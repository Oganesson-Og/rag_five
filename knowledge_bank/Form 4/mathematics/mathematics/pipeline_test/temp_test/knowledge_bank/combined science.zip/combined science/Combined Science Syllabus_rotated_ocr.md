![img-0.jpeg](data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAE/AmgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAPJ/+F++G/wDoG6r/AN8R/wDxdH/C/fDf/QN1X/viP/4uvniigqx9D/8AC/fDf/QN1X/viP8A+Lo/4X74b/6Buq/98R//ABdfPFFAWPof/hfvhv8A6Buq/wDfEf8A8XR/wv3w3/0DdV/74j/+Lr54ooCx9D/8L98N/wDQN1X/AL4j/wDi6P8Ahfvhv/oG6r/3xH/8XXzxRQFj6H/4X74b/wCgbqv/AHxH/wDF0f8AC/fDf/QN1X/viP8A+Lr54ooCx9D/APC/fDf/AEDdV/74j/8Ai6P+F++G/wDoG6r/AN8R/wDxdfPFFAWPof8A4X74b/6Buq/98R//ABdH/C/fDf8A0DdV/wC+I/8A4uvniigLH0P/AML98N/9A3Vf++I//i6P+F++G/8AoG6r/wB8R/8AxdfPFFAWPof/AIX74b/6Buq/98R//F0f8L98N/8AQN1X/viP/wCLr54ooCx9D/8AC/fDf/QN1X/viP8A+Lo/4X74b/6Buq/98R//ABdfPFFAWPof/hfvhv8A6Buq/wDfEf8A8XR/wv3w3/0DdV/74j/+Lr54ooCx9D/8L98N/wDQN1X/AL4j/wDi6P8Ahfvhv/oG6r/3xH/8XXzxRQFj6H/4X74b/wCgbqv/AHxH/wDF0f8AC/fDf/QN1X/viP8A+Lr54ooCx9D/APC/fDf/AEDdV/74j/8Ai6P+F++G/wDoG6r/AN8R/wDxdfPFFAWPof8A4X74b/6Buq/98R//ABdH/C/fDf8A0DdV/wC+I/8A4uvniigLH0P/AML98N/9A3Vf++I//i6P+F++G/8AoG6r/wB8R/8AxdfPFFAWPof/AIX74b/6Buq/98R//F0f8L98N/8AQN1X/viP/wCLr54ooCx9D/8AC/fDf/QN1X/viP8A+Lo/4X74b/6Buq/98R//ABdfPFFAWPof/hfvhv8A6Buq/wDfEf8A8XR/wv3w3/0DdV/74j/+Lr54ooCx9D/8L98N/wDQN1X/AL4j/wDi6P8Ahfvhv/oG6r/3xH/8XXzxRQFj6H/4X74b/wCgbqv/AHxH/wDF0f8AC/fDf/QN1X/viP8A+Lr54ooCx9D/APC/fDf/AEDdV/74j/8Ai6P+F++G/wDoG6r/AN8R/wDxdfPFFAWPof8A4X74b/6Buq/98R//ABdH/C/fDf8A0DdV/wC+I/8A4uvniigLH0P/AML98N/9A3Vf++I//i6P+F++G/8AoG6r/wB8R/8AxdfPFFAWPof/AIX74b/6Buq/98R//F0f8L98N/8AQN1X/viP/wCLr54ooCx9D/8AC/fDf/QN1X/viP8A+Lo/4X74b/6Buq/98R//ABdfPFFAWPof/hfvhv8A6Buq/wDfEf8A8XR/wv3w3/0DdV/74j/+Lr54ooCx9D/8L98N/wDQN1X/AL4j/wDi6P8Ahfvhv/oG6r/3xH/8XXzxRQFj6H/4X74b/wCgbqv/AHxH/wDF0f8AC/fDf/QN1X/viP8A+Lr54ooCx9D/APC/fDf/AEDdV/74j/8Ai6P+F++G/wDoG6r/AN8R/wDxdfPFFAWPof8A4X74b/6Buq/98R//ABdH/C/fDf8A0DdV/wC+I/8A4uvniigLH0P/AML98N/9A3Vf++I//i6P+F++G/8AoG6r/wB8R/8AxdfPFFAWPof/AIX74b/6Buq/98R//F0f8L98N/8AQN1X/viP/wCLr54ooCx9D/8AC/fDf/QN1X/viP8A+Lo/4X74b/6Buq/98R//ABdfPFFAWPof/hfvhv8A6Buq/wDfEf8A8XR/wv3w3/0DdV/74j/+Lr54ooCx9D/8L98N/wDQN1X/AL4j/wDi6P8Ahfvhv/oG6r/3xH/8XXzxRQFj6H/4X74b/wCgbqv/AHxH/wDF0f8AC/fDf/QN1X/viP8A+Lr54ooCx9D/APC/fDf/AEDdV/74j/8Ai6P+F++G/wDoG6r/AN8R/wDxdfPFFAWPof8A4X74b/6Buq/98R//ABdFfPFFAWPt/FGKKKCQxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRiiigAxRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFIaN2D9O5oAWiqM+s6XattuNSs4m9JJ1U/qajTxBo0pAj1ewc+i3KE/zoA0qKYkiSIHjZXU9CpzTgeSKAFooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAENU9T1Sz0ixkvb+6jtraPlpJDgD29z7DmnalqFrpOnT397MIba3QySOegA/n9O9fK3jrxxfeNNVaSQtFp8RxbWuchV7FvVj/+qgDu/FPx2upZJLbwzbLDEOBd3K5dvdU6D8cn2FeYap4p17WnZtR1e7uA3VTKQn/fI4FZH4d6Oef6mgYUfhShSxwoZj6AZp7QSquWicD3U0hklnqF5p0oksru4tn/AL8MhQ/mDXdeH/jL4q0dkS7mXU7YHBS5+/j2cDOfrmvPeP8A9dGPUfpQB9YeDviLo3jKPZayNb3yruezmwHA9R2YfTn2FdcM5Oa+J7W5nsrqK5tZXhuI3DRyRnDK3se1fS/wv+IK+L9Na0vGVdWtgDIF4EyZx5g/HqP8aZNj0KikHP0paACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKQ0tIe1AHh3x58TuJbPw1BIQhAuboA9eSEX9CfxFeJYPtn17Z/wrp/iJqD6l8QdcnYnC3TQrz2j+T/2WsTSNOk1fWbLTYeJLqdIVPoWYDP4Zz+FAzrPAPw11DxpIbl3az0qN8PcEZZyOqoO59T0Fe76J8MvCOiRIItHguJV6zXYEzE+vPAP0Aro9J0y10fS7bTrOMR29sgRFHt1P4nk+5NXcUCIYbW3tkCQQxxIOiogAH5VKVB60tFAGVqPhvRNWRlv9JsrnIOTJApP54yK8u8Y/A+ymt5LzwuzQXCgsbN33JJ7Kx5U/UkfTrXs2KQigD4lngltp5IJ42jljYpIjqQVYcEGtLw1r1x4Z8RWWr25O63kBdAf9Yh4ZfxHH5elel/Hfw3FZ6nZa/boF+15gucDq6jKt9SMj/gNeO+meO1Az7atLmK8s4bqB98MyLJG395SMg/lU1cP8ItRbUPhvphckvb74Gz/ALLHA/Iiu4oEFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUhpaKAPjTxLuHirWA33hfTA/Xea1fhw8cfxF0IynCm6Cj6kED9SKX4k6c2mfETW4WBAkuDOvusnz/ANSPwrmrW5ms7uG6t2KTQOskbDswORSH0PtkUtc54M8W2fjDQIdQtWUTYC3EGcmF+4+nXB7iuiBz9aYhaKKKACiimsSCMDOaAPLfj2Yx4Hs1b7zaimP++JMn/PrXzp26c/4//rr1H41eLodc12HSLKUSWunbhI6nIeU4BwfQYx9d1eXj7w+tA0fSHwJLHwDNnoL+QD6bU/rmvTq4L4OWDWPw105nBDXLPPg+hYgfmFB/Gu9oEFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUh7UtFAHivx28KyTW9r4ltoy3kKLe7x2TPyN9ASR+I7V4VyMc8j/ADn/AD/Wvti7tYLy0ltrmJJYJUKPG4yGUjBBFfNfxC+F1/4XuJr/AE5JLrRiS24DLW/s/t/tdPWgaOM0TXtT8OX6XulXcltMvBK/dYejA8EfWvafBnxpudY1Oy0fUNHDXNzIsSz2j/Lk9yh6AdTg14L344I79xXqXwM0UX3i641WRcx6fASvoJJMqP8Ax3fQDPotTknPanUg6UtAhrEjp6V84+MvjF4g1YXGm2duNJgDNHJsctMcHBG/Ax07AH3r6PNfJ3xN0saR8RNZgCAJLN9oXA4IkAbj8SR+FAHJdzyPwrS0DRbnxFrtppNoP3tzIE3EZCDux9gMmqtnZXeoXcVpaQS3FxKQscUaksx+navpP4X/AA7TwhYtfX4STV7hcOV5EKddgPc+p9hj1IM7rTrOHTtPt7K3QpBbxrFGpOSFUAD+VWqAAOlFAgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAxTSinsKdRQB594l+D/AIZ192nghOm3TEkyWoAUk+qdPfjFaXw+8Ep4I0i5svtK3Us05laYRlMjAAGMnpg/nXXEf5xTHkWJDJIyog6lmwB+JoAkxiisabxb4ctmKz6/pcbDs13GD/Ook8beFXOF8SaST6fbIxn9aAN01wHjL4XWXjTxHbapc38tvHHAIpIoUBaTDEg7jwPvehrtrbULK/GbS8t7gYzmKQP/ACNWR06UAYHhvwZoPhWAx6VYRxuRh52+aR/qx5x7DiugxRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAITiqOravY6Hp8l9qV3HbWsY+aST17AepPoKk1LULbStPnv7yVYra3QySO3YAV8qeOfG174z1hp5S0VjEStrbA8Ivqf9o96Bna+KvjnqV4723hy3FnBnAuJkDyn3C9F/HP17Dy/UdZ1PV5jLqOo3N2+es0pbH0z0/CqPHpn0o9gfyoAMD0oqe3sbu7z9ntZpucfu0LfyFTyaLq0S7pNLvUUfxNbuP6UhlOOR4XV42KMpyCpwQa7Pw/8VfFmgOijUGvrYHmC8zJkezH5l/PHsa4tlKHDAqR1BHNJ1/8A15oA+qPBfxM0jxiogQmz1ILlrSU9f9xv4vpwfau2Uk5z618SQTS288c9vI0U0bBkkQ4ZSOhB/wA/zr6U+FnxD/4SzTzp+oMg1a2XJI4E6dN4HqO4+h70ybHpFFIO9LQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSE4HHWlpCM4oA8T+PXiV447Lw5BIQsi/arraeqgkIv5gn8BXhvOccZ689K634m6gdS+I2syknEU/kKPQRgJx+Kk/jXMWltLeXkFrbrvmnkWKNfVmOAPzIoGdH4I8C6n421AxWv7iziI8+6dcqmeQBj7zY7fmR3+g/Dvwx8K+H4kEenR3dwoGZ7sCRifUA/KPwFbXhbw9aeF/DtppNoo2wr874wZHP3mPuTWzQIaqKihVUKqjAAHSlxS0UAZ2paFpWrxGPUdOtbpSP+W0Stj8eoryHxz8FIUt5dR8Ll96gs1i7Ftw/6Zk85/2T17YPX2+kPSgD4iZWRyrKVZeqkYIrS8Pa1ceHdfstVtTiS3lDYzgOvQqfYg4r0D43+GY9J8QQaxbRhIdRDGVV6CZcFj/wIEH65ryzp1xgGgZ9sWV1DfWNvd27boZ41kjb1UjIqeuH+Ed+1/8ADbTN7Ze3327f8BY4/TFdxQIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoNFFAHxr4mYv4r1h26tfTk/wDfZrU+HESTfEXQkkAKi6Dc+oyR+oFVfHNo1j4712BgRi9lYD/ZZiw/QiqXh7VP7E8R6dqeCVtbhJWA7qDk/pmkM+zBnvS1FBNHcQRzwuHikUOjA5DKeQRUtMQUUUUAFFFITjvigDyv49xI3gezcj511BAD9Y5M/wAq+dT1J4/ya9z+P+sx/ZdK0RWzIXa6lX+6ACq/nl/yrwvB59aBo+kvgSxPgGUHtfSAf98pXp1eefBW0Nt8OLaUgj7TPLKM+m7YD/45mvQ6BBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIaWigD5z+OehPY+LYdWVT5OoxgM3YSIAp/8d2mvLM9O38s19d+OPCkHi/wzPpjlY7j79tKeiSDpn2PQ+3vivkq6tZrK7mtbhAs0EjRSLkHDKcEfh6ikNM9f+FHxRt9MtYvD2vT+XbLxaXb9Iwf4H9B6Ht34r3aOZZY1ljZWjYAqynII9Qe9fElb+heNPEfhtcaVqs8MQOfJbDx/98twPwpgfX4pa+cbb49eJ4FAntNMn/2zG6sfybFWn+P+vMmY9K01T6sJCPy3CgLH0GxxXN+LvGuk+D9Na5v5Q05B8m1U/PI2OOOw9zXgmp/GTxjqcbIl3BYo3H+ixAH8C2WH4GuGurq4vbl7m7nknnf70krFmb6k80BYu+IddvPEmuXOq3z5mnbOB0RQOFHsB/WqNtby3d3DbW8ZkmlcRxoOrMTgD8zUXJOP8/5/wr2H4JeCxe3h8UXgVre1dktVz96TGCxHbAPHufYGkM9r8PaUmh+H9P0tDkWtukRP94gYJ/E5NadIKWmSFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAf//Z)

ZIMBABWE

MINISTRY OF PRIMARY AND SECONDARY EDUCATION

# COMBINED SCIENCE SYLLABUS 

FORMS 1 - 4
2015 - 2022

Curriculum Development Unit
P. O. Box MP 133

MOUNT PLEASANT
HARARE

CAll Rights Reserved
2015

# Combined Science (Form I - 4) Syllabus 

## ACKNOWLEDGEMENTS

The Ministry of Primary and Secondary Education would like to acknowledge contributions made by the following towards the development and production of this syllabus:

- The National Science Syllabus Panel
- Zimbabwe School Examinations Council (ZIMSEC)
- Government Departments
- Ministry of Higher and Tertiary Education, Science and Technology Development
- UNICEF
- UNESCO

# Combined Science (Form I - 4) Syllabus TABLE OF CONTENTS 

ACKNOWLEDGEMENTS ..... i
1.0 PREAMBLE ..... 1
1.1 INTRODUCTION ..... 1
1.2 RATIONALE ..... 1
1.3 SUMMARY OF CONTENT. ..... 1
1.4 ASSUMPTIONS ..... 1
1.5 CROSS- CUTTING THEMES ..... 1
2.0 PRESENTATION OF THE SYLLABUS ..... 1
3.0 AIMS ..... 1
4.0 SYLLABUS OBJECTIVES. ..... 1
5.0 METHODOLOGY AND TIME ALLOCATIONS ..... 2
6.0 TOPICS ..... 2
7.0 SCOPE AND SEQUENCE ..... 3
8.0 COMPETENCY MATRIX ..... 10
9.0 ASSESSMENT ..... 86

# 1.0 PREAMBLE 

### 1.1 INTRODUCTION

This syllabus covers four years of Secondary Education, Forms 1 - 4. The syllabus provides an understanding in Combined Science and a suitable preparation for the study of science related fields. It aims to equip learners in their diverse needs with scientific skills of long term value in an increasingly technological world. A learner- centred practical approach to the subject is adopted to develop scientific thinking and application of acquired knowledge and skills.

### 1.2 RATIONALE

This syllabus develops learners' basic scientific skills in Physics, Chemistry and Biology. It develops knowledge, understanding and practical application of basic scientific concepts and principles as well the ability to handle information and critical thinking. Learners will gain practical experience and leadership skills through individual and group experimental work

### 1.3 SUMMARY OF CONTENT

The Combined Science learning area covers basic concepts in Biology, Chemistry and Physics. The syllabus covers science concepts such as observing, recording, measuring, presentation, interpretation of data and analysis. It also imparts practical skills such as handling of apparatus, chemicals, plant and animal specimens safely and confidently.

### 1.4 ASSUMPTIONS

It is assumed that learners have:

- knowledge of the content of the Science and Technology syllabus offered in Junior School
- engaged in science experiments
- engaged in project and cooperative work
- used measuring instruments such as rulers, thermometers, clocks and balances


### 1.5 CROSS- CUTTING THEMES

In order to foster competency development for further studies, life and work, the following cross-cutting priorities have to be taken into consideration in the teaching and learning of Combined Science:

- Gender
- Children's rights and responsibilities
- Disaster risk management
- Financial literacy play store
- Health issues
- Heritage studies
- Collaboration
- Environmental issues
- Socio-cultural beliefs


### 2.0 PRESENTATION OF THE SYLLABUS

This Form 1 to 4 Combined Science syllabus is presented as a single document which consists of the preamble, rationale, summary of content, assumptions, cross cutting themes, aims, objectives, topics, methodology, time allocation, scope and sequence, competency matrix and assessment. The content is divided into Biology, Chemistry and Physics sections.

### 3.0 AIMS

The aims of the syllabus are to enable learners to:
3.1 provide an opportunity to develop desirable scientific literacy
3.2 promote critical thinking, creativity and problem solving skills that apply to real life situations
3.3 develop scientific practical skills, accuracy, objectivity, integrity, enquiry and team work
3.4 develop attitudes relevant to science such as self-initiative, self-managing and enterprising
3.5 relate scientific practices to sustainable use and extraction of value from our natural resources
3.6 participate in the technological development of Zimbabwe and the global world.

### 4.0 SYLLABUS OBJECTIVES

Learners will be able to:
4.1 apply scientific principles in solving problems and in understanding new situations
4.2 describe observations, record results, interpret and draw conclusions from experiments
4.3 demonstrate knowledge of scientific terms, laws, facts, concepts, theories and phenomena
4.4 demonstrate knowledge and understanding in relation to scientific and technological applications with their social, economic and environmental implications
4.5 demonstrate relevant attitudes to science such as accuracy and precision, objectivity, integrity, enquiry initiative, team work and inventiveness
4.6 demonstrate knowledge and understanding of scientific instruments and apparatus including techniques of operations and aspects of safety
4.7 use different forms of data presentation to give rational explanations of scientific phenomena

## Combined Science (Form I - 4) Syllabus

4.9 plan, organize and carry out experimental investigations
4.9 draw scientific diagrams in two dimensions
4.10 apply scientific principles, formulae and methods to solve qualitative and quantitative problems
4.11 apply scientific principles, methods and techniques in value addition and beneficiation of our natural resources
4.12 use appropriate methods of recycling and/or disposing wastes
4.13 communicate scientific information logically and concisely.

### 5.0 METHODOLOGY AND TIME ALLOCATION

### 5.1 Methodology

Emphasis should be placed on providing learners with practical experience so that they appreciate science as an active and exciting study. Principles of individualisation, concreteness, totality and wholeness, self-activity and stimulation should under pin the implementation of teaching/learning methods in this learning area. The following methods are suggested:

- Experiments
- Demonstration
- Problem solving
- Field trips
- Games
- Cooperative learning/Group work
- Simulations
- Case studies/Research
- Question and Answer
- Discussions
- Surveys, Interviews and Report writing
- Concept mapping
- Visual tactile
- Individualisation


### 5.2 Time allocation

For adequate coverage of the syllabus, a time allocation of 8 periods of 35 minutes per week is recommended. Double periods are recommended to accommodate practical work. The class size should not exceed 35 learners. At least 2 educational tours per year are recommended.

### 6.0 TOPICS

### 6.1 BIOLOGY:

- Laboratory rules and safety
- Cells and levels of organization

# 7.0 SCOPE AND SEQUENCE 

### 7.1 BIOLOGY

| TOPIC | Form 1 | Form 2 | Form 3 | Form 4 |
| :--: | :--: | :--: | :--: | :--: |
| 7.1.1 Laboratory Safety and apparatus | - Laboratory rules and safety <br> - Introduction to laboratory apparatus |  |  |  |
| 7.1.2 Cells and levels of organization | - Plant and animal cell structure <br> - Similarities and differences of plant and animal cells | - Types of variation: continuous and discontinuous | - Structures and functions of specialized cells <br> - Use of a microscope | - Ecosystems |
| 7.1.3 Nutrition | - Diet | - Photosynthesis <br> - Digestive system in humans | - Factors affecting rate of photosynthesis <br> - Conditions necessary for photosynthesis <br> - Teeth and digestion | - Human diet: balanced diet <br> - Deficiency diseases <br> - Food tests |

| 7.1.4 <br> Respiratory systems | - Respiratory gases | - Respiratory organs <br> - Breathing mechanism | - Gaseous exchange in alveoli | - Respiration: aerobic and anaerobic respiration |
| :--: | :--: | :--: | :--: | :--: |
| TOPIC | FORM 1 | FORM 2 | FORM 3 | FORM 4 |
| 7.1.5 <br> Transport systems | - Osmosis and diffusion <br> - Components of blood | - Root and stem structure <br> - Water and ion uptake <br> - Heart structure and associated blood vessels | - Transpiration: factors affecting rate of transpiration <br> - Measurement of transpiration <br> - Plasmolysis <br> - Turgidity <br> - Blood circulation | - Adaptations of plants to reduce transpiration <br> - Structure of blood vessels |
| 7.1.6 <br> REPRODUCTIVE <br> SYSTEMS | - Reproduction in plants: flower structure, pollination, fertilization, seed dispersal <br> - Human reproductive organs <br> - Puberty | - Detailed structure of a wind and an insectpollinated flower <br> - Functions of Human reproductive organs | - Structure of the seed <br> - Germination <br> - Male and female reproductive systems <br> - Sex cells <br> - Fertilisation, pregnancy, placenta and child care <br> - Menstrual cycle | - Asexual and sexual reproduction in plants <br> - Inheritance <br> - Methods of contraception <br> - Contraceptives |

# 7.2 CHEMISTRY 

| TOPIC | FORM 1 | FORM 2 | FORM 3 | FORM 4 |
| :--: | :--: | :--: | :--: | :--: |
| 7.2.1 SEPARATION | - Filtration <br> - Magnetism, <br> - Winnowing, <br> - Decanting, <br> - Evaporation | - Applications of filtration, magnetism, winnowing, decanting, evaporation | - Distillation, <br> - Fractional distillation | - Paper chromatography |

| 7.2.2 MATTER | - States of matter <br> - Kinetic theory <br> - Period table: identification of elements <br> - Metals and nonmetals <br> - Elements mixtures and compounds | - Concentrations of solutions <br> - Groups and periods | - Structure of atoms <br> - Electronic configurations <br> - Periodic table <br> - Nuclide notation <br> - Names and groups of elements <br> - Mole concept, empirical and molecular formulae <br> - concentration | - Reactivity series <br> - Factors affecting rate of reaction |
| :--: | :--: | :--: | :--: | :--: |

| TOPIC | FORM 1 | FORM 2 | FORM 3 | FORM 4 |
| :--: | :--: | :--: | :--: | :--: |
| 7.2.3 ACIDS, BASES AND SALTS | - Identification of acids and bases: litmus paper test | - Acid- base reactions | - pH scale <br> - preparation of salts <br> - reactions of metal + acid, acid + base , acid + carbonate | - Titration of bases with acids |
| 7.2.4 INDUSTRIAL PROCESSES | - Production of peanut butter | - Production of soap | - Fractional distillation of liquid <br> - Electrolysis <br> - Electroplating | - Haber process <br> - Contact process |
| 7.2.5 OXIDATION AND REDUCTION | - Rusting: factors | - Chemical reactions: combustion | - Extraction of iron | - Alloy formation |

# 7.3 PHYSICS 

| TOPIC | Form 1 | Form 2 | Form 3 | Form 4 |
| :--: | :--: | :--: | :--: | :--: |
| 7.3.1 DATA PRESENTATION | - Tallies, tables, bar graphs | - straight line graphs | - pie charts, line graphs, interpretation | - pie charts, line graphs, interpretation and analysis |
| 7.3.2 MEASUREMENT | - Physical quantities <br> - S.I units | - Prefixes <br> - Conversions <br> - Density | - Physical quantities, accuracy and precision <br> - Density of liquids | - Derived quantities |
| 7.3.3 FORCE | - Effects of force <br> - Types of force <br> - Measurement of force | - Moments of force <br> - Resultant force <br> - Levers | - Weight and mass machines: inclined plane, pulleys, levers and gears | - Principles of pressure <br> - Fluid systems <br> - Pumps |
| 7.3.4 ENERGY | - Types of energy <br> - Energy conversions | - Law of conversion of energy <br> - Calculations on work <br> - Properties of light <br> - Sound energy | - Petrol and diesel engines <br> - Heat transfer: convection, conduction and radiation | - Heat transfer applications: solar water heater and solar cooker <br> - Telecommunications |

| 7.3.5 MAGNETISM AND ELECTRICITY | - Magnets, poles, fields, compass <br> - Static electricity: charges <br> - Current electricity: conductors and insulators <br> - Circuit components | - Properties of magnets <br> - Attraction and repulsion <br> - Circuit symbols and diagrams <br> - Measurement of electricity | - Electromagnetism <br> - Motor effect <br> - Generator effect <br> - Electroscope <br> - Lightning <br> - Ohm's Law <br> - Resistance <br> - Resistors <br> - Electrical power and energy | - Power generation <br> - Electrical safety <br> - Domestic electricity |
| :--: | :--: | :--: | :--: | :--: |

# 8.0 COMPETENCY MATRIX 

## FORM 1

### 8.1 BIOLOGY

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.1.1 <br> LABORATORY <br> SAFETY AND <br> APPARATUS | - explain laboratory rules <br> - identify laboratory apparatus <br> - demonstrate use of laboratory apparatus | - Laboratory rules <br> - laboratory apparatus: beaker, measuring cylinder, test tube, crucible, evaporation dish, tripod stand, wire gauze, Bunsen burner, spirit burner, spatula, funnel | - discussing laboratory rules <br> - discussing and drawing laboratory apparatus <br> - taking readings from laboratory apparatus such as measuring cylinder, balances | - Multimedia \& Braille/Jaws software <br> - laboratory apparatus |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.1.2 CELLS AND LEVELS OF ORGANISATION | - describe the structure of a plant and an animal cell <br> - list similarities and differences between plant and animal cells | - Plant cell: cell membrane, cell wall, cytoplasm, nucleus, permanent vacuole <br> - Animal cell: cell membrane, cytoplasm, nucleus | - Using bio viewers and hand lenses to observe and draw cells <br> (avoid using human blood or cheek cells) | - Charts on cells <br> - Models of cells <br> - ICT tools \& Braille/Jaws software <br> - Onion <br> - Hand lens |
| 8.1.3 NUTRITION | - define balanced diet <br> - list component of balanced diet <br> - name functions of nutrients | - Carbohydrates, proteins, fats, vitamins, fibre, mineral salts and water <br> - Functions of nutrients | - Naming different kinds of foods and identifying their nutrients <br> - Discussing functions of nutrients | - Charts on collection of foods <br> - Food samples <br> - E-learning packages |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED <br> RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.1.4 <br> RESPIRATORY <br> SYSTEM | - State the percentage composition of air <br> - Identify respiratory gases <br> - describe the test for carbon dioxide gas <br> - test for oxygen gas | - Nitrogen 78\%, oxygen $20 \%$, carbon dioxide $0,03 \%$, rare gases, water vapour less in air <br> - Oxygen and carbon dioxide <br> - Carbon dioxide <br> - oxygen | - Discussing the composition of air <br> - Comparing oxygen in inhaled and exhaled air experiment <br> - Blowing into lime water or bicarbonate indicator <br> - Using glowing wooden splint for oxygen test | - Model of breathing system, <br> - Internet <br> - Inverted jar, candle, water trough <br> - Lime <br> water/bicarbonate <br> indicator <br> - Glowing wooden splint |
| 8.1.5 TRANSPORT <br> SYSTEMS | - describe water movement in plants <br> - identify components of blood stating the functions | - Osmosis <br> - Diffusion <br> - Components of blood | - Demonstrating water movement in a plant using potassium permanganate/methylen e blue/coloured solution <br> - Observing components | - use of potted plants <br> - ICT tools \& Braille/Jaws software <br> - Bioviewer, bioset |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | of each component | - Functions of the components | of blood on slides |  |
| 8.1.6 <br> REPRODUCTION <br> IN PLANTS AND <br> HUMANS | - describe structure of a simple flower <br> - describe pollination and fertilization <br> - state signs of puberty | - Flowers, carpel, stamens <br> - Pollen grains <br> - Ovule, ovary ,fruit <br> - Signs of puberty, such as breasts, beard, menstruation, growth of pubic hair, widening of pelvic girdle, voice deepening | - Observing a flower using hand lens/ bio viewers <br> - Emphasis on premenstrual symptoms such as period pain | - Charts on flowers <br> - Flowers <br> - Models of human being <br> - Computer <br> - Simulations <br> - ICT tools \& Braille/Jaws software |
| 8.1.7 HEALTH AND DISEASES | - describe a healthy person <br> - state importance of maintaining personal hygiene <br> - list ways of disposing litter/ | - State of being mentally, socially and physically well <br> - Importance of personal hygiene and food hygiene | - Discussing the state of a health person <br> - Cleaning of classrooms <br> - Carrying simple disinfection of drains | - ICT tools \& Braille/Jaws software <br> - Disinfectants <br> - Brooms <br> - Mops <br> - EMA resource |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | waste, stating their advantages and disadvantages <br> - describe methods of transmission of diseases | - Burying, recycling, burning <br> - water, food, vectors, contact <br> Cholera - water <br> Ebola - contact <br> Malaria - vector <br> Bilharzia - vector | - Discussing cleaning of a toilet <br> - Picking and burying wastes <br> - Discussing methods of disease transmission | person <br> - Print media |

# 8.2 CHEMISTRY 

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.2.1 <br> SEPARATION | - State methods of separating mixtures | - Filtration, Magnetism, Winnowing, Decanting, Evaporation | - Carrying out experiments to illustrate methods of separating | - Magnet <br> - sulphur <br> - ICT tools \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.2.2 MATTER | - identify the three state of matter <br> - describe the arrangement of particles in solids, liquids and gases <br> - describe properties of solids, liquids and gases in terms of kinetic theory of matters <br> - describe the factors that affect solubility <br> - identify mixtures, elements and compounds <br> - identify metals and nonmetals on periodic table | - solids, liquids and gases <br> - properties of solids, liquids and gases <br> - Kinetic theory <br> - Particle arrangement in solids, liquids and gases <br> - Particle size, temperature, stirring <br> - Elements, mixtures, compounds <br> Common elements of the periodic table. | - identifying the three states using salt, water and air <br> - compressing a gas in syringe <br> - carrying out experiments on heating ice block, candle wax, naphthalene, iodine crystals <br> - discussing particle arrangement in solids, liquids and gases <br> - dissolving potassium permanganate crystals/ copper sulphate crystals in water <br> - mixing of iron and sulphur, sand and maize | - salt, water, stones, syringe, beakers, ice, candles naphthalene flakes <br> - iodine crystals <br> - models <br> - Periodic Tables <br> - iron filings <br> - Sulphur powder <br> - sand, maize <br> - beakers <br> - spatulas <br> - salt/sugar <br> - water |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | grains <br> - heating iron and sulphur <br> - identifying elements on the Periodic Table |  |
| 8.2.3 ACIDS AND BASES | - identify acids and bases using red and blue litmus <br> - list properties of acids and bases | - Acids and bases | - dipping litmus paper in HCL, NaOH, $\mathrm{H}_{2} \mathrm{O}, \mathrm{CuSO}_{4}$,tap water | - Red/blue litmus <br> - Solutions(acids and base) |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.2.4 INDUSTRIAL PROCESSES | - Outline production of peanut butter <br> - Outline the production of oil from peanut butter <br> - State uses of oil | - Processes: <br> Shelling, roasting, grinding and packaging <br> Equipment : <br> sheller, peanut <br> butter making machine | - Preparing peanut butter <br> - Pressing peanut butter to produce oil | - Winnowing basket <br> - Roaster, sheller and peanut butter making machine <br> - Grinding stone (guyo/imbokodo) <br> - Mortar and pestle |
| 8.2.5 OXIDATION AND REDUCTION | - state conditions necessary for rusting <br> - explain methods of preventing rusting | - Conditions: oxygen and moisture <br> - Methods: painting, galvanising, plating | - carrying out experiments to investigate conditions necessary for rusting | - iron nails <br> - oil <br> - Multimedia \& Braille/Jaws software <br> - fused calcium chloride |
| 8.2.6 ORGANIC CHEMISTRY | - identify forms of fuels <br> - compare the efficiency of different fuels | - Fuels : liquid, solid, gaseous | - Discussing forms of fuels <br> - Experimenting on fuel efficiency | - Wood, <br> - Paraffin, <br> - Methylated spirit burner, <br> - Bunsen burner |

# 8.3 PHYSICS 

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED <br> RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.3.1 DATA <br> PRESENTATION | - Present data in the form of tallies, tables and bar graphs <br> - Interpret data presented in the form of tallies, tables and bar graphs | - tallies, tables and bar graphs | - collecting and presenting data in the form of tallies, tables and bar graphs | - Multimedia \& Braille/Jaws software |
| 8.3.2 <br> MEASUREMENT | - estimate physical quantities <br> - identify appropriate instruments for measuring physical quantities <br> - measure accurately <br> - identify types of errors in measurement <br> - read an instrument scale to the nearest division <br> - identify units including S.I | - Length, mass, time and temperature <br> - Length, mass, time and temperature <br> - Parallax error and zero error <br> - SI units: metre (m), | - Estimating length, time, mass and temperature <br> - Taking measurements at different points <br> - Measuring length, time, temperature and mass | - Metre rule <br> - Thermometer <br> - Balance <br> - Stop watch <br> - ICT tools \& Braille/Jaws software <br> - Foam rubber, springs, trolleys, rubber bands <br> - Magnets, rulers, |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | units | kilogram(kg), <br> Kelvin, second(s) |  | bricks <br> - Masses |
| 8.3.3 FORCE | - demonstrate the effect of forces on position, shape and size <br> - identify various types of force <br> - state the unit of force | - Effects of Forces: deformation of solids, change of position, change in speed and direction <br> - Types of forces: gravitational | - Carrying out experiments on effects of forces <br> - Carrying out experiments on gravitational force, push and pull, electrostatic force, magnetic force, | - Forcemeter <br> - Spring balance |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - identify instruments for measuring force | force, weight, mechanical force <br> - electrostatic force ,magnetic force and friction <br> - S.I unit: Newton (N) <br> - Forcemeter <br> - Spring balance | friction <br> - Measuring force using spring balance or forcemeter |  |
| 8.3.4 ENERGY | - describe effects of energy <br> - identify different -forms of energy <br> - list forms of potential energy | - Effects of energy <br> - Forms and sources of energy <br> - Kinetic, potential, light, heat, electrical, chemical, sound <br> - Forms of | - Demonstrating the effects of energy: burning fuels, bouncing a ball, making objects move, compressing a spring <br> - Running upstairs, lighting a torch, clapping hands, raising a brick <br> - Carrying out | - spring, candle, ball, catapult, magnesium ribbon <br> - torch, brick, musical instruments <br> - trolleys <br> - catapult <br> - torch cell |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  | potential energy: gravitational, elastic, chemical | experiments to show potential energy |  |
|  | - identify energy conversions <br> - construct energy chains <br> - identify energy convertors | - Energy conversion: energy changes, energy chains <br> - Energy convertors | - Lighting a torch <br> - Using a dynamo to light a bulb <br> - Using a catapult and solar panel <br> - Discussing various energy convertors | - Torch <br> - Dynamo <br> - Catapult <br> - Solar panel <br> - Bulb <br> - Green plants <br> - Engines <br> - refrigerator <br> - Cell <br> - Bulb <br> - Solar cells <br> - Generators |
| 8.3.5 MAGNETISM | - distinguish magnetic material from nonmagnetic materials <br> - identify the poles of a | - Magnets: bar magnets, horse shoe magnets, | - Using magnets to identify magnetic and non-magnetic materials <br> - suspending a bar | - Horse shoe magnets <br> - Bar magnets <br> - C-magnets |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | magnet | C -magnets, <br> E-magnets <br> - Magnetic and non-magnetic materials <br> - Poles and magnets: South and north poles: earth as magnet | magnet to determine polarity <br> - using a compass | - E-magnets <br> - Steel, iron nails, copper, aluminium, wood, plastic, glass <br> - bar magnet, string, magnetic compass, |
| 8.3.6 ELECTRICITY | - state the two type of charges <br> - describe the production of charges <br> - define current <br> - distinguish between conductors and insulators <br> - identify components of | - Negative, positive <br> - Static electricity <br> - Current as flow of charges <br> - Conductors and insulators | - Rubbing polythene or Perspex on hair or dry cloth <br> - Carrying out experiment on conductivity of different materials <br> - Drawing circuit | - Polythene <br> - Perspex <br> - Dry cloth <br> - Plastic <br> - Wood <br> - Iron bar electrolytes, <br> - Carbon rods, <br> - Copper rods <br> - Light bulb <br> - Voltmeter |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | direct current (d.c.) circuit <br> - draw and label a simple direct current (d.c) circuit | - Cells, batteries, bulbs, switches ,resistors, <br> - standard symbols | diagrams using symbols | - Ammeter <br> - Circuit boards <br> - Cells <br> - Switches <br> - Resistors <br> - Chart of standard electrical symbols <br> - ICT tools \& Braille/Jaws software |

# 8.4 BIOLOGY 

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.4.1 TYPES OF VARIATION | - state differences among living organisms <br> - compare continuous and discontinuous variation <br> - draw bar graphs to show variations in living organisms | - variation: <br> height, mass, shoe size, skin/ coat colour, sex, right or left handedness, tongue rolling <br> - bar graphs | - comparing height, mass, shoe size, skin/ coat colour, sex, right or left handedness, tongue rolling <br> - drawing bar graphs to show variations | - leaves <br> - seeds in a pod <br> - ICT tools \& Braille/Jaws software |
| 8.4.2 NUTRITION | - explain importance of plants as producers <br> - state the word equation for photosynthesis <br> - draw and label digestive system of humans <br> - outline the route followed by food in the human digestive system | - Animals as consumers of food <br> - Photosynthesis <br> - Digestive system in Humans: alimentary canal | - Discussing the conversion of solar energy to chemical energy by plants <br> - Observing a model of the alimentary canal | - Charts on leaf structure <br> - ICT tools \& Braille/Jaws software <br> - Models of the alimentary canal <br> - Charts on human alimentary canal |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.4.3 RESPIRATORY ORGANS | - state word equations for respiration <br> - label parts of respiratory system | - Glucose + 0xygen $\rightarrow$ carbon dioxide + water | - Carrying out experiments to show that energy is released during burning of food(during respiration) | - Models of respiration <br> - ICT tools \& Braille/Jaws software |
| 8.4.4 TRANSPORT SYSTEMS | - Outline the internal structures of a root and stem <br> - describe water and ion uptake by plants <br> - Draw and label the structure of the heart | - Root and stem structures of a dicotyledonous plant: epidermis, cortex, phloem, cambium, xylem <br> - Osmosis and active uptake <br> - Structure of heart; atria, ventricles and valves; bicuspid and tricuspid, semi lunar | - Discussing the internal structures of a root and stem <br> - Viewing of prepared slides <br> - Carrying out an experiment to show arrangement of vascular tissue using dye <br> - Examining model of the circulatory system <br> - Drawing and | - Plant <br> - ICT tools \& Braille/Jaws software <br> - Microscope <br> - Bio-viewer <br> - Model of human circulatory system <br> - ICT tools \& |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - name the main blood vessels to and from the heart <br> - state functions of the heart | valves <br> - Blood vessels and heart <br> - Receiving and pumping blood | labelling structure of the heart <br> - Identify vessels to and from the heart on a model <br> - Simulations on action of the heart | Braille/Jaws software <br> - Model of the heart |
| 8.4.5 <br> REPRODUCTIVE <br> SYSTEMS | - distinguish between monocotyledonous and dicotyledonous plant seeds <br> - describe functions of cotyledon and endosperm <br> - state the functions of the female and male reproductive systems | - Structure of maize and bean seeds: testa, radicle, plumule, endosperm and cotyledon <br> - Human reproductive systems: <br> Penis, testes, sperm duct, urethra, prostate glands, vagina, ovary, oviduct, uterus, cervix | - comparing internal and external features of the monocotyledonous and dicotyledonous plant seeds <br> - discussing the functions of male and female reproductive systems | - Multimedia \& Braille/Jaws software <br> - models of reproductive systems <br> - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.4.6 HEALTH AND DISEASES | - state causes of diseases <br> - describe causes of bilharzia <br> - describe the life cycle of bilharzia parasite | - Contaminated food, water, air <br> - Bilharzia worm <br> - Snail-human host <br> - Eggs in water | - discussing the transmission of bilharzia parasite and methods of preventing spread of bilharzia | - bilharzia life cycle chart <br> - Multimedia \& Braille/Jaws software |

# 8.5 CHEMISTRY 

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED <br> RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.5.1 <br> SEPARATION | - state the applications of filtration, winnowing magnetism and evaporation | - application: treatment of water ,grain separation, separation of metallic objects from grain before grinding, separation of | - practicals on salting of peanuts <br> - details of the process of sugar production and process of production of ammonium nitrate NOT required <br> - field trips on visiting a | - Multimedia \& Braille/Jaws software <br> - field trips |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  | metallic waste for recycling <br> - formation of sugar and ammonium nitrate crystals from their solutions | grinding mill, water filtering plant, ammonium nitrate manufacturing plant |  |
| 8.5.2 MATTER | - determine the concentrations by colour intensities of dissolved substances <br> - determine the concentration of a substance by varying the amount of solute in a given solvent | - Concentration of solutions <br> - Concentration of solution expressed in terms of mass of solute dissolved per given volume of solvent | - carrying out experiments on dissolving coloured substances(differing amounts to be dissolved) <br> - Carrying out experiments on dissolving known masses of solute in known volumes of solvent | - potassium permanganate <br> - ammonium dichromate <br> - copper sulphate <br> - brown sugar <br> - salt, water <br> - ammonium nitrate |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.5.3 <br> ACIDS,BASES <br> AND SALTS | - describe an acid-base reaction | - Acids-base reactions | - Carrying out experiments to demonstrate acid- base reactions | - litmus paper <br> - Dilute $\mathrm{HCl}, \mathrm{H}_{2} \mathrm{SO}_{4}$ and NaOH solution |
| 8.5.4 INDUSTRIAL PROCESSES | - Outline the manufacture of soap | - Production of soap/ <br> saponification | - Making soap <br> - Visiting soap manufacturing companies | - NaOH solution, NaCl solution, plant/animal fat |
| 8.5.5 OXIDATION AND REDUCTION | - write simple word equations <br> - define oxidation and reduction in terms of oxygen <br> - distinguish between physical and chemical changes | - Chemical reactions | - burning magnesium ribbon <br> - melting ice, burning sugar/mealie- meal | - burner <br> - magnesium ribbon and mealie meal/sugar |
| 8.5.6 ORGANIC <br> CHEMISTRY | - define complete and incomplete combustion of fuels <br> - list the products of complete and incomplete combustion | - Complete and incomplete combustion <br> - Global warming. | - lighting burners (methylated spirit) with long and short wicks/ paraffin stove <br> - lighting Bunsen burner | - Burner(paraffin/ methylated) <br> - Gas burners <br> - Posters, drama. |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | of fuels <br> - describe the effects of burning fuels | deforestation, | sleeve wide/narrow <br> - Carrying out environmental awareness campaigns |  |

8.6 PHYSICS

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED <br> RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.6.1 DATA <br> PRESENTATION | - Construct a straight line graph from appropriate data <br> - Interpret straight line graphs | - Straight line graphs | - Drawing a straight line graphs from given data | - Multimedia \& Braille/Jaws software |
| 8.6.2 <br> MEASUREMENTS | - convert units <br> - measure mass of a liquid <br> - measure the volume of an | - prefixes of S.I units <br> - Measurement of mass <br> - Measurement of | - Converting metre to centimetre, millimetre, kilogram to gram, hour to minutes, minutes to second <br> - Carrying out | - Metre rule, balance, stopwatch, <br> - Beaker and water <br> - Measuring |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | irregular object <br> - determine the thickness, volume and mass of small objects <br> - calculate density | volume by displacement <br> - Measurement of volume, thickness and mass of small objects <br> - Formula for density | experiments on measurement by differences of mass <br> - Carrying out experiments on measurement of irregular objects <br> - Carrying out experiments on measurements of volume, thickness and mass <br> - carrying out experiments to find mass and volume <br> - Carrying out experiments to demonstrate equal and unequal forces | cylinder <br> - Irregular objects <br> - Overflow can <br> - String <br> - Book, seeds, pins <br> - Metre rule <br> - Balance <br> - Stopwatch <br> - Regular and irregular objects <br> - liquids <br> - Forcemeters, levers, <br> - masses, balance, metre rule, |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - define moment of a force <br> - calculate moment of a force <br> - state the principle of moments <br> - apply the principle of moments in simple calculations <br> - define friction <br> - measure friction <br> - state the applications of frictional force | - Moment of force $=$ force $x$ perpendicular distance from the pivot <br> - At equilibrium: Clockwise moments = anti clock wise moments <br> - Frictional force: force opposing motion <br> - nature of surface <br> - car braking system <br> - tyre treads <br> - soles of shoes <br> - road surfaces <br> - power =current $x$ | - Demonstrating moments of force <br> - applying the principle of moments <br> - Carrying out experiments to investigate frictional forces | - spring balance |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  | voltage |  |  |
| 8.6.4 MACHINES | - define a machine <br> - construct a simple machine | - Simple machines: levers | - Lifting a load using a crowbar <br> - Constructing a simple machine | - Crowbar <br> - Planks <br> - Masses |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.6.5 ENERGY | - state the law of conservation of energy <br> - define work and energy <br> - state the S.I unit of work and energy <br> - calculate the work done or energy used by forces <br> - list sources of light energy <br> - show that light travels in a straight line <br> - state the production and transmission of sound <br> - demonstrate the need for a medium in the transmission of sound | - Conservation of energy <br> - Work and energy <br> - Joule( J) <br> - Work done or energy used $=$ force $x$ distance moved <br> - Sun ,fire, electric bulb <br> - Production of shadows <br> - Sound Energy <br> - vibrations <br> - passing of sound energy through different media 33 | - Carrying out experiments to demonstrate Work done = Energy used <br> - Solving problems on work done and energy used <br> - observing sources of light <br> - carrying out experiments to demonstrate that light travels in a straight line (production of shadows) <br> - Producing sound using musical instruments <br> - Conducting a bell jar experiment to show that sound requires a material medium for transmission | - force meter <br> - object <br> - ruler <br> - bulb, torch, fire, candle, sun <br> - light source, slits screen <br> - ball <br> - Multimedia \& Braille/Jaws software <br> - musical instruments <br> - Tuning fork <br> - bell jar <br> - vacuum pump <br> - electric bell |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.6.6 MAGNETISM <br> AND <br> ELECTRICITY | - describe properties of magnets <br> - state the law of magnetism <br> - draw magnetic fields <br> - define current and voltage <br> - state the S.I units of current and voltage <br> - measure current and voltage <br> - determine electrical power | - Polarity, field direction and strength <br> - Attraction, repulsion, like and unlike poles <br> - Magnetic fields <br> - Current: ampere (A) <br> Voltage: volt (V) <br> - Power $=$ Current $x$ Voltage | - Illustrating properties of magnets <br> - Carrying out experiments using magnets <br> - Demonstrating magnetic fields <br> - Discussing the meaning of current and voltage <br> - Carrying out experiments to measure current and voltage <br> - Calculating electrical power | - string, compass <br> - bar magnets <br> - iron filings, magnets, plain paper <br> - Ammeter <br> - Voltmeter <br> - Circuit boards <br> - Connecting wires <br> - Light bulbs |

# 8.7 BIOLOGY 

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED <br> RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.7.1 STRUCTURE AND FUNCTION OF A CELL | - identify specialized cells <br> - draw and label specialised cells <br> - state the function(s) of the specialised cells in relation to structure <br> - use a microscope to observe cell structure | - Specialised cells -red blood cell -muscle cell -palisade cell -root hair cell <br> - Functions of specialised cells | - Drawing specialised cell structures <br> - Using a microscope/bioviewer to observe specialized cell <br> (Identification of parts of a microscope not necessary Avoid using fresh, animal cells) | - Microscope <br> - Charts <br> - Bio-viewers <br> - Bio-sets <br> - Printed Multimedia \& Braille/Jaws software <br> - ICT tools \& Braille/Jaws software <br> - Prepared slides |
| 8.7.2 NUTRITION <br> Factors affecting the rate of photosynthesis | - State factors which affect photosynthesis <br> - describe experiments on factors which affect | - Water, light ,carbon dioxide, chlorophyll | - Investigating factors affecting rate of photosynthesis <br> - Testing for starch in a leaf | - Iodine solution <br> - Leaves <br> - Glowing splint <br> - Light source <br> - Pond weed |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED <br> RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | photosynthesis <br> - describe the fate of end products of photosynthesis <br> - identify parts of the internal structure of a leaf <br> - describe how the leaf is adapted for photosynthesis | - Carbohydrates and oxygen <br> - Translocation, storage and structure formation, respiration <br> - Epidermis, stomata, vascular tissue, mesophyll, guard cells <br> - Surface area, stomata, palisade cells, air spaces. | - Testing for oxygen using a glowing splint <br> - Observing the internal leaf structure using a bio- viewer/microscope <br> - Examining the external leaf structure | - Sodium hydrogen carbonate/Soda lime/Sodium hydroxide <br> - Microscope <br> - Bio-viewer <br> - ICT tools \& Braille/Jaws software |
| 8.7.3 HUMAN <br> NUTRITION <br> Alimentary canal | - draw and label parts of the alimentary canal and associated organs | - Mouth, oesophagus stomach, small and large intestines, gall bladder, pancreas, liver | - Watching video simulation to examine human alimentary canal | - ICT tools \& Braille/Jaws software <br> - Model of human alimentary canal |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - identify parts of the alimentary canal of a human <br> - state the functions of parts of the alimentary canal of a human | - Ingestion, digestion, absorption, assimilation and egestion | - Identifying parts using a chart |  |
| 8.7.3 NUTRITION | - Name types of teeth and their functions <br> - Describe mechanical and chemical | - Incisor <br> -cutting <br> -biting <br> - Canines <br> -tearing <br> -gripping <br> - Premolar and molar -grinding <br> Chewing <br> - Mechanical | - Discussing the functions of teeth and their structure <br> - Observing types of teeth on the skeleton models <br> - Using a model to examine action of amylase on starch <br> - Discussing | - ICT tools \& Braille/Jaws software <br> - Skeleton model <br> - Visking tubing/egg shell |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | digestion <br> - Explain the importance of digestion <br> - Describe the function of a typical enzymes (amylase) <br> - Identify the end products of digestion | digestion - breaking down of food into smaller pieces <br> - chemical digestion use of enzymes to convert food from insoluble to soluble molecules <br> - Increase surface area for enzyme action and solubility <br> - Catalysis for conversion of starch to maltose/glucose <br> - Carbohydrates: glucose <br> - Protein: amino acids <br> - Fats: fatty acids and glycerol | mechanical and chemical digestion <br> - Demonstrating increase in surface area when a solid is broken into smaller pieces <br> - Experimenting using enzymes on different food substrates <br> - Testing for glucose, proteins and fats | - amylase powder <br> - protease <br> - pepsin <br> - Catalase (use potato or fresh liver <br> - Food samples <br> - Reagents for food testing |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.7.4 <br> RESPIRATORY <br> SYSTEMS <br> Gaseous exchange in alveoli | - state the differences between inhaled and exhaled air <br> - describe the role of the alveoli in gaseous exchange <br> - explain how the alveolus is adapted for gaseous exchange | - Percentage composition of inhaled and exhaled air <br> - Diffusion of carbon dioxide and oxygen <br> - Adaptations-1 cell thick, moist, large surface area, network of blood capillaries | - Carrying out an experiment to show the change in proportions of carbon dioxide and oxygen in inhaled and exhaled air <br> - Describing gaseous exchange in the alveoli <br> - Discussing adaptations | - ICT tools <br> - Braille/Jaws software <br> - Limewater/bicarbonate indicator solution <br> - Model of alveoli |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.7.5 TRANSPORT <br> SYSTEMS <br> Transpiration | - explain the process of transpiration <br> - state factors affecting the rate of transpiration <br> - measure transpiration in a plant <br> - outline the importance of transpiration | - Water loss in plants <br> - Wind speed, temperature, humidity, surface area, light intensity, number of stomata <br> - Use of a potometer <br> - Water and mineral salts uptake, cooling the plant | - Discussing the process of transpiration <br> - Carrying out experiments to investigate factors affecting the rate of transpiration <br> - Explaining the importance of transpiration | - ICT tools \& Braille/Jaws software <br> - Potometer |
| 8.7.6 Plasmolysis and turgidity | - explain the terms plasmolysis and turgidity <br> - describe the effects of water loss and water gain in plant cells | - Plasmolysis <br> - Turgidity | - Discussing plasmolysis and turgidity <br> - Watching video simulations on plasmolysis and turgidity <br> - carrying out | - ICT tools \& Braille/Jaws software <br> - Potato strips <br> - Visking tubing |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | experiments to demonstrate plasmolysis and turgidity using potato strips |  |
| 8.7.7 Blood circulation | - describe the double circulatory system | - Human blood circulatory system | - Watching video simulations on the blood circulatory system <br> - Examining model of human circulatory system | - Multimedia \& Braille/Jaws software <br> - Circulatory System Model |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.7.8 <br> REPRODUCTIVE <br> SYSTEMS IN <br> PLANTS <br> Wind and insect pollinated flowers | - explain the structures of wind and insect pollinated flowers | - Wind pollinated flower <br> - Insect pollinated flower | - Examining the structure of wind and insect pollinated flower <br> - Drawing the structures of wind and insect pollinated flower | - Plant specimen <br> - Multimedia \& Braille/Jaws software |
| 8.7.9 Germination | - describe the process of germination <br> - investigate conditions necessary for germination <br> - calculate percentage germination | - Germination <br> - Moisture, warmth, oxygen <br> - Percentage germination | - Discussing the process of germination <br> - Carrying out experiments to demonstrate conditions necessary for germination <br> - Determining germination percentage | - Seeds <br> - Multi-media |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.7.10 Reproductive systems | - state the functions of the male and female reproductive system <br> - describe the structure and functions of sex cells <br> - draw and label the sex cells <br> - describe the route of the sperm from the testis to the ovum after ovulation <br> - define fertilisation <br> - describe the menstrual cycle | - male and female reproductive system <br> - functions <br> - Sperm and ovum <br> - Epididymis, testis, sperm duct, urethra, vagina, cervix, uterus, oviduct, <br> - Hormones i.e. progesterone, oestrogen <br> - Ovulation <br> - Menstruation | - drawing the male and female reproductive systems <br> - Drawing the structure of sex cells <br> - Illustrating the menstrual cycle | - models of reproductive organs <br> - ICT tools \& Braille/Jaws software <br> - Multimedia \& Braille/Jaws software <br> - Bio-viewers <br> - Multi-media |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - describe the role of the placenta <br> - identify the substances exchanged in the placenta | - Placenta <br> - Nutrients, wastes, antibodies, oxygen | - Watching video simulations of the placenta <br> - Listing the substances exchanged in the placenta | - Multi-media |
| 8.7.11 HEALTH AND DISEASES | - list sexually transmitted infections (STIs) <br> - describe the signs, symptoms and effects of : <br> Gonorrhoea, Syphilis, <br> Chancroid, Genital herpes <br> - state the causative agents of: <br> Gonorrhoea, Syphilis, | - Gonorrhoea <br> - Syphilis <br> - Chancroid <br> - Genital herpes | - Discussing STIs <br> - Identifying the sign, symptoms and effects of STIs <br> - Watching videos on signs and symptoms of STIs <br> - Listing the causes | - Bio-viewers <br> - Multi-media |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | Chancroid, Genital herpes <br> - state the control methods and treatment <br> - describe the signs and symptoms of malaria, typhoid, Ebola and cholera <br> - state the cause of malaria, typhoid, Ebola and cholera <br> - explain how the diseases are treated <br> - describe the effects of tobacco smoking on health | - Pathogens <br> -virus <br> -bacteria <br> - Abstinence, condoms, contact tracing <br> - Malaria <br> - Typhoid <br> - Ebola <br> - Cholera <br> Plasmodium, bacteria, virus <br> - Emphysema, bronchitis, lung cancer, low birth | - Using charts on the signs and symptoms <br> - Discussing the causes <br> - Outlining the disease control methods <br> - Discussing the effects of smoking | - Print media <br> - Multi-media |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - describe effects of excessive consumption of alcohol <br> - explain effects of use of mandrax and cannabis <br> - outline the effects of breathing solvents | weight <br> - Liver cirrhosis, social implications, reduced reaction time <br> - Hallucinations, addiction <br> - Damaged muscles, heart and addiction | - Identifying effects of excessive alcohol consumption <br> - Listing effects of mandrax and cannabis <br> - Explaining effects of breathing solutions |  |

# 8.8 PHYSICS 

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.8.1 DATA <br> PRESENTATION | - Construct a pie chart <br> - Interpret and | - pie charts and line graphs | - explaining data presented in form of pie chart | - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | analyse data from pie charts and line graphs |  | and line graphs |  |
| 8.8.2 MEASUREMENT <br> Physical quantity | - measure physical quantities accurately using appropriate instruments <br> - read instruments scale to the nearest fraction of the division <br> - determine density of liquids | - Measurement of physical quantities: length (thickness and internal diameter) current, voltage <br> - Density: liquids | - Measuring length, current, voltage <br> - Determining density of liquids experimentally | - Vernier callipers <br> - Voltmeter <br> - Ammeter <br> - Measuring cylinder <br> - Micrometre screw gauge <br> - Balance <br> - Multimedia \& Braille/Jaws software |
| 8.8.3 FORCE <br> Weight/mass | - define weight, momentum and inertia <br> - distinguish between | - Weight, <br> - Momentum <br> - Inertia | - Defining weight, momentum and inertia | - Spring balances <br> - Trolleys <br> - Ticker timer |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | weight and mass <br> - state Newton's laws of motion <br> - calculate force, given mass and acceleration <br> - state application of Newton's laws of motion | - force $=$ mass $x$ acceleration <br> - inertia <br> - $F=\mathrm{ma}$ | - Discussing Newton's laws of motion limited to linear motion <br> - Verifying Newton's second law of motion experimentally |  |
| 8.8.4 Machines | - describe the uses and applications of machines <br> - determine Mechanical Advantage (MA), Velocity Ratio (VR) and efficiency of levers inclined plane, | - Simple machines: Levers, pulley system, inclined plane, gears <br> - Mechanical advantage, velocity ratio and efficiency | - Lifting different loads using the simple machines <br> - Carrying out experiments to determine MA, VR and efficiency <br> - Calculating | - Crow bar <br> - Wheel barrow <br> - Scissors <br> - Pulleys <br> - Inclined plane <br> - Gears |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | pulleys and gears <br> - explain energy losses in machines <br> - describe ways of improving efficiency in machines | - Friction and mass of moving parts <br> - Lubrication, bearings and mass reduction | mechanical advantage and velocity ratio of the simple machines <br> - Demonstrating effects of lubrication, bearings and mass reduction on efficiency | - Bearings |
| 8.8.5 Petrol and diesel engines | - describe the operation of a four stroke petrol and diesel engine <br> - explain the role of the fuel injector and carburettor | - refer to old engines <br> - Strokes: intake compression, power and exhaust <br> - Fuel and air supply <br> - Ignition methods, efficiency, carbon monoxide production | - Demonstrating intake, compression, power and exhaust using an engine model <br> - Explaining how the fuel injector and the carburettor works and their importance <br> - Examining the ignition and fuel | - Model of a four stroke petrol engine <br> - Engine block <br> - Fuel injector <br> - Car engines |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - describe the operation of a modern petrol and diesel engine <br> - outline the advantages of modern petrol engines over old petrol engines | - Petrol fuel injectors: intake, compression, power, exhaust. <br> - Modern diesel engine <br> - Fast start, efficiency | economy of petrol and diesel engine <br> - Field tour to a modern garage | - Model of a modern petrol engine <br> - Model of a modern diesel engine <br> - Modern garage |
| 8.8.6 ENERGY <br> heat transfer | - give an account of heat transfer <br> - explain convection in terms of the kinetic theory of matters | - conduction, good and bad conductors <br> - convection in liquids and gases | - carrying out experiments with metal and non-metal rods <br> - demonstrating heat movement in liquids and gases <br> - carrying out | - iron <br> - copper <br> - aluminium <br> - wood <br> - glass |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - state good and bad reflectors, absorbers and emitters of heat | - good and bad reflectors, absorbers and emitters of heat | experiments on absorption, emission and reflection of heat using different surfaces | - smoke chamber <br> - copper sulphate crystals <br> - black painted surface <br> - white painted and shiny surfaces |
| 8.8.7 <br> Electromagnetism | - Describe an experiment to demonstrate that a current carrying conductor has a magnetic field around it. | - Magnetic field patterns of long straight conductor, solenoid | - Demonstrating magnetic field around a current carrying conductor, using iron filings and magnetic compass | - Copper wire <br> - Iron filings <br> - Source of d.c <br> - magnetic compass |
| 8.8.8 Motor effect | - Illustrate how movement is produced in a current carrying wire in a magnetic field | - Motor effect: Interaction of magnetic fields, electrical energy converted to kinetic energy, motion | - Carrying out an experiment using a current carrying wire between magnets | - Copper coil, source of d.c <br> - magnets |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - describe the operation of a direct current(d.c) motor <br> - state the factors that affect the rotation of the coil | - electrical to mechanical energy <br> - strength of magnetic field <br> - number of turns in the coil <br> - amount of current passed <br> - number of turns of the coil | - constructing and operating an electric motor <br> - use of iron core | - electric motor <br> - model of a motor |
| 8.8.9 Generator effect | - describe an experiment which shows that a change in magnetic field can induce an electro motive force (e.m.f) in a conductor | - the generator principle, magnetic field, electric field and e.m.f | - carrying out an experiment which illustrates the generator effect | - copper coil <br> - galvanometer <br> - magnet <br> - source of d.c |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - state the factors which affect the magnitude of induced e.m.f <br> - describe the operation of an alternating current(a.c) and direct current(d.c) generator | - strength of a magnet, relative motion, number of turns and area of coil <br> - mechanical energy to electrical energy | - carrying out experiments to investigate factors which affect the magnitude of induced e.m.f. <br> - illustrating output voltage graphically <br> - discussing factors affecting output voltage | - magnets of different strengths <br> - coils of different turns <br> - coils of different area <br> - a.c generator <br> - d.c generator <br> - Multimedia \& Braille/Jaws software |
| 8.8.10 STATIC <br> ELECTRICITY <br> Electroscope | - Describe simple experiments to show electrostatic charging using an electroscope <br> - Describe forces between charges | - Electron, positive and negative charges <br> - like and unlike charges | - Demonstrating electrostatic charging <br> - Demonstrating attraction and repulsion of charges using an electroscope | - Electroscope: gold leaf, aluminium foil, iron nail |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  |  |  |
| 8.8.11 Lightning conductor | - describe the production of lightning <br> - Explain the principle of a lightning conductor <br> - state the dangers of lightning <br> - state safety precaution against lightning | - Movement of charges between cloud and ground <br> - Height, conduction and earthing <br> - High voltage electrocution heating effect | - Discussing the production of lightning <br> - Erecting a lightning conductor <br> - Discussing dangers of lightning <br> - Demystify myths on lightning - wearing red clothes | - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.8.12 CURRENT <br> ELECTRICITY <br> Ohm's law | - state Ohm's law <br> - calculate resistance /voltage/current using Ohm's law <br> - describe an experiment to determine resistance <br> - state the limitations of Ohm's law <br> - state factors that affect resistance | - Ohm's law <br> - $\mathrm{V}=\mathrm{R}$ <br> - resistance <br> - limitation of Ohm's law: temperature <br> - factors that affect resistance: length of wire, thickness (cross sectional area) | - Carrying out experiments to verify Ohm's law <br> - Carrying out calculations using Ohm's law <br> - determining resistance experimentally using a voltmeter and an ammeter | - Voltmeter <br> - Ammeter <br> - Bulbs <br> - Resistors <br> - different conducting materials |
| 8.8.13 Resistors | - construct simple electric circuits <br> - draw and interpret circuit diagrams | - simple electric circuits: cells, switches, resistors, variable resistors, bulbs ammeter, | - setting up practical electric circuits <br> - drawing and interpreting circuit | - cells <br> - resistors <br> - switches |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - calculate resistance in simple circuits | voltmeter and fuses <br> - series and parallel arrangement of resistors <br> - $R_{\text {total }}=R_{1}+R_{2}+R_{3}+\ldots$ <br> $\frac{1}{R \text { total }} \frac{1}{R 1}+\frac{1}{R 2}+\frac{1}{R 3}+\ldots$ | diagrams <br> - determining total resistance of resistors in series and parallel arrangement | - bulbs <br> - fuses <br> - ammeters <br> - voltmeters <br> - leads <br> - Resistors connected in series and parallel |

| TOPIC | OBJECTIVES <br> Learners should be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.8.14 Electrical power and energy | - Define electrical power and energy <br> - Calculate electrical power and energy | - Power and energy <br> - Units: <br> - watt (W), kilowatthour ( kWh ) <br> $\mathrm{P}=\mathrm{VI}$ <br> $\mathrm{E}=\mathrm{Vlt}$ | - Discussing electrical power and energy use by appliances <br> - Determining power and energy using the formulae | - Electric iron <br> - Electric fan <br> - Heating elements <br> - Smart phones <br> - computers <br> - Multimedia \& Braille/Jaws software |

8.9 CHEMISTRY

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.9.1 <br> SEPARATION | - describe the processes of distillation and fractional distillation | - distillation and $f$ racional distillation | - demonstrating distillation of impure water and fractional distillation of dilute ethanol <br> - discussing fractional distillation of air | - ethanol <br> - distillation unit <br> - fractional distillation unit <br> - charts |
| 8.9.2 MATTER | - define relative <br> mass/mass number <br> - define the proton number/atomic number <br> - calculate the number of neutrons from given data | - nuclide notation ${ }_{6}^{a} x$ <br> - Isotopes: <br> ${ }^{16} \mathrm{O}$ and ${ }^{18} \mathrm{O}$ <br> ${ }^{35} \mathrm{Cl}$ and ${ }^{37} \mathrm{Cl}$ <br> ${ }^{12} \mathrm{C}$ and ${ }^{14} \mathrm{C}$ <br> - Proton, neutrons | - Calculating molecular masses <br> - Calculating empirical formula <br> Calculating concentration of solutions <br> - Explaining relative mass/mass number | - Periodic Table chart <br> - Computer simulation of atomic structure <br> - Magnesium ribbon <br> - Lead nitrate, HCl , <br> - Barium nitrate, <br> - Silver nitrate |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - name the sub-atomic particles <br> - state the relative charges and masses of subatomic particles <br> - state relative position of sub-atomic particles within the atom <br> - name the first 20 elements in the periodic table stating their symbols <br> - write the electronic configuration of the first 20 elements <br> - describe ionic and covalent bonding | and electrons <br> - Structure of an atom: nucleus, electron shells <br> - Metals and non metals <br> - Electronic configurations <br> - Bonding <br> - Ionic bonding: $\mathrm{NaCl}, \mathrm{MgO}$, $\mathrm{Na}_{2} \mathrm{O}$ <br> - Covalent bonding: $\mathrm{H}_{2}, \mathrm{Cl}_{2}, \mathrm{H}_{2} \mathrm{O}$ | using models <br> - Defining isotopes | - Periodic Table chart <br> - Computer simulation of atomic structure <br> - Magnesium ribbon <br> - Lead nitrate, $\mathrm{HCO}, \mathrm{H}_{2} \mathrm{SO}_{4}$ <br> - Barium nitrate <br> - Silver nitrate |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED <br> ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - Define the Avogadro number <br> - State the relationship between the mole and molecular mass (Mr) or atomic mass (Ar) <br> - Calculate empirical formula and molecular mass <br> - Calculate concentration of solutions in mole/dm ${ }^{3}$ and $\mathrm{g} / \mathrm{dm}^{3}$ | - Avogadro number <br> - Mole concept <br> - $\mathrm{n}=\mathrm{m} / \mathrm{Mr}$ <br> - Empirical formula and molecular formula from percentage composition data <br> - Concentration | - Stating Avogadro constant <br> - Calculating molecular masses <br> - Calculating empirical formula <br> - Calculating concentration of solutions | - Models/use of marble to demonstrate moles |
| 8.9.3 <br> ACIDS,BASES <br> AND SALTS | - identify the regions of acidity neutrality and alkalinity of substance on the pH scale and using universal indicator | - The pH scale <br> - Use of universal indicator solution | - Drawing the pH scale <br> - Carrying out experiments using universal indicator to | - pH scale chart <br> - Universal indicator solution <br> - Ammonia solution, |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED <br> ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | solution <br> - describe the reactions of acids with metal and bases <br> - write word and chemical equations for reactions | - Reaction of dilute acids with metals, bases and carbonates <br> - neutralization | identify the pH ranges for different substances <br> - Reacting dilute hydrochloric acid, nitric acid and sulphuric acid with magnesium, zinc, calcium carbonate, magnesium carbonate, sodium hydroxide | sodium hydroxide, vinegar/lemon juice, hydrochloric acid, water <br> - Dilute acids <br> - Hydroxides <br> - Metal granules/powder |
| 8.9.4 <br> INDUSTRIAL PROCESSES | - outline the production of nitrogen and oxygen <br> - define electrolysis <br> - label the general components of an electrolytic cell <br> - describe anode and cathode reactions for electrolysis of molten | - Fractional distillation of liquid air <br> - Electrolytic cell: <br> - connecting wires, cathode, anode, battery, electrolyte <br> - Electrolysis of: molten lead bromide | - Discussing the production of nitrogen and oxygen <br> - Setting up an electrolytic cell <br> - Discussing the electrolysis of molten lead bromide | - Flow charts <br> - Battery, electrodes molten lead bromide <br> - Dilute $\mathrm{H}_{2} \mathrm{SO}_{4}$ <br> - Carbon electrodes |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | lead bromide <br> - state observations for the electrolysis of molten lead bromide <br> - describe the electrolysis of water <br> - state the products formed during the electrolysis of water <br> - state the uses of oxygen and hydrogen | - Solid lead and bromine fumes <br> - Electrolysis of Water <br> Electrolyte : dilute $\mathrm{H}_{2} \mathrm{SO}_{4}$ <br> - uses of $\mathrm{H}_{2}$ and $\mathrm{O}_{2}$ | - experimenting on electrolysis of water <br> - Discussing the uses of oxygen and hydrogen |  |
|  | - state the cathode, anode and electrolyte <br> - explain the cathode process <br> - state reasons for electroplating materials | - Copper electroplating an iron nail <br> - Cathode reaction <br> - Prevention of corrosion, decoration | - Setting out experiments to electroplate an iron nail <br> - Identifying electroplated objects | - Iron sheet/nail <br> - Copper sulphate solution <br> - Copper electrode |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.9.5 OXIDATION AND REDUCTION | - define oxidation <br> - define reduction <br> - list the raw materials used in the extraction of iron and their sources <br> - describe reactions in the blast furnace <br> - state the functions of the | - Oxidation: loss of electrons, gain of oxygen, loss of hydrogen <br> - Reduction: gain of electrons, loss of oxygen, gain of hydrogen <br> - Redox reactions <br> - Extraction of iron at ZISCO steel in the blast furnace <br> - Lime stone/calcium carbonate/caco ${ }_{3}$, iron ore/haematite/ $\mathrm{Fe}_{2} \mathrm{O}_{3}$ coke/carbon/C <br> - Reactions in the blast furnace: formation of $\mathrm{CO}_{2}$, | - Demonstrating the reaction of copper oxide with hydrogen <br> - Discussing the extraction process <br> - Visiting ZISCO steel <br> - Heating sample of Iron (III) Oxide on a charcoal block | - Copper oxide <br> - Hydrogen gas <br> - ZISCO steel <br> - Iron oxide <br> - charcoal |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | raw materials <br> - describe how iron and slag separate | formation CO reduction of $\mathrm{Fe}_{2} \mathrm{O}_{3}$, decomposition of $\mathrm{CaCO}_{3}$, formation of slag |  |  |
| 8.9.6 ORGANIC CHEMISTRY | - define the term hydrocarbon <br> - name the members of the homologous series with 3 carbon atoms <br> - draw the displayed structures of methane, ethane, propane, ethene, propene <br> - state uses of methane, ethane, propane, ethene, propene. | - Hydrocarbons: alkanes and alkenes methane ethane propane ethene propene <br> - drawing structures <br> - As fuels and alcohols | - Outlining the structures of methane, ethane, propane, ethene and propene using models | - Models of atoms and bonds |
|  | - outline the production of | - Biogas production: role of bacteria | - Preparing a model of a | - Model of bio digester |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED <br> ACTIVITIES AND <br> NOTES | SUGGESTED <br> RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | biogas <br> - identify factors affecting the production of biogas <br> - state the use of biogas | temperature <br> pH <br> - Fuel | bio digester | - Samples of organic waste (plant and animal waste) |

FORM 4
8.10 BIOLOGY

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.10.1 CELLS AND LEVELS OF ORGANISATION <br> Ecosystems | - explain the term ecosystem <br> - list components of an ecosystem | - Organisms and their environment <br> - Physical and biological components | - Discussing the term ecosystem <br> - Identifying components of an ecosystem <br> - Examining various ecosystems e.g. garden, pond, forest <br> - Engaging in field trips to observe natural ecosystem <br> - Illustrating food chains, food webs and pyramids of biomass <br> - Energy flow | - Multi-media <br> - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | is lost in food chains and food webs <br> - describe the carbon and nitrogen cycles | - Carbon and nitrogen cycles | energy input and energy flow <br> - Explaining the carbon and nitrogen cycles |  |
|  | - describe an artificial ecosystem <br> - explain biodiversity <br> - identify problems caused by limited bio-diversity <br> - state advantages of biodiversity | - Garden, pond and plantation <br> - Bio-diversity <br> - Soil infertility, pests and diseases <br> - Wide variety of food source <br> - Self-sustenance of an ecosystem <br> - Interdependence <br> - Less spread of diseases | - Visiting plantations, pond, garden <br> - Discussing biodiversity <br> - Explaining problems caused by limited biodiversity | - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.10.2 NUTRITION | - Plan a balanced diet meal for different groups of people | - diet for a toddler, adolescent, manual worker and sedentary worker | - Planning balanced meals <br> - Discussing balanced diet | - Food samples <br> - Multimedia \& Braille/Jaws software |
|  | - describe the functions of the components of a balanced diet in the body | - Functions of carbohydrates, fats, proteins, vitamins(A, C, D), mineral salts(iodine, calcium, iron), water, roughage | - Identifying components of a balanced diet <br> - Discussing functions of the nutrients in the body | - Dieticians, <br> - Nutritionists and resource persons |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - Explain malnutrition <br> - explain the term deficiency disease <br> - state causes of deficiency diseases <br> - Describe the tests for starch,simple sugars ,protein and fats | - effects of malnutrition, obesity, anorexia nervosa <br> - Deficiency diseases: Kwashiorkor, goitre, rickets, scurvy, anaemia and night blindness <br> - Food tests | - Discussing diabetes mellitus 2, obesity and anorexia nervosa <br> - Explaining deficiency diseases <br> - Watching videos and pictures of people suffering from deficiency diseases <br> - Listing causes of various deficiency diseases <br> - Carrying out experiments to test for starch,simple sugars, protein and fats <br> - Watching videos on the food tests to observe colour | - lodine solution <br> - Benedict solution/Clinisti $x$ <br> - Ethanol <br> - Sodium hydroxide, copper |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | changes | sulphate/ albustix |
| 8.10.3 Respiratory system | - describe aerobic and anaerobic respiration <br> - state word equations for aerobic and anaerobic respiration | - Aerobic and anaerobic respiration <br> - Word equations: <br> glucose + <br> oxygen $\rightarrow$ carbondioxid <br> e + water + energy <br> - glucose $\rightarrow$ lactic acid + less energy | - Discussing aerobic and anaerobic respiration <br> - Writing down word equation <br> - Carrying out experiments to show release of energy and carbon dioxide from animals and germinating seeds. | - Multimedia \& Braille/Jaws software <br> - Small animals such as frogs to be returned to their natural environment <br> - Germinating seeds |
| 8.10.4 TRANSPORT <br> SYSTEMS: | - describe adaptations of plant leaves to reduce transpiration | - Reduction of surface area, thickness of cuticle, distribution of stomata, presence of hairs | - Discussing adaptations of plant leaves to minimize water loss <br> - Carrying out experiment to demonstrate the | - Potted plant samples <br> - Potometer |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | distribution, role of stomata and water loss <br> - Field touring to identify various types of leaves. Avoid plucking leaves from plants |  |
|  | State the functions of blood <br> - describe the structure of blood vessels <br> - draw and label the structure of blood vessels <br> - Outline the differences among blood vessels. | Transport, defence, homeostasis <br> - Veins, arteries and capillaries <br> - Structure of blood vessels <br> - Lumen, valves ,thickness | - Discussing the structure of blood vessels <br> - Illustrating the structure of veins, capillaries and arteries <br> - Watching video simulations on the structure of blood vessels | - Multimedia \& Braille/Jaws software <br> - Models <br> - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  |  | - Listing the differences among blood vessels |  |
| 8.10.5 REPRODUCTIVE SYSTEM | - explain asexual reproduction in plants <br> - identify methods of asexual reproduction in plants <br> - state advantages and disadvantages of asexual reproduction <br> - outline the differences between sexual and asexual reproduction in plants | - Asexual/vegetative reproduction <br> - Methods of asexual reproduction: rhizomes, cuttings, tubers <br> - Advantages and disadvantages of asexual reproduction <br> - Differences between sexual and asexual reproduction | - Discussing asexual reproduction in plants <br> - Listing methods of asexual reproduction <br> - Identifying advantages and disadvantages of asexual reproduction <br> - Listing differences between sexual and asexual reproduction | - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - describe methods of contraception <br> - advantages and disadvantages of different methods | - Natural methods, barrier methods, hormonal methods and spermicides | - Discussing contraceptive methods, <br> - Stating examples <br> - Identifying advantages and disadvantages | - Pictures <br> - Samples <br> - Multimedia \& Braille/Jaws software |
| 8.10.6 HEALTH AND DISEASES | - explain the term immunity <br> - describe passive, active, natural and artificial immunity <br> - explain how infants acquire immunity | - Immunity <br> - Passive, active, natural and artificial immunity <br> - Breastfeeding, immunisation schedule | - Discussing immunity <br> - Identifying different types of immunity <br> - Discussing how infants acquire immunity | - Resource persons <br> - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - describe how HIV/AIDS is spread <br> - describe effects of HIV on the body <br> - explain how the spread of HIV/AIDS can be controlled <br> - describe the life cycle of malaria parasite <br> - describe methods of controlling malaria | - HIV/AIDS <br> - Inability to resist infection <br> - Methods of controlling the spread of HIV/AIDS <br> - Life cycle of malaria parasite in humans and in anopheles mosquito <br> - Methods of controlling malaria | - Discussing the spread of HIV/AIDS <br> - Explaining effects of HIV on the body <br> - Discussing methods of controlling the spread of HIV/AIDS <br> - Discussing methods of controlling anopheles mosquito at its different developmental stages | - Resource persons <br> - Multimedia \& Braille/Jaws software |

# 8.11 CHEMISTRY 

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.11.1 <br> SEPARATION | - Describe paper chromatography <br> - State the application of paper chromatography | - Paper chromatography: solvent, mixture of dyes, solvent front, initial position of dye and solvent, <br> - Separation of dyes/extracts from plants, | - Carrying out an experiment to separate mixtures in dyes and plant extracts using paper chromatography | - Filter paper <br> - Thin Layer Chromatography paper <br> - Benzene <br> - Toluene <br> - Plant extracts |
| 8.11.2 MATTER | - Describe the properties of group I, II, VII and VIII <br> - State the use of halogens <br> - Describe the reactions of metals with water, steam, air and dilute acids <br> - Write equations for the reaction of metals with oxygen, dilute acids and water | - Physical and chemical properties of group I, II, VII and VIII <br> - Uses of halogens <br> - Reactivity series | - Carrying out experiments to react magnesium, iron, zinc and copper, lead with air, water/steam and dilute acids | - Metals <br> - Dilute acids <br> - Multimedia \& Braille/Jaws software |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | - List metals in order of decreasing reactivity <br> - Predict the reactivity of a metal from its position in the reactivity series |  |  |  |
| 8.11.3 ACIDS, <br> SALTS AND <br> BASES | - Identify apparatus used in a titration <br> - Describe an acid /base titration procedure <br> - Carry out acid - base titration | - Acid-base titrations | - Titrating dilute sodium hydroxide against hydrochloric acid | - Dilute acids <br> - $\mathrm{NaOH}_{(\text {(aq) }}$ <br> - Phenolphthalein |
| 8.11.4 <br> INDUSTRIAL PROCESSES <br> Haber | - List the raw materials used to manufacture ammonia <br> - Describe the manufacture of ammonia <br> - State the conditions | - Haber Process <br> - Raw materials: <br> -Hydrogen from electrolysis of water <br> -Nitrogen from fractional distillation of air <br> - Pressure:200atm | - Describing the Haber process <br> - Conducting educational tours to Sable Chemicals | - Flow chart of the Haber Process |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| Contact | needed for the production of ammonia <br> - State the industrial uses of ammonia <br> - List the raw materials used to manufacture sulphuric acid <br> - Describe the manufacture of sulphuric acid <br> - State the conditions needed for the production of sulphuric acid <br> - State uses of sulphuric acid | - Catalyst: Iron <br> - Temperature: $450^{\circ} \mathrm{C}-$ $500^{\circ} \mathrm{C}$ <br> - Uses of ammonia: manufacture of ammonium nitrate, dyes <br> - Contact process <br> - Raw materials: sulphur dioxide from burning iron pyrites/sulphur, oxygen from air <br> - Pressure: 1 atm <br> - Uses of sulphuric acid: battery acid, plastics, cleaning materials before electroplating <br> - Catalyst: vanadium(V) Oxide <br> - Temperature: $450^{\circ} \mathrm{C}-$ $500^{\circ} \mathrm{C}$ | - Describing the production of ammonium nitrate through acid-base titration <br> Discussing the contact process | Multimedia \& Braille/Jaws software <br> Ammonia solution <br> Nitric acid <br> Titration materials |
| 8.11.5 <br> OXIDATION AND | - List down alloys of iron <br> - State the percentage | - Alloy formation <br> - mild steel | - Discussing the uses of alloys of iron | - Mild steel |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| REDUCTION | composition of alloys of iron <br> - Explain the uses and properties of alloys of iron | - stainless steel <br> - cast iron |  | - Stainless steel utensils <br> - Cast iron objects |
| 8.11.6 ORGANIC CHEMISTRY | - State the homologous series to which ethanol belongs <br> - Draw the displayed structural formula of ethanol <br> - Describe the production of concentrated ethanol <br> - List uses of ethanol <br> - <br> - Define the term global warming <br> - List the causes of global warming | - Ethanol <br> - Fermentation <br> - pH <br> - role of yeast <br> - temperature $30^{\circ} \mathrm{C}-35^{\circ} \mathrm{C}$ <br> - Fractional distillation <br> - Beverage, medical purpose, fuel, solvent <br> - Global warming <br> - Combustion <br> - Deforestation | - Fermenting sugar solution and maize meal solution(maheu) <br> - Discussing effects of combustion, veld fires and deforestation | - Sugar solution <br> - Maize meal solutions <br> - Yeast/malt <br> - Fractional distillation apparatus <br> - Multimedia \& Braille/Jaws software |

# 8.12 PHYSICS 

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED <br> ACTIVITIES AND NOTES | SUGGESTED <br> RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
| 8.12.1 <br> DATAPRESENTATION <br> 8.12.2 <br> MEASUREMENTS | - construct, interpret and analyse pie charts and line graphs <br> - Express derived quantities in terms of base units | - pie charts and line graphs <br> - Derived units <br> - SI units <br> - newton, joule, watt, volts, ampere | - Constructing pie charts and line graphs <br> - Interpreting and analysing pie charts and line graphs <br> - Expressing derived quantity units in terms of base units | - Graph paper, protractors, compasses, ICT tools \& Braille/Jaws software <br> - Print and electronic media |
| 8.12.3 FORCE | - Define pressure <br> - Calculate pressure <br> - Calculate pressure in fluids <br> - Describe effect of depth on pressure <br> - Describe atmospheric pressure <br> - Describe the | - Pressure $P_{=} F / A$ <br> - Pressure in fluids $P_{=} h \partial g$ <br> - Atmospheric pressure <br> - manometer | - Determining pressure of solid objects <br> - Demonstrating variation of pressure with depths (Refer to structure of dam walls) <br> - Demonstrating atmospheric pressure <br> - Constructing and using | - Solid objects of different crosssectional area <br> - Container with holes at different depth <br> - Water barometer <br> - Oil, water |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED <br> ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | construction and use of a simple manometer |  | a simple manometer to determine fluid pressure |  |
|  | - Explain the function and operation of simple fluid systems | - Fluid system: <br> siphon and hydraulic systems (car braking system and hydraulic jack) | - Demonstrating the operation of a siphon, hydraulic jack and car braking system | Siphon <br> hydraulic jack |
|  | - Describe the structures, functions and operations of simple pumps | - Lift pump:- Blair pump <br> - Force pump: bicycle pump | - Illustrating operation of a Blair pump and a bicycle pump | - Model of a Blair pump <br> - bicycle pump |
| 8.12.4 ENERGY | - Describe the functions and designs of a solar cooker and a solar | - Solar cooker <br> - Solar water heater | - Discussing qualitatively functions and design of a solar cooker and solar water heater | - A curved reflective surface <br> - Black container |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED <br> ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | water heater |  |  | - Water heater |
| 8.12.5 <br> TELECOMMUNICATION | - Describe communication over a distance cell phone and email <br> - List down types of media for signal transmission <br> - Describe how signal is transmitted in different media transmitters <br> - Describe operations of cell phones and related signal transmitters and receivers | - Transmission, decoding receiver <br> - Energy conversions <br> - Optic fibre, coaxial cables, WI-FI, sheathed pair cables | - Discussing communication over a distance <br> - Discussion on process of signal transmission in cables and WI-FI <br> - Examining signal transmitter cables <br> - Tours to internet service providers and telecommunication companies | - ICT gadgets <br> - |
| 8.12.6 MAGNETISM | - describe hydro and thermal power | - hydro and thermal power generation | - Outlining the energy conversions involved in | - Model hydro and thermal |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED <br> ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  | generation |  | hydro and thermal power generation <br> - field trips to hydro and thermal power stations | power generations |
| 8.12.7 ELECTRICITY | - Describe electrical hazards and safety precautions <br> - Describe wiring of a three pin plug <br> - Explain the use of a two pin plug | - Hazards safety precautions <br> - Hazards:Damaged insulation, overheating cables, damp conditions <br> - Safety precautions: <br> earthing, avoid overloading circuits, use insulated cables, do not handle appliance with wet hands, put on rubber footwear when using appliances <br> - live wire, neutral | - Discussing the hazards and safety precautions <br> - Wiring a three pin plug practically <br> - Identifying appliances that use the two pin plug <br> - Examining appliances with double insulation <br> - Demonstrating the operation of a fuse and switch | - Charts <br> - Three pin plug, fuse <br> - Radio, <br> - Different fuse ratings <br> - Switches <br> - Three pin plug <br> - Two pin plug |

| TOPIC | OBJECTIVES <br> Learners will be able to: | CONTENT | SUGGESTED ACTIVITIES AND NOTES | SUGGESTED RESOURCES |
| :--: | :--: | :--: | :--: | :--: |
|  |  | wire, earth wire, fuse, colour codes <br> - Two pin plug, double insulation of appliances |  |  |
|  | - state uses of electricity in the home <br> - Calculate cost of electricity <br> - Discuss different methods of saving electricity <br> - Explain the use of solar photo voltaic systems | - Heating <br> - Lighting <br> - Powering electrical devices <br> - Meter reading costs per unit <br> - Energy saving bulbs, solar panels, biogas <br> - Alternative sources of energy, switch off appliances not in use <br> - low power rating appliances <br> - solar photo voltaic cells | - Discussing uses of electricity in the home <br> - Reading of electricity meter, determining the costs of electricity used <br> - Discussing ways of saving electricity <br> - Discussing the use of solar systems as alternative sources of energy in homes | - Electrical appliances used in the home e.g. electric jug, iron, welding machines, TV, cake mixers <br> - Energy saving bulbs, other bulbs <br> - Photovoltaic cells |

## Combined Science (Form 1 - 4) Syllabus 8.0 ASSESSMENT

### 9.1 ASSESSMENT OBJECTIVES

The scheme of assessment is grounded in the principle of inclusivity and equalisation of opportunities hence does not condone direct or indirect discrimination of learners.

Modifications of arrangements to accommodate candidates with special needs must be put in both continuous and summative assessments. These modifications must neither give these candidates an undue advantage over others nor compromise the standards being assessed.

### 9.2 Scheme of Assessment

Forms 1 to 4 Combined Science assessment will be based on $35 \%$ continuous assessment and $65 \%$ summative assessment.

The syllabus' scheme of assessment is grounded in the principle of equalisation of opportunities hence does not condone direct or indirect discrimination of learners.

Arrangements, accommodations and modifications must be visible in both continuous and summative assessments to enable candidates with special needs to access assessments and receive accurate performance measurement of their abilities. Access arrangements must neither give these candidates an undue advantage over others nor compromise the standards being assessed.

Candidates who are unable to access the assessments of any component or part of component due to disability (transitory or permanent) may be eligible to receive an award based on the assessment they would have taken.
NB For further details on arrangements, accommodations and modifications refer to the assessment procedure booklet.

### 8.2 Continuous Assessment

Continuous assessment for Forms 1 - 4 will consist of practical tests, written tests and end of term examinations:

### 8.2.1 Practical tests

These are practical tests that teachers give to learners once a month. These may be individual or group activities. The tests should cover manipulation of apparatus, following procedures, results collection, presentation, analysis and evaluation.

### 8.2.2 Written Tests

These are tests set by the teacher to assess the concepts covered during a month. The tests should consist of multiple choice, structured and free response questions.

### 8.2.3 End of term examinations

These are comprehensive tests of the whole term/s or year's work. These can be set at school/district/ provincial level.

## Summary of Continuous Assessment Tasks

In Terms 1 to 11, candidates are expected to have done at least the following recorded tasks per term:

- 2 Practical tests
- 2 Written tests
- 1 End of term test

Detailed Continuous Assessment Tasks Table

| Term | Practical tests | Written Tests | End Of Term Test | Total |
| :-- | :-- | :-- | :-- | :-- |
| 1 | 2 | 2 | 1 |  |
| 2 | 2 | 2 | 1 |  |
| 3 | 2 | 2 | 1 |  |
| 4 | 2 | 2 | 1 |  |
| 5 | 2 | 2 | 1 |  |
| 6 | 2 | 2 | 1 |  |
| 7 | 2 | 2 | 1 |  |
| 8 | 2 | 2 | 1 |  |
| 9 | 2 | 2 | 1 |  |
| 10 | 2 | 2 | 1 |  |
| 11 | 2 | 2 | 1 |  |
| 12 | National <br> Examinations |  |  |  |
| Weighting | $15 \%$ | $10 \%$ | $10 \%$ | $35 \%$ |

## Combined Science (Form 1 - 4) Syllabus 8.3 SUMMATIVE ASSESSMENT

## ASSESSMENT OBJECTIVES

The following objectives reflect those aspects of the aims that will be assessed. Specific behavioural learning objectives are stated in each section of the syllabus.

### 8.3.1 KNOWLEDGE AND COMPREHENSION

Learners should be able to demonstrate knowledge and understanding of:
1.1 scientific instruments and apparatus, techniques and aspects of safety;
1.2 scientific units, terminology, symbols an conventions;
1.3 scientific quantities and how they are determined;
1.4 scientific phenomena, facts and laws, definitions, concepts, theories and models;
1.5 personal, social, economic and environmental implications of science applications.

### 8.3.2 HANDLING INFORMATION AND SOLVING PROBLEMS

Learners should be able to demonstrate, in familiar and unfamiliar situations, their ability to:
2.1 extract information relevant to a particular context from data presented in diagrammatic, symbolic, graphical, numerical or verbal form;
2.2 use data to recognize patterns, formulate hypotheses and draw conclusions;
2.3 translate information from one form to another;
2.4 communicate logically and concisely;
2.5 explain facts, observations and phenomena in terms of scientific laws, theories and models;
2.6 explain technological applications of science and evaluate their associated personal, social, economic, and environmental implications;
2.7 make logical decisions based on the examination of evidence and arguments;
2.8 apply scientific principles, formulae and methods to solve qualitative and quantitative problems;
2.9 suggest explanations of unfamiliar facts, observations and phenomenal

### 8.3.3 EXPERIMENTAL SKILLS

Learners should be able to:
3.1 follow instructions for practical work; plan, organise and carry out experimental investigations;
3.3 select appropriate apparatus and materials for experimental work;
3.4 use apparatus and materials effectively and safely;
3.5 make accurate, systematic observations and meas urements, recognising the variability of experimental measurements;
3.6 observe, measure and record results of experimental procedures;
3.7 identify possible sources of error in experimental procedures;
3.8 draw conclusions and make generalisations from experiments;
3.9 extract information from data presented in diagrammatic, graphical or numerical form.

WEIGHTING OF ASSESSMENT OBJECTIVES

|  | ASSEMENT OBJECTIVES | WEIGHTING |
| :-- | :-- | :-- |
| Paper 1 and 2 |  |  |
| Knowledge and comprehension | $\mathbf{1 . 0}$ | $\mathbf{6 0 \%}$ |
| Handling information and solving problems | $\mathbf{2 . 0}$ | $\mathbf{4 0 \%}$ |
| Paper 3 |  |  |
| Experimental skills | $\mathbf{3 . 0}$ | $\mathbf{1 0 0 \%}$ |


| Paper | Type of paper | Duration | Marks | Weighting |
| :-- | :-- | :-- | :-- | :-- |
| $\mathbf{1}$ | Multiple choice | 1 Hour | 40 | $30 \%$ |
| $\mathbf{2}$ | Theory | 2 Hours | 100 | $40 \%$ |
| $\mathbf{3}$ | Practical | 1 Hour 30 minutes | 40 | $30 \%$ |

# Combined Science (Form 1 - 4) Syllabus 

## Paper 1 Theory (1 hour, 40 marks)

This paper will consist of 40 compulsory multiple-choice items.

## Paper 2 Theory (2 hours, 100 marks)

This paper is composed of four sections, A, B, C and D:

- Section A - made up of 6 compulsory structured questions of variable marks which add up to 40 marks.
- Section B 20 marks, will be based on the Biology section of the syllabus. It will consist of three free-response Biology questions. Candidates will be required to answer any two questions.
- Section C 20 marks, will be based on the Chemistry section of the syllabus. It will consist of three free-response Chemistry questions. Candidates will be required to answer any two questions
- Section D 20 marks, will be based on the Physics section of the syllabus. It will consist of three free-response Physics questions. Candidates will be required to answer any two questions.

Paper 3Practical Examination (1 hour 30 minutes, 40 marks)

This is a practical consisting of two compulsory questions of 20 marks each from any two sections of the syllabus

NOTE: Examination questions on all papers may be set requiring candidates to apply knowledge to novel situations.

# SPECIFICATION GRID 

| TOPIC | Paper 1 |  | Paper 2 |  |  |  |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|  | Skill 1.0 | Skill 2.0 | Skill 1.0 |  | Skill 2.0 |  |
| BIOLOGY |  |  | Section A | Section B | Section A | Section B |
| Cells and levels of organization |  |  |  |  |  |  |
| Nutrition |  |  |  |  |  |  |
| Respiratory system |  |  |  |  |  |  |
| Transport systems |  |  |  |  |  |  |
| Reproductive systems |  |  |  |  |  |  |
| Health and diseases |  |  |  |  |  |  |
| SUB TOTAL | 8 | 6 | 8 | 12 | 6 | 8 |
| CHEMISTRY | Skill1.0 | Skill 2.0 | Skill 1.0 |  | Skill 2.0 |  |
|  |  |  | Section A | Section C | Section A | Section C |
| Matter |  |  |  |  |  |  |
| Acids, bases and salts |  |  |  |  |  |  |
| Industrial processes |  |  |  |  |  |  |
| Oxidation and reduction |  |  |  |  |  |  |

| Organic chemistry |  |  |  |  |  |  |
| :-- | :-- | :-- | :-- | :-- | :-- | :-- |
| SUB TOTAL | 8 | 5 | 8 | 12 | 5 | 8 |
| PHYSICS | Skill1.0 | Skill2.0 | Skill1.0 |  | Skill 2.0 |  |
|  |  |  | Section A | Section D | Section A | Section D |
| Measurements |  |  |  |  |  |  |
| Force |  |  |  |  |  |  |
| Energy |  |  |  |  |  |  |
| Magnetism |  |  |  |  |  |  |
| Electricity |  |  |  |  |  |  |
| SUB TOTAL | 8 | 5 | 8 | 12 | 5 | 8 |
| GRAND TOTAL | 24 | 16 | 24 | 36 | 16 | 24 |

## Combined Science (Form I - 4) Syllabus

NB: Paper 3 consists of two compulsory questions of 20 marks each from any two sections of the syllabus. All questions are on experimental skill (3.0)

### 10.1 GLOSSARY OF TERMS USED IN SYLLABUS/SCIENCE PAPERS

It is hoped that the glossary (which is relevant only to science subjects) will prove helpful to candidates as a guide, i.e. it is neither exhaustive nor definitive. The glossary has been deliberately kept brief not only with respect to the number of terms included but also to the descriptions of their meanings. Candidates should appreciate that the meaning of a term must depend in part on its context.
10.1 Define (the term(s)...) is intended literally. Only a formal statement or equivalent paraphrase being required.
10.2 What do you understand by/What is meant by (the term(s)...) normally implies that a definition should be given, together with some relevant comment on the significance or context of the term(s) concerned, especially where two or more terms are included in the question. The amount of supplementary comment intended should be interpreted in the light of the indicated mark value.
10.3 State implies a concise answer, with little or no supporting argument, e.g. a numerical answer that can be obtained 'by inspection'.
10.4 List requires a number of points, generally each of one word, with no elaboration. Where a given number of points is specified, this should not be exceeded.
10.5 Explain may imply reasoning or some reference to theory, depending on the context.
10.6 Describe requires candidates to state in words (using diagrams where appropriate) the main points of the topics. It is often used with reference either to particular phenomena or to a particular experiment. In the former instance the term usually implies that the answer should include reference to (visual) observations associated with the phenomena
10.7 Calculate is used when a numerical answer is required. Working should be show
10.8 Deduce means that the candidate is expected to draw logical and valid conclusion from given information.
10.9 Determine implies that the quantity concerned cannot be measured directly but is obtained by calculation, substituting measured or known values of other quantities into a standard formula.
10.10 Estimate implies an approximate calculation of the magnitude or quantity concern
10.11 Find means that the candidate is expected to calculate measure or determine.
10.12 Measure means to establish the quantity concerned using a suitable measuring instrument.
10.13 Outline means to give the essential points.
10.14 Predict implies that the candidate is expected to state what as likely to happen by analysing given information
10.15 Sketch, when applied to graph work, implies that the shape and/or position of the curve need only be qualitatively correct.

# Combined Science (Form I - 4) Syllabus

# Combined Science (Form I - 4) Syllabus

# Combined Science (Form I - 4) Syllabus

# Combined Science (Form I - 4) Syllabus