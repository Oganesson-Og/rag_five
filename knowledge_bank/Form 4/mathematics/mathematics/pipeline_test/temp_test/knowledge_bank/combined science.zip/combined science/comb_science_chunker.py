import json
import re

# Load JSON data provided by user
file_path = '/mnt/data/Combined Science_ocr.json'
with open(file_path, 'r', encoding='utf-8') as file:
    data = json.load(file)

# Initialize structured data
structured_data = []

# Helper function to match topics between Scope and Sequence and Competency Matrix
def normalize_text(text):
    return re.sub(r'\s+', ' ', text.strip().lower())

# Extract Scope and Sequence data
scope_sequence_data = {}
competence_matrix_data = {}

# Extract pages data
pages = data.get("pages", [])

# Flags to identify sections
in_scope_sequence = False
in_competence_matrix = False
current_subject = ""
current_form = ""

# Process each page for Scope and Sequence and Competence Matrix
for page in pages:
    markdown_text = page.get("markdown", "")
    
    if "SCOPE AND SEQUENCE" in markdown_text:
        in_scope_sequence = True
        in_competence_matrix = False
        continue
    if "COMPETENCY MATRIX" in markdown_text:
        in_scope_sequence = False
        in_competence_matrix = True
        continue
    
    if in_scope_sequence:
        if markdown_text.startswith("### 7.1 BIOLOGY"):
            current_subject = "Biology"
        elif markdown_text.startswith("# 7.2 CHEMISTRY"):
            current_subject = "Chemistry"
        elif markdown_text.startswith("# 7.3 PHYSICS"):
            current_subject = "Physics"

        if current_subject:
            matches = re.findall(r'\|\s*(7\.\d+\.\d+)\s*([^\|]+)\|([^\|]+)\|([^\|]+)\|([^\|]+)\|([^\|]+)\|', markdown_text)
            for match in matches:
                topic_code = match[0].strip()
                topic = match[1].replace('<br>', ' ').strip()
                for form_number, content in enumerate(match[2:], start=1):
                    if content.strip():
                        form_key = f"Form {form_number}"
                        scope_sequence_data[(form_key, normalize_text(topic))] = {
                            "subject": current_subject,
                            "topic_code": topic_code,
                            "subtopics": [st.strip() for st in content.split('<br>')]
                        }

    if in_competence_matrix:
        # Detect form changes
        form_match = re.search(r'#\s*8\.(\d+)\s+(\w+)', markdown_text)
        if form_match:
            form_num = int(form_match.group(1))
            if form_num <= 3:
                current_form = "Form 1"
            elif form_num <= 6:
                current_form = "Form 2"
            elif form_num <= 9:
                current_form = "Form 3"
            else:
                current_form = "Form 4"
            current_subject = form_match.group(2).title()

        # Extract competencies
        comp_matches = re.findall(
            r'\|\s*(8\.\d+\.\d+)\s*([^\|]+)\|\s*([^\|]+)\|\s*([^\|]+)\|\s*([^\|]+)\|', markdown_text)
        for comp in comp_matches:
            topic_code = comp[0].strip()
            topic = comp[1].replace('<br>', ' ').strip()
            objectives = comp[2].replace('<br>', '\n').strip()
            content = comp[3].replace('<br>', '\n').strip()
            activities_notes = comp[4].replace('<br>', '\n').strip()
            competence_matrix_data[(current_form, normalize_text(topic))] = {
                "subject": current_subject,
                "topic_code": topic_code,
                "objectives": objectives,
                "content": content,
                "activities_notes": activities_notes
            }

# Merge Scope and Sequence data with Competence Matrix data
for key, scope_data in scope_sequence_data.items():
    form, topic = key
    comp_data = competence_matrix_data.get((form, topic), {})

    merged_data = {
        "form": form,
        "subject": scope_data["subject"],
        "topic": f"{scope_data['topic_code']} {topic.title()}",
        "subtopics": scope_data["subtopics"],
        "objectives": comp_data.get("objectives", ""),
        "content": comp_data.get("content", ""),
        "suggested_activities_notes": comp_data.get("activities_notes", "")
    }

    structured_data.append(merged_data)

# Output structured data
structured_json = json.dumps(structured_data, indent=4)
output_path = '/mnt/data/structured_combined_science.json'
with open(output_path, 'w', encoding='utf-8') as out_file:
    out_file.write(structured_json)

output_path
