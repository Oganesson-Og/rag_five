# Page 1

FORM 3
COMBINED SCIENCE 4003
NEW CURRICULUM NOTES
BIOLOGY SECTION

# CELLS 

A Cell is a basic unit of the structure and function of all living organisms.
The cells cannot be seen by naked eyes; instead microscopes are needed to telescope our view of these structures.

## Cell structures:

The structure of an animal and plant cell
![img-0.jpeg](img-0.jpeg)

## A Comparison between a plant and animal cells:

| Plant cells | Animal cells |
| :-- | :-- |
| Have a cellulose wall covering the cell membrane | Don't have cell wall |
| Have a cell membrane | Have a cell membrane |
| Have cytoplasm | Have cytoplasm |
| Have a nucleus | Have a nucleus |
| Often have chloroplasts with chlorophyll in them | Chloroplasts absent in animal cells |
| Often have large vacuoles containing cell sap | No vacuoles |
| Often have starch grains | Only have glycogen granules present sometimes |

## OlmOCR Image Descriptions

### Image: img-0.jpeg

![img-0.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-0.jpeg.png)


s": [{"description": "The diagram compares an Animal Cell and a Plant Cell. Both cells have three common features:\n\n1) Nucleus - contains genetic material that controls what the cell does.\n2) Cytoplasm - contains enzymes that speed up biological reactions.\n3) Cell membrane - holds the cell together and controls what goes in and out.\n\nThe Plant Cell has an additional three extracellular structures:\n\n1) Rigid Cell wall made of cellulose, gives support for the cell.\n2) Vacuole - contains cell sap, a weak solution of sugar and salts.\n3) Chloroplasts containing chlorophyll for photosynthesis. Found in the green parts of plants."}]}





# Page 2

## Specialised cells:

A specialised cell is designed to do a particular job.
Ciliated cell: found in the trachea and bronchi, moves the mucus towards the throat. They are adapted by the tiny hair like projections called cilia which sweeps the contaminated mucus upwards. The mucus is secreted by goblet cells which are next to ciliated cells.
![img-1.jpeg](img-1.jpeg)

Memory cell : found in the blood, keep antibodies ready to kill pathogens that have affected you more than once.

Root hair cell : found at the end of the plant roots are responsible for the absorption of minerals and water. They are adapted by 3 ways. One, they have an extension that increases the surface area for more water intake. Two, they have a large number of mitochondria for respiration to become more active. Three a concentrated vacuole to help absorbing water by osmosis.
![img-2.jpeg](img-2.jpeg)

Palisade mesophyll cell : found beneath the epidermis of a leaf are specialised at photosynthesis.
![img-3.jpeg](img-3.jpeg)

Sperm cells: are male sex cells. The front of the cell is oval shaped and contains a nucleus which carries genetic information. There is a tip, called an acrosome, which secretes enzymes to digest the cells around an egg and the egg membrane. Behind this is a mid-piece which is packed with mitochondria to provide energy for movement. The tail moves with a whip-like action enabling the sperm to swim. Their function is reproduction, achieved by fertilising an egg cell.
![img-4.jpeg](img-4.jpeg)

Egg cells (ova, singular: ovum): are larger than sperm cells and are spherical. They have a large amount of cytoplasm, containing yolk droplets made up of protein and fat. The nucleus carries genetic information. The function of the egg cell is reproduction.

## OlmOCR Image Descriptions

### Image: img-1.jpeg

![img-1.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-1.jpeg.png)


s": [{"description": "The diagram illustrates a cell with various labeled parts. The nucleus is located at the top left corner of the cell, depicted as a small oval shape filled with a lighter color. Extending from the right side of the cell are numerous thin, wavy lines labeled as cilia. These structures appear to be protruding from the cell's surface, suggesting their role in movement or sensory functions."}]}


### Image: img-2.jpeg

![img-2.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-2.jpeg.png)


s":"The diagram illustrates a plant cell, showing various components labeled as follows:\n\n- **Nucleus**: Located near the center of the cell, this structure is responsible for controlling the cell's activities.\n- **Vacuole**: A large central vacuole occupies most of the cell's space, storing nutrients and waste products.\n- **Cell wall**: Surrounding the cell membrane, it provides structural support and protection.\n\nThe diagram uses color coding to differentiate between these components, with blue for the nucleus and vacuole, and a lighter shade for the cell wall. The overall shape of the plant cell is rectangular with a protruding end, typical of many plant cells."}


### Image: img-3.jpeg

![img-3.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-3.jpeg.png)


s": [{"description": "The diagram illustrates a plant cell with various labeled parts. The cell wall is shown as the outermost layer, providing structural support and protection. Inside the cell wall, the cell membrane is depicted, separating the cell from its surroundings. The cytoplasm fills the space within the cell membrane, containing organelles and other cellular components. A chloroplast, which is responsible for photosynthesis, is visible within the cytoplasm. The vacuole, a large central vacuole, occupies a significant portion of the cell's interior, storing nutrients and waste products. The nucleus, the control center of the cell, is located near the center of the cell."}]}


### Image: img-4.jpeg

![img-4.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-4.jpeg.png)


s": ["The diagram depicts a simplified representation of an amoeba. The cell membrane is shown as a thin line surrounding the cytoplasm. Inside the cytoplasm, there are mitochondria and a nucleus, which are labeled accordingly. The lagellum (tail) extends from one end of the cell, indicating movement or locomotion. The diagram also includes labels for the cell membrane and nucleus to help identify these important cellular components."}]





# Page 3

![img-5.jpeg](img-5.jpeg)

Nerve cell : found throughout the bodies of all organisms are responsible for the transmission of electrical nerve impulses
![img-6.jpeg](img-6.jpeg)

Red Blood Cell : found throughout in the blood of mammals and specialis e at the transport of oxygen using the red pigment haemoglobin. Do not have a nucleus. They are adapted by four ways: They have a biconcave disc shape that gives it a large surface area to carry more oxygen. They contain a chemical called haemoglobin that combines with oxygen and carbon dioxide. They have no nuclease to carry more oxygen and carbon dioxide. They are tiny enough to squeeze through capillaries.
![img-7.jpeg](img-7.jpeg)

Muscle cells: They are cells found in muscles in animals, they contract and relax together to move the organisms.

Their function is to contract to support and move the body. They are adapted by two ways, First, Is that they are made of contractile filament to help in contraction. Second is it contains lots of mitochondria to supply the cell with energy.
![img-8.jpeg](img-8.jpeg)

White blood cells: attack bacteria
![img-9.jpeg](img-9.jpeg)

Platelets: help clotting
![img-10.jpeg](img-10.jpeg)

## OlmOCR Image Descriptions

### Image: img-5.jpeg

![img-5.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-5.jpeg.png)


s": [{"description": "The diagram depicts a cell with various labeled parts. The nucleus is located in the center of the cell, surrounded by the cytoplasm. The cell membrane encloses the entire cell structure."}]}


### Image: img-6.jpeg

![img-6.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-6.jpeg.png)


s":"The diagram depicts a neuron, which is a type of cell that processes and transmits information within the nervous system. The neuron has a distinct structure with an axon extending from the body (soma) and dendrites branching out to receive signals from other neurons. The nucleus, labeled in the image, is located at the center of the soma, responsible for controlling the cell's activities. This diagram provides a clear visual representation of the basic anatomy of a neuron, highlighting its key components."}


### Image: img-7.jpeg

![img-7.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-7.jpeg.png)


s": ["The image depicts a close-up view of red blood cells within a bloodstream. The cells are oval-shaped and appear to be moving through the blood vessel. The background is a vibrant red color, representing the fluid in which the cells are suspended. The texture of the blood vessel wall can be seen, giving a sense of depth and realism to the image."]}


### Image: img-8.jpeg

![img-8.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-8.jpeg.png)


s":"The diagram illustrates a cross-sectional view of a muscle fiber. It shows the single muscle fiber surrounded by multiple nuclei, which are essential for the cell's genetic material. The muscle fibers are connected to bone through tendons, indicating the role of muscles in movement and support. Blood vessels are also present within the muscle tissue, providing oxygen and nutrients necessary for muscle function. This detailed view highlights the intricate structure of muscle fibers, emphasizing their importance in physiological processes."}


### Image: img-9.jpeg

![img-9.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-9.jpeg.png)


s": [{"description": "The diagram illustrates a white blood cell, also known as a leucocyte. The cell is depicted with a central nucleus and several vacuoles within the cytoplasm. The background contains small, round objects representing bacteria or other particles that the white blood cell may be attacking or engulfing."}]}


### Image: img-10.jpeg

![img-10.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-10.jpeg.png)


s": [{"description": "The image contains a diagram of a platelet (thrombocyte). The platelet is depicted as an irregularly shaped cell with several projections. The color used for the platelet is red, which is typical for visual representations of blood cells in educational materials."}]}





# Page 4

# NUTRITION 

- Green plants are the only living organisms able to manufacture their own food in the form of carbohydrates.
- They are called food producers of the world.
- Animals rely on green plants to make food that produces energy.


## Photosynthesis

- It is whereby green plants manufacture their own food using carbon dioxide, water and light as a source of energy.

Carbon dioxide + water reactants $\quad$| Chlorophyll +Sunlight |
| :--: |
| Catalysts |$ \quad$ carbohydrates + oxygen products

The equation shows that carbon dioxide, water and sunlight are raw materials and carbohydrates and oxygen are the end products.

Carbohydrate is a group of foods that can be in two types (sugars and starches).

## Experiment1

Testing a leaf for starch
Materials: iodine solution, dropper, alcohol, test tube, burner, stand, white tile, green leaf, beaker.
Method
![img-11.jpeg](img-11.jpeg)
i. Dip a leaf in water in a beaker to kill cells, stop chemical reactions and to soften it.
ii. Place a leaf in alcohol to remove chlorophyll.

NB. Alcohol is highly flammable. Put the test tube with alcohol in beaker of boiling water.
iii. Dip the leaf in hot water to soften it again.
iv. Place the leaf on a white tile and cover it with iodine solution using a dropper.

Observations
When the leaf is boiled in alcohol, it becomes decolourised.

## OlmOCR Image Descriptions

### Image: img-11.jpeg

![img-11.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-11.jpeg.png)


s": [{"description": "The diagram illustrates a setup for extracting pigments from leaves. A leaf is placed in a boiling tube containing ethanol and asbestos gauze. The boiling tube is inside a beaker filled with boiling water, which serves as the water bath. The entire setup is mounted on a tripod stand."}]}





# Page 5

The colour enables colour changes between iodine and starch to be more visible.
Alcohol makes the leaf brittle and hard and can be softened by placing it in hot water.
Results
The leaf turns to blue-black when starch is present. The leaf turns yellowish-brown when there is no starch.
Conclusion
Plants can make their own food.
Experiment 2
Is carbon dioxide necessary for photosynthesis?

# Materials 

Two potted plants, soda lime, sodium hydrogen carbonate, starch test kit, polythene bags.
Method
![img-12.jpeg](img-12.jpeg)

- De-starch the leaf.
- Cover the plants in a polythene bags for two days, keeping them in a lighted place.
- Insert an inverted lid containing soda lime or calcium carbonate on the surface of the pot for plant A. This absorbs carbon dioxide.
- Cover the plant again and leave plant B untreated and keep the plants for 2-3 days.
- Perform the starch test.
- Record the results.

Observation
Soda lime absorbs carbon dioxide.
The control has all the conditions necessary for photosynthesis.
Results

## OlmOCR Image Descriptions

### Image: img-12.jpeg

![img-12.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-12.jpeg.png)


s": [{"Experiment A": "This experiment involves a potted plant placed inside a bag with carbon dioxide-free atmosphere. The plant is exposed to potassium hydroxide, which reacts with the air inside the bag."}, {"Control B": "The control experiment uses a transparent plastic bag containing sodium hydrogen carbonate. This setup allows for comparison with Experiment A."}]}





# Page 6

Plant A does not photosynthesize since carbon dioxide is being absorbed.
Plants B makes food because carbon dioxide is produced and used by the plant.
Conclusion
Carbon dioxide is required for photosynthesis to take place.
Experiment 3
Is chlorophyll essential for photosynthesis?
Materials
Variegated plant, starch test kit,
Method:
![img-13.jpeg](img-13.jpeg)

1. Starch is difficult to remove chlorophyll from a leaf without killing it so a leaf which contains chlorophyll only in patches is used.
2. Test the variegated leaf for starch.

Observations
When dropping iodine solution, only the green part changes to blue-black, but the white part remains brown.

Conclusion
Chlorophyll is necessary for photosynthesis.
Experiment 4
To investigate the leaf for sunlight
Materials
Aluminum foils, green plant, iodine solution,
Method

- De starch the potted plant by placing it in darkness for at least 24 hours.

## OlmOCR Image Descriptions

### Image: img-13.jpeg

![img-13.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-13.jpeg.png)


s":"The diagram consists of two leaves labeled a) and b), representing the beginning and end of an experiment. Leaf a) is white with green areas indicating the presence of chlorophyll, labeled as 'Beginning of experiment'. The leaf is variegated. Leaf b) is blue-black with brown areas, labeled as 'End of experiment'. This suggests a change in the condition or state of the leaf over time."}





# Page 7

- Take a small piece of aluminium foil or cardboard and cut simple shape out on its middle and cover leaf on the plant with the foil, ensuring the cut out side is uppermost.
- Leave the plant in sunlight for 4-6 hours.
- Remove the leaf covered by the foil and test it for starch.
![img-14.jpeg](img-14.jpeg)

Results
When testing for starch, the uncovered part will turn blue- black (starch present).
The covered part turns brown / no colour change (absent of starch).
Conclusion
Sunlight is essential for photosynthesis.

# Experiment 5 

Is oxygen produced during photosynthesis?
Materials: leaf (elodea), iodine solution, test tube, beaker, funnel, water, glowing splint, stand Method
![img-15.jpeg](img-15.jpeg)

## OlmOCR Image Descriptions

### Image: img-14.jpeg

![img-14.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-14.jpeg.png)


s": [{"image": "a) Beginning of experiment\n- Exposed\n- Covered with foil paper\n\nb) End of experiment\n- Blue-black\n- Brown\n\nThe diagram illustrates an experiment involving a leaf. At the beginning of the experiment (a), the leaf is exposed and covered with foil paper. By the end of the experiment (b), the leaf shows blue-black and brown areas, indicating some form of chemical reaction or process occurring during the experiment."}]


### Image: img-15.jpeg

![img-15.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-15.jpeg.png)


s": [{"description": "The diagram illustrates an experiment setup for collecting gas. It consists of a beaker containing water and pond weed. A funnel is placed in the beaker to allow gas to enter. The gas collects in a measuring cylinder above the water level. The labels indicate that gas collected is being measured."}]}





# Page 8

i. Place a water weed in a beaker with water.
ii. Fill the test tube with water and invert it over the inverted funnel.
iii. Place the apparatus near a window so it receives sunlight.
iv. Leave the apparatus until the test tube is full of gas.

Observations
Gas collects in the test tube. Remove the test tube by lifting it upwards sob that the gas remains in it. Test the gas in the test tube with a glowing splint.

Results; The splint burst into a flame.
Conclusion
Oxygen is produced during photosynthesis.

Factors that Affect the Rate of Photosynthesis.
There are 4 factors affecting the rate of photosynthesis,

1. Amount of carbon dioxide - increased carbon dioxide increases rate of glucose production which speeds up photosynthesis
2. Light intensity- light energy is trapped by chlorophyll to split water molecules \& therefore increasing light energy will speed up the rate of photosynthesis
3. Temperature - temperature affect rates of chemical reactions. Low temp makes enzymes inactive \& slows down photosynthesis while very high temp will kill the enzymes stopping photosynthesis
4. Amount of water available - adequate amounts of water are needed \& any shortage will slow down photosynthesis

The External leaf Structure
![img-16.jpeg](img-16.jpeg)

Structure of a Leaf

## OlmOCR Image Descriptions

### Image: img-16.jpeg

![img-16.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-16.jpeg.png)


s":"The diagram illustrates a leaf with various labeled parts. The lamina is the flat, green part of the leaf that is attached to the petiole. The mid-rib runs down the center of the lamina and is connected by smaller veins called branch veins. These veins form a vein network throughout the leaf. A bud is visible at the base of the petiole, indicating the potential for new growth. The diagram provides an educational overview of leaf anatomy."}





# Page 9

![img-17.jpeg](img-17.jpeg)

Functions of the Parts
4 Cuticle layer:- It is a waxy layer on top of epidermis. It is a waterproof and therefore reduces the loss of water from the leaves and also prevents entry of pathogens.
4 Palisade layer/mesophyll- : main organ of food production. The cells contain a lot of chloroplast.
4 Upper epidermis below the cuticle and forms a protective covering.
4 Lower epidermis at the lower surface and contains stomata for gaseous exchange.
4 Spongy layer :- have got a lot of air spaces and is important for gaseous exchange.
4 Vascular bundle-: contains the xylem and phloem vessels.
-Xylem vessels -carries water required for photosynthesis.
-Phloem vessels- carry away soluble food to other parts of the plant.
4 Stomata are small pores on the lower epidermis for gaseous exchange during photosynthesis, respiration and transpiration.
Adaptations of a Leaf for Photosynthesis
4 Large surface area to trap light.
4 Thin leaf to allow light through and a short diffusion for carbon dioxide.
4 Presents of stomata on the underneath of the leaf to allow gaseous exchange.
4 Spongy layer which creates air spaces to allow carbon dioxide to enter through.
4 Chlorophyll to attract or trap sunlight.
4 Venation (veins) to carry water into the leaf and soluble food out of the leaf.
4 Many stomata on the lower surface for gaseous exchange and water vapour.
4 The cuticle is transparent to allow easy passage of light.
End products and their fate

- Starch is manufactured.
- Oxygen is given out or produced. Oxygen passes out by diffusion into the surrounding air, Some of the oxygen is used by plants during respiration.

## OlmOCR Image Descriptions

### Image: img-17.jpeg

![img-17.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-17.jpeg.png)


s": [{"description": "The diagram on the left illustrates a cross-section of a leaf. It shows the different layers and cells within the leaf structure. The upper epidermis is depicted at the top, followed by the palisade cells, spongy mesophyll cells, and air spaces. Stomata are also visible in the spongy mesophyll layer. The diagram includes labels for each component."}, {"description": "The diagram on the right provides a detailed view of leaf anatomy. It highlights the cuticle, epidermis, palisade cells, spongy mesophyll, and veins. The stomata are shown in the spongy mesophyll layer, with guard cells surrounding them. The diagram also includes labels for each part of the leaf structure."}]}





# Page 10

- Carbohydrates or starch is transported to other parts of plant. They are transported as sugars as these molecules are soluble.
- Carbohydrate are used for energy or stored as starch which is insoluble.
- Cellulose is also a structural compound from carbohydrates used to make plant cell walls and give plant support. It makes up the fibred found in plant such as carrots, sugarcane and mangoes.


# Question 2 

Why is photosynthesis important? (4)

1. It produces carbohydrates which are food for animals. The plants themselves also manufacture their own food. This is why plants are called Producers when looking at food chains and food webs.
2. Photosynthesis produces oxygen which is used by plants and animals during respiration.
3. Plants use carbon dioxide during photosynthesis which helps to reduce global warming.
4. Photosynthesis converts light energy into chemical energy. This chemical energy can be used for many processes in our everyday life e.g. we burn firewood to get heat.



# Page 11

# ANIMAL NUTRITION 

## Alimentary system

Is made up of many different organs. These organs together, help with the processing of food.
The alimentary canal
![img-18.jpeg](img-18.jpeg)

4 Ingestion is a process of taking in food. In the mouth, food is broken down into smaller pieces by the teeth (physical digestion).
4 Food is mixed with saliva which contains enzyme salivary amylase. It breaks starch into maltose (chemical digestion).
4 From there food passes the oesophagus to the stomach. In the stomach, it is mixed with gastric juice containing gastric enzymes.
4 Food remains for some hours and is then churned by movement of stomach walls (physical digestion).
4 Food then passes into the duodenum where many digestive enzymes act on it and food is broken into smaller particles.(chemical digestion).
4 Food travels into small intestines (ileum) where most of digested food is absorbed into blood streams.
4 The remains pass into the colon (large intestines), and the rest enters into the rectum and is egested as waste material through the anus.

Parts of the digestive system
Mouth - food enters the mouth (ingestion) where it is chewed and mixed with saliva. Starch is digested in the mouth by action of enzyme called salivary amylase. The tongue rolls food into balls and pushes the food down.

Gullet/oesophagus - when food is pushed, it is forced to move slowly through this passage to the stomach. This process is called peristalsis (contraction and relaxation of muscles).

## OlmOCR Image Descriptions

### Image: img-18.jpeg

![img-18.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-18.jpeg.png)


s": [{"description": "The diagram illustrates the human digestive system. It includes major organs such as the stomach, liver, gall bladder, small intestine (duodenum and ileum), large intestine (colon and rectum), pancreas, and appendix. The bile duct is connected to the liver and flows into the duodenum. The pyloric sphincter connects the stomach to the small intestine. The pancreatic duct leads from the pancreas to the small intestine. The anus is at the end of the large intestine."}]}





# Page 12

![img-19.jpeg](img-19.jpeg)

Stomach - food is kept here for up to 5 hours and chemical digestion takes place. Food is chewed into churned by action of stomach juices. Stomach-walls secrete gastric juice containing enzymes renin and pepsin. Renin assists in coagulating milk thus, preventing it passing too rapidly through the canal before it can be digested. Renin is important to children who frequently consume milk. Pepsin breaks down protein into peptones. Hydrochloric acid provides the correct pH for gastric enzymes to act.

Small intestines - food enters the small intestines from the stomach. This is where digestion is completed. The gall bladder produces bile to digest proteins and other carbohydrates. The ileum joins the large intestines

Large intestines /colon - this is for absorption of water which enables wastes (faeces) to pass out via the rectum to the anus where egestion

Duodenum- undigested food is converted into maltose. Proteins are changed into peptones. Fats are changed into fatty acids and glycerol. The digestion of fat is aided by bile which is made in the liver, stored in the gall bladder and carried to the duodenum along the bile duct. Peptones from the stomach are changed into amino acids and amino acids are small enough to be absorbed through the ileum. Sugars are converted into glucose which is absorbed through the intestinal wall.
![img-20.jpeg](img-20.jpeg)

# Types of teeth and functions 

Teeth are used for cutting and chewing food.

## OlmOCR Image Descriptions

### Image: img-19.jpeg

![img-19.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-19.jpeg.png)


s": [{"description": "The diagram illustrates the movement of food down the oesophagus. It shows a relaxed state on the left and a contracted state on the right. The relaxed muscles allow the bolus of food to enter the oesophagus, while the contracted muscles facilitate its passage. An inset image highlights the process of contraction."}]}


### Image: img-20.jpeg

![img-20.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-20.jpeg.png)


s": [{"description": "The diagram illustrates the anatomy of the digestive system focusing on the bile ducts and their connections. The common bile duct is shown emerging from the liver and connecting to both the gallbladder and the pancreatic duct. These ducts converge near the duodenum, which is the first part of the small intestine. The gallbladder is depicted as a green structure located near the liver, while the pancreas is not explicitly shown but implied by the presence of the pancreatic duct."}]}





# Page 13

![img-21.jpeg](img-21.jpeg)

Identify types of teeth and explain their functions (8)

The teeth are used to bite, tear, crush and grind food into smaller pieces. There are four main types of human teeth. Each type is different in structure and performs a specific function:

1. Incisors ( $\boldsymbol{i}$ ): Four front teeth in the upper jaw and four front teeth in the lower jaw. They are chisel-shaped and are used for biting and cutting food.
2. Canines (c): These are single teeth in each half jaw next to the incisors. They are pointed and are used for gripping and tearing food.
3. Premolars ( $\boldsymbol{p m}$ ): There are two behind the canines on the upper and lower jaws, thus totalling eight. Together with the molars, they form the cheek-teeth and have flattened surfaces for crushing and grinding food.
4. Molars (m): There are six molars found at the back of the upper jaws and six in the lower jaws. They have flattened surfaces for crushing and grinding food.
Causes of dental decay/dental caries
Caused by bacteria and plague.
Plague- It is a thin layer of food remains on the tooth surface which contains bacteria.
Stages in Tooth Decay
5. Damage to the enamel results in no pain being felt.
6. Dentine damage results in extreme cold/heat causing a pain sensation.
7. Opening into the pulp results in severe toothache as a result of exposure of the blood capillaries and nerve endings. Tooth extraction is usually recommended at this stage.
N.B- Action of bacteria on sugary food remains has been associated with dental decay.

## OlmOCR Image Descriptions

### Image: img-21.jpeg

![img-21.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-21.jpeg.png)


s": [{"description": "The diagram illustrates a cross-sectional view of a tooth. It shows the various components of the tooth, including the enamel, dentine, pulp cavity, root canal, gum tissue, nerve and blood vessels, cement, and bone. The tooth is divided into different parts: crown, neck, and root. The crown includes incisors, canines, premolars, and molars."}]}





# Page 14

![img-22.jpeg](img-22.jpeg)

Caring For Teeth
$\checkmark$ Regular brushing.
$\checkmark$ eat a balanced diet.
$\checkmark$ Use a tooth brush.
$\checkmark$ brush after meal.
$\checkmark$ brush gently for 1-3 minutes.
$\checkmark$ visit the dentist regularly
$\checkmark$ eat fibrous foods.
$\checkmark$ brush in circular motion.

# Question 1 

a) Give the difference between non-ruminant and ruminant animals. (6)
b) What are the functions of the hepatic portal vein and the liver?

Solution
a)

| Ruminants e.g. cow | Non ruminants e.g. rabbit |
| :-- | :-- |
| Have four stomach chambers | Have one stomach |
| Chew the cud | Do not chew the cud |
| Cellulose digestion in the rumen | Cellulose digestion in the caecum |

## Digestion

- Is the breaking down of insoluble food particles into soluble ones.

Mechanical digestion
$>$ Is the physical breakdown of food in the alimentary canal. It starts in the mouth by the action of teeth.
$>$ In the stomach, food is squeezed, churned and mixed with gastric juices. Involuntarily muscles in the stomach bring this automatic action about.
$>$ Peristaltic movements in alimentary canal (successive squeezing movements in the walls of the alimentary canal)
$>$ Anti-peristalsis in ruminants allows the cow to chew and this is physical.
$>$ The strong contraction of the rectal muscles helps to expel the undigested matter.

## Chemical digestion

$>$ Is the breakdown of food into smaller soluble molecules so that they can be observed into the blood stream. Enzymes bring about chemical digestion.
$>$ Enzymes are produced either in the walls of the gut or in glands. They are catalysts which speed up chemical digestion.

## OlmOCR Image Descriptions

### Image: img-22.jpeg

![img-22.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-22.jpeg.png)


s": [{"description": "The diagram illustrates a cross-sectional view of a decaying tooth. The outer layer is the enamel, which is followed by the dentine. Inside the dentine, there are nerves and pulp. A cavity can be seen in the center, indicating decay."}]}





# Page 15

NB: In the caecum (of rabbits) and rumen (of cattle) the bacteria secretes cellulose that changes cellulose to glucose.

Modelling the action of amylase on starch

- Collect a 15 cm length of visking tubing which has been softened in water.
- Tie one end tightly. Use a syringe to introduce $2 \%$ starch solution into the visking tubing, to about two thirds full.
- Add 2 cm 3 of $5 \%$ amylase solution (or saliva if it is permissible).
- Pinch the top of the visking tubing to keep it closed, before carefully mixing its contents by squeezing the tubing.
- Rinse the outside of the visking tubing thoroughly with tap water, then place it in a boiling tube, trapping the top of the tubing with an elastic band.
- Add enough distilled water to cover the visking tubing.
- Test a small sample of the distilled water and the contents of the Visking tubing for starch and reducing sugar, using iodine solution and Benedict's solution.
- Place the boiling tube in a beaker of water or a water bath at $37^{\circ} \mathrm{C}$.
- After 20 minutes, use clean teat pipettes to remove a sample of the water surrounding the Visking tubing and from inside the visking tubing.
- Test some of each sample for starch, using iodine solution, and for reducing sugar, using Benedict's solution.
- Also test some of the original starch solution for reducing sugar, to make sure it is not contaminated with glucose.
![img-23.jpeg](img-23.jpeg)

Results

- At the start of the investigation the distilled water tests negative for starch (stays brown) and reducing sugar (stays turquoise). The contents of the visking tubing are positive for starch (blue-black), but negative for reducing sugars (stays turquoise).
- After 20 minutes, the contents of the visking tubing are yellow/brown with iodine solution, but turn orange or brick red with Benedict's solution. The water sample stays yellow/brown with iodine solution, but turns orange or brick red with Benedict's solution.

## OlmOCR Image Descriptions

### Image: img-23.jpeg

![img-23.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-23.jpeg.png)


s": [{"description": "Figure 7.26 Experiment to model the digestion of starch\n\n- elastic band\n- amylase + starch solution\n- Visking tubing\n- water"}]}





# Page 16

- The amylase digests the starch in the visking tubing, producing reducing sugar.
- The complete digestion of starch results in a negative colour change with iodine solution.
- The presence of reducing sugar (maltose or glucose) causes the Benedict's solution to turn orange or brick red.
- The reducing sugar molecules can diffuse through the visking tubing into the surrounding water, so the water gives a positive result with Benedict's solution.
- Starch is a large molecule, so it cannot diffuse through the tubing: the water gives a negative result with iodine solution.
This model can be used to represent digestion in the gut. The starch solution and amylase are the contents of the mouth or duodenum. The visking tubing represents the duodenum wall and the distilled water represents the bloodstream, into which the products of digestion are absorbed.


# Absorption 

- Soluble food molecules are the end products of digestion. This happens mainly in the small intestines or ileum. Water and alcohol can be observed directly through the walls of the stomach. The ileum is very long in most mammals and its inner wall with its folds and villi greatly increase the surface area available for absorption.
- The walls of villi are one cell thick and this enables simple food molecules to pass through.
- Inside each villus are capillaries with blood which collect and carry food molecules from the small intestines.
- Glucose and amino acids are absorbed by diffusion from an area of their high concentration in the ileum to one of their low concentration in the villus.
- Inorganic salts, vitamins and water are also absorbed through the villi in the ileum
- Fatty acids and glycerol pass into the blood stream via the lacteal ducts of the villi and the lymphatic system.



# Page 17

![img-24.jpeg](img-24.jpeg)

The role of the liver

- Glucose, amino acids and fatty acids are carried to the liver in the blood via a system of capillaries and veins to the large herpatic portal vein. This connects the blood system surrounding the ileum to the liver.
NB: The principal area for the absorption of nutrients is the ileum/small intestines.
Assimilation
- It looks at the fate of the products of digestion that have been absorbed into the body of an animal.
- The carbohydrates and amino acids are taken to the liver through the hepatic portal vein.
- Glucose is stored in the liver or in muscles as glycogen or fats
- Excess amino acids are taken back to the liver where they are de-animated to remove nitrogen which is made into area. The urea is then taken to the kidneys where it is removed as urine.
- Fatty acids and glycerol burnt to provide energy to the body especially when glucose is in short supply.
- Some fatty acids are made into cell membranes.
- Excess fatty acids are converted to fats which insulates the body providing warmth, and protect organs such as the heart and the intestines.

## OlmOCR Image Descriptions

### Image: img-24.jpeg

![img-24.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-24.jpeg.png)


s": [{"description": "The diagram illustrates a longitudinal section through a villus. The Thin epithelium is one cell thick to increase diffusion rate and has microvilli that increase the surface area for absorption. The Lacteal (tiny lymphatic vessels) absorb fatty acids and glycerol. The Blood capillary absorbs glucose and amino acids."}]}





# Page 18

## Food Tests

- It is important to know how much nutrients they contain. This would be useful to nutritionist and those who are health conscious.


## Experiments

## Materials

Benedict's solution /Clinistix, iodine solution, Biuret's solution / Albustix, ethanol, paper, a variety of foods to be tested, burners, suitable containers.

Testing for starch

1. Drop a few drops of iodine solution on the food.
2. Or add a food sample to a test tube containing an iodine solution

## Results

The iodine solution turns blue black if starch is present.

Testing for Glucose
Method

1. Place about 2 ml of food solution in a test tube and add some Benedict's solution
2. Heat the test tubes in a water bath.
3. Observe the colour change from green/orange to red/brown/ brick red.

## Results

The Benedict's solution changes from green/orange to brick red if the food contains sugar/glucose

## Protein

1. Add a few drops of Biuret solution to the food sample.
2. Add a food sample to a test tube containing Biuret solution

## Results

If the food sample contains proteins the solution will turn blue/ a darker shade of blue.

Fats

1. Place the food sample (about 2 ml ) into a test tube.
2. Add ethanol and shake thoroughly.

## Results

Am emulsion forms if fat or oil is present.
NB. Alternatively a small amount the food can be smeared onto a piece of paper. And left to dry for a couple of minutes, the remaining stain is then observed. If a translucent stain forms then fat is present in the food sample being tested.

Qn 1. Describe food tests using Clinistix and Albustix. [6 ]



# Page 19

# RESPIRATORY SYSTEMS 

The system is responsible for gaseous exchange and breathing so that oxygen is taken in and carbon dioxide expelled out. All organisms need oxygen from the air. The oxygen is taken into cells so that glucose can be broken down (respiration).

The respiratory system consists of the lungs, organs inside the head and of the chest.
Experiment 1 (a)
Comparing inhaled and exhaled air
Apparatus: carbon dioxide indicator, two test tubes, mouth piece,
Method
![img-25.jpeg](img-25.jpeg)

Set up the apparatus.
4. Breathe in and out of the mouth piece while closing pipe A and B to help the movement of air.
4. Observe any colour change.

Observations
Lime water in A remains clear and in B turns milky.
Results
Lime water changes colour to milky showing the presence of carbon dioxide.
Conclusion
There is more carbon dioxide in B than in A.
Experiment 2 (b)
Aim: comparing inhaled and exhaled air
Materials
Large transparent container e.g. bell jar, candle, tin lid, water, large basin, rubber tubing, ruler.

## OlmOCR Image Descriptions

### Image: img-25.jpeg

![img-25.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-25.jpeg.png)


s": [{"description": "The diagram illustrates a setup for a biological experiment involving the use of clear limewater. The setup consists of two test tubes labeled A and B, each containing clear limewater. A mouthpiece is connected to both test tubes via tubing, indicating that air or gas can be introduced into the system through the mouthpiece. The presence of clear limewater suggests that the experiment may involve observing the reaction with carbon dioxide, as clear limewater turns cloudy when exposed to it."}]}





# Page 20

# Method 

![img-26.jpeg](img-26.jpeg)

Place the bell jar over a lighted candle floating in a basin of water.
4. Measure how far the water rises up after the candle has been extinguished.
4 Repeat this with exhaled air after holding your breath for 30 mins, this will fill the container with exhaled air.
4 Place a candle in the container and measure the water displacement again.
Results and explanation

- Water displacement in the first instance when natural air is used is greater due to more oxygen which is then used up by the candle.
- Oxygen combines with carbon to form carbon dioxide. The candle eventually goes out as oxygen runs out and the container is filled with carbon dioxide.
- There is less displacement in the second instance as exhaled air contains less oxygen.

Conclusion
Inhaled air contains more oxygen than exhaled air.
Differences between Inhaled and Exhaled Air

|  | Inhaled | Exhaled |
| :-- | :-- | :-- |
| Oxygen | $21 \%$ | $16 \%$ |
| Carbon dioxide | $0,03 \%$ | $4,1 \%$ |
| Water vapour | Small percentage | A larger percentage |
| Temperature | Lower than <br> exhaled | Higher than inhaled |
| Nitrogen | $78 \%$ | $78 \%$ |

## OlmOCR Image Descriptions

### Image: img-26.jpeg

![img-26.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-26.jpeg.png)


s": [{"description": "The diagram illustrates a simple experiment setup. A bell jar is placed over a candle, which is lit and placed inside the jar. The air within the bell jar is displaced by the water in the basin below it. This setup demonstrates the principle of atmospheric pressure and how it affects the flame's combustion."}]}





# Page 21

The Alveoli or Air Sacs
![img-27.jpeg](img-27.jpeg)

- The alveoli are air sacs where gaseous exchange takes place.
- They are good gaseous exchange surfaces because there are many and their total surface area is large enough intake of oxygen and expulsion of carbon dioxide.
- They are moist, thin walled to allow gaseous exchange and re surrounded by blood vessels.
- Capillaries surrounding the alveoli contain less oxygen than the air sacs.
- Oxygen therefore diffuses from the alveoli into the capillaries.
- It is then carried by blood to all parts of the body to respiring cells.
- The blood in the capillaries has more carbon dioxide than the blood in the air sacs, so by diffusion carbon dioxide moves into the air sacs and expelled through the bronchioles.

## OlmOCR Image Descriptions

### Image: img-27.jpeg

![img-27.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-27.jpeg.png)


s": [{"description": "The diagram illustrates the process of gas exchange between the lungs and the circulatory system. It shows how gases such as oxygen (O₂) and carbon dioxide (CO₂) are exchanged at the alveoli level. Oxygen diffuses into red blood cells from the air, while CO₂ diffuses into the alveolus to be exhaled. The diagram highlights the capillary network that facilitates this exchange. It also labels key components such as the capillary, alveolar membrane, and respiratory membrane."}]}





# Page 22

# TRANSPORT SYSTEMS 

## Transpiration

Question 1 - define transpiration. (2)
It is the loss of water from the plant through the leaves and stem. Water is lost from the plant mainly through the stomata on the leaves.

Importance of Transpiration

- For continuous absorption of water. The continuous flow of water from the roots up the stems and out of the leaves is called transpiration stream.
- For the plant to take up dissolved mineral nutrients/ions.
- It has a cooling effect on the plant due to evaporation.

However, when plants loose more water than they can absorb from the soil wilting occurs
i.e. wilting occurs when plant leaves loose excessive water. Permanent wilting leads to plant death.

## Experiment 1

Do plants lose water?
Apparatus: one potted plant, plastic bag, rubber band, blue anhydrous cobalt chloride paper.
Method
4. Place a transparent plastic bag over a potted plant.
4. Leave the set up for about 20 minutes.
4. Observe the results, if there is a liquid, drop it on blue cobalt chloride paper to see if it is water.

Observations and results
Droplets of liquid are seen inside the plastic bag.
Blue cobalt chloride paper changes to pink i.e. the positive test of water.
Experiment 2
Investigating factors affecting the rate of transpiration
The apparatus shown below is called a potometer. It is used to measure the rate of transpiration.

Method



# Page 23

![img-28.jpeg](img-28.jpeg)

- Cut a woody shoot and immediately place the cut edge of the shoot under water.
- Immerse the potometer complelely under water in a big bowl or sink with the tap under the reservoir open. Make sure the potometer is completely filled with water and that there are no air bubbles.
- Put the cut stalk of your leafy shoot into the water in the sink and cut off the last centimetre of the stem obliquely under water.
- With the potometer and the stalk of the shoot still under water, fit the stalk into the rubber bung. It must fit very tightly.
- Close the tap under the reservoir and remove the shoot and potometer from the water. Clamp in position if necessary and keep in a still, lit position.
- Any air bubbles in the capillary tube should be expelled by opening the tap to let water run into the potometer bottle from the reservoir.
- At this stage if the apparatus is not air tight, water will be seen oozing out from the sides of the stopper. If necessary smear some Vaseline around the rubber stopper to prevent any leakage.
- Prepare a results table.
- Record the distance the air bubble travelled in mm every minute for at least 10mins
- Calculate and record the distance travelled in mm per min.
- Repeat at least twice and calculate the average distance.

The conditions can now be changed in one of the following ways:

- Move the apparatus into sunlight or under a fluorescent lamp.
- Blow air past the shoot with an electric fan or merely fan it with an exercise book.
- Cover the shoot with a plastic bag.
- After each change of conditions, take three more readings of the rate of uptake and notice whether they represent an increase or a decrease in the rate of transpiration.


# Results 

- An increase in light intensity should make the stomata open and allow more rapid transpiration.
- Moving air should increase the rate of evaporation and, therefore, the rate of uptake.
- The plastic bag will cause a rise in humidity round the leaves and suppress transpiration.

## OlmOCR Image Descriptions

### Image: img-28.jpeg

![img-28.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-28.jpeg.png)


s": [{"description": "The diagram illustrates a potometer, a device used to measure the rate of transpiration in plants. The setup includes a cut shoot from which water is drawn into a reservoir. An air bubble is present within the volume scale, indicating the level of water movement. A capillary tube connects the reservoir to a beaker of water, allowing for the measurement of water uptake by the plant."}]}





# Page 24

Limitations of the potometer

- Not all the water taken up will be transpired; some will be used in photosynthesis; some may be absorbed by cells to increase their turgor. However, these quantities are very small compared with the volume of water transpired and they can be disregarded.
- The rate of uptake of a cut shoot may not reflect the rate in the intact plant. If the root system were present, it might offer resistance to the flow of water or it could be helping the flow by means of its root pressure.


# Factors affecting Transpiration (Summary) 

The rate of transpiration is affected by environmental factors: light, heat, air and wind.

1. Temperature - when temperatures increases the rate of transpiration increases as evaporation of water on leaves becomes rapid. When temperature is low the rate is also low.
2. Humidity - when the atmosphere is saturated with water vapour the rate of transpiration will be reduced. The rate will be low when the atmosphere is dry.
3. Light intensity - transpiration is fast when there is more light as this would encourage the opening of stomata.
4. Surface area - plant with broad leaves lose more water than those with small, thin leaves.
5. Air movement - water is lost faster on a leaf exposed to the wind, as more water is swept from the surface of the leaf thus transpiration is rapid.
6. Stomata - the greater the number of stomata on the leaf surface, the greater the rate of transpiration.

## Question 2

With the aid of labeled diagram, describe an experiment to illustrate that water is given off during transpiration. (6)



# Page 25

# Turgidity and Plasmolysis 

## Turgidity

Turgid means cell is completely filled with water and cannot absorb more water.

- When plant cells are surrounded by water, there is a higher concentration of water molecules outside compared to inside the cells.
- Water moves into the cells by osmosis.
- The cells become firm and hard.
- We say the cells are turgid.
- The cellulose cell wall prevents the cells from bursting.
![img-29.jpeg](img-29.jpeg)


## Plasmolysis

- Plasmolysis /flaccid means cell has lose water and become soft
- When plant cells are surrounded by concentrated sugar solution they lose water by osmosis.
- Water molecules move from the plant cells into the sugar solution where they are at a lower concentration.
- The cell walls sag inwards, the cells become soft.
- We say the cells are flaccid.
![img-30.jpeg](img-30.jpeg)

## OlmOCR Image Descriptions

### Image: img-29.jpeg

![img-29.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-29.jpeg.png)


s": [{"description": "The diagram illustrates a cross-section of plant tissue. It shows several hexagonal cells with visible cell walls and vacuoles. The cell walls are thick and appear to be made of cellulose, which is indicated by the dotted lines. There are dark regions within some of the cells, possibly representing organelles or other cellular structures. The arrangement of the cells suggests a compact and sturdy tissue structure."}]}


### Image: img-30.jpeg

![img-30.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-30.jpeg.png)


s": ["The diagram depicts a cross-sectional view of plant cells. The cells are hexagonal in shape with visible cell walls and vacuoles. There are several nuclei present within the cells, indicating active cellular processes. The arrangement suggests a typical epidermal layer structure, possibly from a leaf or root tissue."]}





# Page 26

# Osmosis and Diffusion 

Diffusion is the movement of particles from a region of high concentration to low concentration through a concentration gradient. Diffusion only stops when the concentration of particles in region A is equal to that in region B, I.e. when there is equilibrium.

Osmosis is the movement of water particles from a region of high concentration to low concentration through a semi-permeable membrane. This type of membrane usually refers to animal and plant cell membranes.

## Experiment 1

Demonstrating turgidity and plasmolysis
Method
![img-31.jpeg](img-31.jpeg)

- Cut three pieces of peeled potato of about $5 \mathrm{~cm} \times 1 \mathrm{~cm}$.
- Place the in distilled water until they are required.
- Prepare three solutions and place in three different containers as follows: A - distilled water.
B - $5 \%$ solution by dissolving 10 g of sugar in 90 g of water.
C - $10 \%$ solution by dissolving 10 g in 90 g of water.
- Record the size of potato. Results
$\checkmark$ In A, there the potato increases in size due to osmosis.
$\checkmark$ In B there is no discernible change in size because of more or less equal water concentration without and within the potato piece hence negligible change in size.
$\checkmark$ In C, the salt solution increases and the potato becomes soft due to less water concentration outside the potato.

## OlmOCR Image Descriptions

### Image: img-31.jpeg

![img-31.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-31.jpeg.png)


s": [{"description": "The diagram depicts a beaker containing a solution with a potato submerged in it. The beaker is labeled as 'beaker' and the solution inside is indicated by an arrow pointing towards the liquid. The potato is shown at the bottom of the beaker, partially submerged in the solution."}]}





# Page 27

# Transport System in humans 

## Blood circulatory

- Animals require a system to carry simple food molecules, oxygen, water other nutrients and also unwanted substances which should be removed from body cells.
- The blood provides a fluid carrying medium which makes up a circulatory system. In mammals, the system is facilitated by a pump (the heart) to create the force to push these substances through tubes or blood vessels.


## The Blood

The blood is made up of two major components

1. Blood Plasma, and
2. Blood Cells (red blood cells, white blood cells and blood platelets)

## Activity: Allowing blood to stand

If blood is allowed to stand without clotting, it separates out into 4 components: plasma, red blood cells, white blood cells and platelets.

The plasma and red blood cells play an important role in the transportation of substances, around the body. White blood cells and platelets are part of the body's immune system
![img-32.jpeg](img-32.jpeg)

## Blood Plasma

Is the liquid part of blood which carries all the other components of the blood around the body. 55\% of the blood is plasma. This straw-coloured liquid contains water with many
important dissolved substances which must be carried around the body. Most materials are carried by the blood plasma either in solution or suspension, except for oxygen which is carried by the red blood cells.

## Plasma transports:

- blood cells (red blood cells, white blood cells and platelets)
- soluble nutrients e.g. glucose and amino acids (products of digestion) from the small intestine to the organs

## OlmOCR Image Descriptions

### Image: img-32.jpeg

![img-32.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-32.jpeg.png)


s": [{"description": "The diagram illustrates the components of blood. It shows a test tube containing blood with layers labeled as plasma and red blood cells. The white blood cells are depicted in a separate section, along with platelets."}]}





# Page 28

- amino acids (plasma acts as a pool for amino acids for these cannot be stored in the body)
- Plasma proteins that are important in blood clotting (e.g. fibrinogen).
- Carbon dioxide (waste gas produced by respiration in cells) from the organs to lungs
- Other wastes of digestion (e.g. urea) from the liver to the kidneys.
- Antibodies and antitoxins produced by white blood cells
- Hormones
- Heat from the liver and muscles to all parts of the body.


# 1. Red blood cells 

![img-33.jpeg](img-33.jpeg)

- They are made in the bone marrow of some bones, including ribs, vertebrae and some limb bones.
- Transport Oxygen from lungs to all respiring tissues.
- Contain haemoglobin, a red iron-containing pigment which can carry Oxygen. In the lungs, Haemoglobin combines with Oxygen to form oxy-haemoglobin. In other organs, oxy-haemoglobin splits up into Haemoglobin and Oxygen.
- Red blood cells have no nucleus.
- Have a special biconcave disc shape which increases the surface area and makes the diffusion of oxygen into \& out of the cell easier.
- Old red blood cells are broken down in the liver, spleen and bone marrow. Some of the iron from the Haemoglobin is stored, and used for making new Haemoglobin, some of it is turned into bile which is used during digestion.


## 2. White blood cells

![img-34.jpeg](img-34.jpeg)

- These are made in the bone marrow and in the lymph nodes.
- They have a nucleus, and shape of nucleus depends on type as shown in the diagram above.
- Can move around and squeeze out through the walls of blood capillaries into all parts of the body to fight off infection.
- There are two main different kinds of white blood cells and all have the function of fighting pathogens (diseasecausing bacteria and viruses) and to clear up any dead body cells in your body:


## a. Phagocytes

- Have a lobed nuclei and granular cytoplasm.
- Can move out of capillaries to the site of an infection.
- Remove any microorganisms that invade the body and might cause infection, engulf (ingest) and kill them by digesting them.

## OlmOCR Image Descriptions

### Image: img-33.jpeg

![img-33.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-33.jpeg.png)


s": [{"description": "The diagram illustrates red blood cells, which are biconcave discs with no nucleus. They contain haemoglobin and carry oxygen."}]}


### Image: img-34.jpeg

![img-34.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-34.jpeg.png)


s": [{"description": "The image contains a detailed illustration of a phagocyte (a neutrophil), which is a type of white blood cell. The phagocyte appears to be in the process of engulfing particles or pathogens, indicating its role in the immune response by phagocytosis. The cell has a large nucleus and several lobes, characteristic of neutrophils. On the right side of the image, there is a smaller illustration labeled 'lymphocyte,' which represents another type of white blood cell involved in the immune system."}]}





# Page 29

## b. Lymphocytes

- produce antibodies to fight bacteria and foreign materials.
- Have large nuclei
- Responsible for immunity


## 3. Platelets.

![img-35.jpeg](img-35.jpeg)

Platelets are responsible for blood clotting. When an injury occurs, fibrinogen in the blood interacts with platelets to form insoluble fibrin. This forms a net over the wound and the net traps blood cells plugging the wound and stopping the bleeding.
![img-36.jpeg](img-36.jpeg)

## Necessity for blood clotting

- Prevent excessive blood loss from the body when there is a damage of the blood vessel.
- Maintain the blood pressure.
- Prevent the entry of microorganism and foreign particles into the body.
- Promote wound healing.

Summary of the Composition of the blood.
![img-37.jpeg](img-37.jpeg)

## OlmOCR Image Descriptions

### Image: img-35.jpeg

![img-35.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-35.jpeg.png)


s": [{"description": "The diagram illustrates a microscopic view of blood cells and plasma. It shows red blood cells (erythrocytes) in various shapes, including biconcave discs, which are essential for oxygen transport. White blood cells (leukocytes), smaller and more irregularly shaped, play a role in the immune system. Platelets (thrombocytes) are also visible, which are crucial for blood clotting. Blood plasma fills the space between these cells, carrying nutrients and waste products."}]}


### Image: img-36.jpeg

![img-36.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-36.jpeg.png)


s": [{"description": "The diagram illustrates the process of blood clotting. At the top, it shows a broken blood vessel wall with red blood cells and platelets surrounding it. The text labels include 'Platelet', 'Red blood cell', and 'Broken blood vessel wall'.\n\nAt the bottom, the activated platelets are shown forming a clot with fibrin, indicating the formation of a blood clot."}]}


### Image: img-37.jpeg

![img-37.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-37.jpeg.png)


s": [{"description": "The diagram illustrates the composition of blood and its components. Blood is divided into two main parts: plasma (55%) and dissolved substances (8%). Plasma contains water (92%), salts (3.5%), hormones, and proteins such as fibrinogen (for clotting) and albumen (maintains osmotic pressure of blood). Dissolved substances include foods like glucose, amino acids, fats, etc., and other nutrients. Blood cells are further divided into red cells (transport of oxygen), white cells (defense), and platelets (clotting). Red cells include phagocytes (ingest microorganisms) and lymphocytes (B-cells produce antibodies; T-cells kill infected & cancerous cells)."}]}





# Page 30

# Blood Vessels. 

These are the tubes through which blood flows around the body. There are 3 main kinds of blood vessels - arteries, veins and capillaries. Blood leaves the heart through arteries. These break up into smaller arterioles which divide again and again, and eventually form very tiny vessels called capillaries. The capillaries gradually join up with one another to form large vessels called veins. Veins carry blood towards the heart.
![img-38.jpeg](img-38.jpeg)

## Plan of the main blood vessels in the human body

The comparison of blood vessels structure and functions
![img-39.jpeg](img-39.jpeg)

## The transfer of materials between capillaries and tissue fluid

As blood enters capillaries from arterioles (small arteries), it slows down. This allows substances in the plasma, as well as Oxygen from red blood cells, to diffuse through the capillary wall into the

## OlmOCR Image Descriptions

### Image: img-38.jpeg

![img-38.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-38.jpeg.png)


s": [{"description": "The diagram illustrates the blood circulation system. It shows an artery, a capillary, and a vein. The artery is depicted with a red color and contains blood flowing from the heart to the body tissues. The capillary network is shown as a mesh of thin vessels where exchange occurs between the blood and tissue cells. The vein is illustrated in blue, indicating the return of blood to the heart. The text states that at any given moment, about 30% of the blood in your systemic circulation will be found in the arteries, 5% in the capillaries and 65% in the vein."}]}


### Image: img-39.jpeg

![img-39.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-39.jpeg.png)


s": [{"description": "The diagram illustrates the structure of blood vessels. It shows an artery on the left and a vein on the right, both labeled with their respective parts: elastic tissue, inner tunic (endothelium), middle tunic (smooth muscle), outer tunic (connective tissue). The blood flow is indicated by arrows. Below these major vessels are arterioles and venules connected to capillaries."}]}





# Page 31

surrounding tissues (the capillary wall is thin and permeable).
Liquid in the plasma also passes out. This forms tissue fluid, bathing the cells. Waste products from the cells, e.g. Carbon dioxide, diffuse back through the capillary walls into the plasma. Some of the tissue fluid also passes back.

Diffusion is responsible for the transfer of materials between capillaries and tissue fluid.

|  | Arteries | Capillaries | Veins |
| :--: | :--: | :--: | :--: |
| Function | Carry blood away from the heart at high pressure | -Supply all cells with their requirements -Take away waste products | Return blood to the heart at low pressure |
| Structure of wall | -Thick, strong -Contain muscles, elastic fibres and fibrous tissue | Very thin, only one cell thick | -Thin <br> -Mainly fibrous tissue <br> -Contain far less muscle and elastic tissue than arteries |
| Lumen | -Narrow <br> -Varies with heartbeat (increases as a pulse of blood passes through) | -Very narrow <br> -Just wide enough for a red blood cell to pass through | Wide |
| Valves | $(-)$ | $(-)$ | $\begin{gathered} (+) \\ \text { Prevent backflow } \end{gathered}$ |
| How structure fits function | -Strength and elasticity needed to withstand the pulsing of the blood, prevent bursting and maintain pressure wave <br> -Helps to maintain high blood pressure, preventing blood flowing backwards | - No need for strong walls, as most of the blood pressure has been lost -Thin walls and narrow lumen bring blood into close contact with body tissue, allowing diffusion of materials between capillary and surrounding tissues. -White blood cells can squeeze between cells of the wall | - No need for strong walls, as most of the blood pressure has been lost <br> - Wide lumen offers less resistance to blood flow |

# The Circulatory System 

- It consists of the heart and blood vessels and these valves to make sure that there is a one way flow.
- Mammals have got a double circulation or pump action. The double action keeps the blood high enough to force the blood through the vessels.



# Page 32

![img-40.jpeg](img-40.jpeg)

# The Heart 

Blood from the body enters the right atrium through the vena cava (main vein). The right atrium contracts and forces blood into the right ventricle. The right ventricle contracts and the tricuspid valve closes. Why? Deoxygenated blood is pumped into lungs through the pulmonary artery. In the lungs blood picks oxygen and gets rid of carbon dioxide. Oxygenated blood moves to the left side of the heart and enters the heart through the pulmonary vein, then into the left atrium and the left ventricle through the bicuspid valve. Blood is forced into the aorta to all parts of the body.
![img-41.jpeg](img-41.jpeg)

## OlmOCR Image Descriptions

### Image: img-40.jpeg

![img-40.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-40.jpeg.png)


s": [{"description": "The diagram illustrates the human circulatory system with a focus on the heart. The Pulmonary Artery carries deoxygenated blood from the right ventricle to the lungs for oxygenation. The Superior Vena Cava brings oxygen-rich blood back to the right atrium. The Tricuspid Valve separates the right atrium and right ventricle. The Right Atrium receives blood from the body via the Superior Vena Cava and sends it to the Right Ventricle through the Tricuspid Valve. The Right Ventricle pumps oxygenated blood into the Pulmonary Artery, which transports it to the lungs for oxygenation. After oxygenation, the blood flows back to the left side of the heart through the Pulmonary Vein, entering the Left Atrium. The Bicuspid Valve (Mitral Valve) separates the Left Atrium and Left Ventricle. The Left Ventricle pumps oxygenated blood into the Aorta, which distributes it throughout the body."}]}


### Image: img-41.jpeg

![img-41.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-41.jpeg.png)


s": [{"description": "The diagram on the left is a simplified representation of the human heart. It shows the main components such as the atria (right and left), ventricles (right and left), pulmonary artery, aorta, and blood flow paths. The labels include terms like 'blood to lungs', 'blood to rest of body', 'pulmonary vein', and 'cardiac muscle'. This diagram is useful for understanding the basic anatomy and function of the heart."}, {"description": "The diagram on the right is a detailed illustration of the human heart, showing various valves (bicuspid valve, semilunar valve), arteries (superior vena cava, inferior vena cava, pulmonary artery, aorta), and veins. It also highlights the flow of blood through the heart, with arrows indicating the direction of blood movement. This diagram provides a comprehensive view of the heart's structure and function."}]}





# Page 33

# Parts of the Heart 

- Pulmonary Artery: carries deoxygenated blood from the heart to the lungs.
- Vena Cava :- a large vein returning blood from the body to the right atrium of the heart (deoxygenated blood).
- Right Artrium: -thin walled chamber that receives the deoxygenated blood from the body tissues.
- Tricuspid valve -: these are three flaps to prevent back flow of blood.
- Aorta :- the main artery from the heart to the body. It carries oxygenated blood to the rest of the body.
- Pulmonary vein: -carries oxygenated blood from the lungs to the heart.
- Left atrium:- upper chamber of the heart receiving blood from veins.
- Blood entering the left side of the heart carries oxygen from the lungs.
- Blood entering the right side comes from the body and is then pumped to the lungs to absorb more oxygen.
NB. 1) Blood on the left side of the heart is oxygenated and that on the right side is de-oxygenated.

2) Muscular walls of the left ventricle are much thicker than those on the right because the blood has to reach all parts of the body.
Other main blood vessels in the body

| Hepatic Artery | Carries oxygenated blood to the liver |
| :-- | :-- |
| Hepatic Portal | Carries de-oxygenated blood and products of digestion from the <br> Vein small intestines. |
| Hepatic Vein | Carries de-oxygenated blood from the liver. |



# Page 34

# PLANT REPRODUCTION 

## Reproduction

Is a feature of all living organisms and shows continuity of life. Is a process whereby organisms produce off springs of their kind.

## Types of Reproduction

a) Sexual reproduction-it involves the fusion of male and female sex cells or gametes.
b) Asexual reproduction-is where by organisms reproduce from multiplication of a single cell e.g. bacteria and amoeba.

In plants, this is named vegetative reproduction (apart of the plant grows and give rise to a new independent plant).

Sexual Reproduction in Plants
The main reproduction organ is the flower and produces fruits and seeds.
Structure of a Flower
![img-42.jpeg](img-42.jpeg)

- On the diagram, label the filament and style. (2)

Functions of Parts of a Flower

| Stigma | Where pollen grains are deposited, produces sticky substance <br> to ensure pollen grains get stuck |
| :-- | :-- |
| receptacle | Where the floral parts of the flower grow and are usually <br> swollen. |
| Style | Hold the stigma and is a path way for pollen tube to ovules. |
| Ovary | Produces ovules and develops into fruit. |

## OlmOCR Image Descriptions

### Image: img-42.jpeg

![img-42.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-42.jpeg.png)


s": [{"description": "The diagram on the left is a detailed illustration of a flower. It highlights various parts such as petals (corolla), stamen, pistil, and sepals (calyx). The labels include: Stigma, Carpel, Petal (petals = corolla), Anther, Filament, Receptacle, Style, Ovary, and Peduncle. This diagram provides a comprehensive view of the flower's anatomy."}, {"description": "The diagram on the right is a detailed illustration of a flower's reproductive parts. It includes: Bract, Filament, Stigma, Anthers, and Ovary. The labels are clearly marked to indicate each part's function in the flower's reproduction process."}]}





# Page 35

| Ovule | Contains female sex cells and develops into seeds after <br> fertilization. |
| :-- | :-- |
| Petals | Attract insects for pollination and the corolla tube directs <br> insects to the nectaries. |
| Sepals | Protect the flower when still in bud. |
| Anther | Male sex cells (produces pollen grains). |
| Filament | Hold the anther |

Features of Wind and Insect Pollinated Flower

| Wind pollinated flower | Insect pollinated flower |
| :-- | :-- |
| has small dull petals | large bright petals |
| do not produce nectar | produce scent |
| have long stamens which hang out of the <br> flower | produces nectar |
| produce plenty of pollen | have short stamens |
| have small, smooth, light and dry pollen | they do not produce much pollen |
| Have hairy stigma hanging out of the flower | have big, rough, sticky pollen |
|  | have short style with a sticky <br> stigma |

Qn 1 a. Define pollination. [2]
b. State types of pollination and the agents of pollination. [4]

Pollination:
Pollination is the transfer of pollen grains from the anthers of a flower to the stigma of a flower.
Methods of Pollination
There are two methods of pollination,

1. insect pollination and
2. wind pollination.



# Page 36

Some flowers pollinate by insects while others pollinate by wind and wind and insects can also be called the agents of pollination.

Insect pollination
Insect pollinating flowers have special attractive features like brightly colored petals, attractive scents and sugary nectar. These features' aim is to attract insects like bees to come and collect their nectar. While an insect is collecting the nectar, its body will touch the anthers. The pollen grains of insect pollinating flowers have hooks and spikes all over them in order to stick to the bodies of the insect that touch it. When this happens, the pollen grain sticks to the body of the insect. When the insect moves on to another flower to collect its nectar, the pollen grain falls off the insect onto the stigma of the flower, thus insect pollination took place.

# Wind Pollination 

Wind pollinating flowers however look very different from insect pollinating ones. This is because they do not need attractive features such as bright colors and scents and nectar to attract insects. Instead, their petals are green or brown with their anthers and stigmas hanging outside the flower to be exposed to the wind. When wind is strong enough, it will blow the pollen grains off the anther and carry it along. At some point the wind will get weaker and the pollen grain will land, if it lands on the stigma of a flower of the same species then the pollination was successful. The surface of pollen grains of wind pollinated plants is smooth because it does not need spikes to catch on insects.

## Types of Pollination

There are two type of pollination

1. Self Pollination and
2. Cross Pollination:

Self pollination - The transfer of a pollen grain from the anther to the stigma of the same flower or the stigma of a flower of the same plant.
Advantages of self pollination

1. Good characteristics can be maintained in the offspring because there is no variation.
2. Chances of success for self pollination are much greater especially were plant population is small. Cross Pollination - The transfer of a pollen grain from the anthers of one plant to the stigma of a flower on another plant of the same species.
Self pollination is considered sexual reproduction because it involves the fusion of two gametes together even though they might come from the same flower or plant.
Why cross pollination is considered desirable
3. It causes variation in plants which allows plants to adapt to changing environments. This prevents the extinction of plant species.
4. It allows the breeding of better varieties by combining plants with desired characteristics.

How are plants adapted to promote cross pollination

1. Unisex plants - some plants have female plants and male plants and no plant can pollinate itself e.g. paw paw plant
2. Stigmas and anthers of plants in certain plants mature at different times. The stigma matures earlier than the anthers and can only receive pollen from another plant.



# Page 37

3. Anthers which are lower than stigmas. This ensures that insects touch the stigma on their way in with pollen from another plant. On their way out, they crawl out using the petals carrying pollen from this flower to another plant.
4. Self sterilisation - some plants produce chemicals on the stigma which do not allow pollen from the same plant to develop.

Disadvantages of Cross pollination
Refer to advantages of self pollination.

# Fertilisation 

Is the fusion or joining of male and female sex cells to form a zygote.
![img-43.jpeg](img-43.jpeg)

## Occurrence

- Fertilization occurs after pollination.
- When a pollen lands on the stigma, it grows a pollen tube(s)
- The pollen tube grows down through the style absorbing a fluid from the style.
- On reaching the ovary, the pollen tube grows towards one of the ovules and enters through a hole (micropyle).
- The male nucleus fuses with the female nucleus to form a zygote.


## After Fertilisation

- The zygote develops into an embryo.
- The ovule becomes the seeds and the ovary develops into fruit.

The zygote divides to form a mass of food material called endosperm.

## Germination

It is the beginning of growth in a plant or a process by which a seed becomes a seedling.

## Experiment 1

Investigating conditions necessary for Germination
Materials: maize seeds, containers, cotton wool, filter paper, pyrogallic acid.
Method

## OlmOCR Image Descriptions

### Image: img-43.jpeg

![img-43.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-43.jpeg.png)


s": [{"description": "The diagram illustrates the process of pollination in flowering plants. It shows a pollen grain containing male nucleus that lands on the stigma. A pollen tube grows down through the style and ovary wall, reaching the ovule containing female nucleus. The male nucleus fertilizes the female nucleus."}]}





# Page 38

![img-44.jpeg](img-44.jpeg)

- Take four batches with ten seeds in each.
- Put them into containers as shown above.
- Container A has water, oxygen, low temperature.
- Container B has oxygen, suitable temperature but no water.
- Container C has water, suitable temperature but no oxygen( pyrogallic acid absorbs oxygen).
- Container D is the control.

Results
$\checkmark$ Very few seeds in container A germinated.
$\checkmark$ The dry seeds in container B did not germinate.
$\checkmark$ Seeds in container C did not germinate at all.
$\checkmark$ Most of seeds in D germinated.

# Conclusion 

- Temperature, moisture and oxygen at optimum are necessary for germination.
- Light is not necessary for germination.

Question1: Explain the main functions of temperature, moisture and oxygen during germination. (6)

## OlmOCR Image Descriptions

### Image: img-44.jpeg

![img-44.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-44.jpeg.png)


s": [{"image": "A", "description": "In this diagram, a container filled with ice is shown. Inside the container, there are cotton wool, moist filter paper, and water. A bean seed is also present on top of the moist filter paper."}, {"image": "B", "description": "This diagram shows a jar with dry filter paper inside it. There is no water present in this jar."}, {"image": "C", "description": "In this diagram, there is a bottle with a closed lid. Inside the bottle, there is pyrogallic acid and moist filter paper. A bean seed is also placed on top of the moist filter paper."}, {"image": "D", "description": "This diagram depicts a jar filled with water and cotton wool. There are no other visible objects inside this jar."}]}





# Page 39

Answer:

| Condition | Purpose for seed germination |
| :-- | :-- |
| Suitable temperature | Increases enzymes activity which speeds up biological reactions and <br> development of the seed. |
| Moisture (water) | Necessary for chemical reactions. <br> The medium for dissolving food substances. |
| Oxygen | Needed for respiration. Oxygen is used to burn the endosperm and <br> /cotyledon (food sources) so that energy is released for the plumule to shoot <br> out of the soil and the radicle to develop into the root system. |

Percentage Germination
Percentage germination $=$ Number of seeds that germinated $x 100 \%$
Number of seeds that were planted



# Page 40

# Reproductive systems (Human) 

Males and females become sexually mature at puberty stage when their bodies undergo changes in appearance and behavior. Reproduction occurs when male and female sex cells fuse (fertilisation). There is internal and external fertilization. The organs and mechanism for reproduction are adapted to ensure successful role (fertilization).

Male Reproductive System
![img-45.jpeg](img-45.jpeg)

The male reproductive system is also located under the stomach. It consists of the following parts:
*.Testes:a male human has two testicles. A testes is a male gland which produces sperms and the male sex hormone testosterone,
*.Scrotum:it is the sac which contains the testicles,
*.Sperm Ducts (Vas deferens): They are two muscular tubes, each connected to a testis. They carry the sperms from the testis to the urethra,
*.Prostate Gland:It secretes a nutritive fluid to the sperms to form a mixture called semen,
*.Urethra:It is a tube inside the penis which is the pathway of semen and urine out of the body,
*.Penis:It is the male sex organ which ejaculates semen into the vagina during sexual intercourse,
*.Epididymis:coiled tubes in which sperms are stored,
*.Seminal vesicle:it is another gland like the prostate gland. It also secretes nutritive fluids for sperms to feed from and swim in forming semen.
-The testicles are inside the scrotum which hangs outside the body. This is because testicles work best at a temperature below that of the body.

The Female Reproductive System:
The female reproductive system is located under the stomach. It consists of the following parts:
*.The Ovaries: There are two ovaries, one on each side. They contain follicles where eggs are produced,
*.Oviducts (Fallopian Tube): They are two tubes, one on each side connected to an ovary. They are where fertilization occurs and they provide a pathway for the eggs to travel to the uterus by sweeping them by cilia on its walls,
*.Uterus (Womb) :Where the fetus develops,
*.Cervix: A muscular tissue which separates the vagina from the uterus,
*.Vagina: it receives the male penis during sexual intercourse.

## OlmOCR Image Descriptions

### Image: img-45.jpeg

![img-45.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-45.jpeg.png)


s": [{"description": "The diagram on the left is a detailed anatomical illustration of the male reproductive system. It includes key structures such as the bladder, ureter, seminal vesicle, prostate gland, sperm duct, epididymis, scrotum, testis, and penis. The labels are clearly marked to indicate each component's position within the body."}, {"description": "The diagram on the right is another anatomical illustration focusing specifically on the male reproductive system. It highlights structures such as the bladder, sperm duct, epididymis, penile urethra, testicle, and scrotum. The labels are used to identify these components accurately within the context of the body."}]}





# Page 41

![img-46.jpeg](img-46.jpeg)

Sex Cells

| Ova | Sperm |
| :-- | :-- |
| Small spherical cell with a nucleus, cytoplasm <br> and thick membrane. | Single cell, with oval shaped head. |
| Larger than sperm-this is because it needs space <br> to store nutrients on which the embryo feeds on <br> before it reaches the uterus. | Smaller than an ovum and in larger quantities to <br> increase the chance of successful fertilisation. <br> Has small middle part and a tail. |
| Does not move by itself - they are swept to the <br> uterus by cilia in the walls of the oviduct. | Can swim to meet the ovum because it has a <br> large number of mitochondria to release lots of <br> energy to be used in swimming. |
| Once a month - puberty to menopause. | Million produced. |

QN 1 Draw and label the sex cells [6 ]

## OlmOCR Image Descriptions

### Image: img-46.jpeg

![img-46.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-46.jpeg.png)


s": [{"description": "The diagram on the left illustrates a female reproductive system. It includes labeled parts such as the ovary, uterus, cervix, vagina, vulva, and tunnel of oviduct."}, {"description": "The diagram on the right provides a more detailed view of the female reproductive system, including additional labels for bladder, urethra, rectum, anus, and other anatomical structures. The image uses shading to differentiate between various organs and tissues."}]}





# Page 42

Fertilisation
![img-47.jpeg](img-47.jpeg)

Define the term fertilisation. (2)
During the formation of the gametes the chromosome number is reduced half so that the normal number is retained (46) at fertilisation.

This refers to the fusion of the male and female gamete nuclei to form a zygote; it takes place in the oviduct or fallopian tube.

- Sperm swim through the cervix into the uterus by wriggling movements of their tail.
- They pass through the uterus to the oviduct, one of the sperm may bump into it and stick to its surface.
- The sperm then enters the cytoplasm of the ovum.
- Then the nucleus fuses with the female nucleus.
- A single ejaculation may contain about 5 hundred million sperms, only one sperm fertilizes the ovum.
- When one sperm enters the ovum, it forms a barrier such that other sperms will not enter and will die after fertilization.
- Before fertilization the released ovum can survive for about 24 hours and a sperm for 2 to 3 days.


# Menstrual Cycle 

![img-48.jpeg](img-48.jpeg)

## OlmOCR Image Descriptions

### Image: img-47.jpeg

![img-47.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-47.jpeg.png)


s": [{"description": "The diagram illustrates the process of fertilization. It shows a single egg cell surrounded by several sperm cells. The nucleus of the egg is labeled and is visible within the cell. One sperm cell has penetrated the egg's membrane, indicating successful fertilization."}]}


### Image: img-48.jpeg

![img-48.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-48.jpeg.png)


s": [{"description": "The diagram illustrates the ovarian cycle and its relationship with body temperature and uterine changes. The top section shows the changes in body temperature over a 28-day period, with two distinct lines representing different temperatures. The bottom section depicts the uterine cycle, highlighting key phases such as follicular phase, ovulation, and luteal phase."}]}





# Page 43

# Day 1-5: 

- The menstrual cycle begins on the first day of bleeding. The thickened spongy layer of the endometrium (uterus lining) breaks down and passes through the vagina. During menstruation, another ovum starts to mature in one of the ovaries


## Day 6-14

- The maturing ovum releases the hormone oestrogen that stimulates the endometrium in the uterus to form a new layer of spongy tissue. On day 14 the mature ovum is released from the ovary into the fallopian tube. This is called ovulation.


## Day 15-28

- A yellowish body called the corpus luteum develops in the ovary where the ovum has been released. The corpus luteum produces the hormone progesterone that stimulates the tissue of the endometrium to thicken to prepare for the possible implantation of a fertilized ovum. The ovum passes down the fallopian tube to the uterus. If there are sperms, fertilization can occur. If the ovum is not fertilized it passes through the uterus to the vagina and out of the body. The corpus luteum degenerates and stops producing progesterone. With no progesterone present, the endometrium breaks down again, restarting the menstrual cycle.


## Causes of Infertility

- Low sperm count.
- Poor quality of sperm.
- Physical conditions.
- Cancer.
- Damage by sexually transmitted diseases (STDs).
- Blockage of the oviducts or sperm ducts.

Development of the Foetus / Embryo (Pregnancy)
-After fertilisation, a zygote is formed in the oviduct or fallopian tube. The embryo then implants itself into the lining of the uterus and begins to develop on placenta. At about eight weeks after fertilisation, the embryo begins to develop features such as a heart, head and limbs, at this stage is called fetus (foetus). The normal gestation period is about 40 weeks.



# Page 44

![img-49.jpeg](img-49.jpeg)

Functions of The Placenta, Umbilical Cord And Amnion.

1. Placenta - allows the diffusion of substances such as oxygen, glucose, amino-acids, salts and antibodies from the mother`s blood to the fetus.
-Also waste substances like carbon dioxide and urea are excreted together with the mother's waste substances. NB: The placenta is selectively permeable, not all substances in the mother`s blood pass to the fetus. Alcohol and nicotine do pass through the placenta and may affect development of the fetus.
2. Umbilical Cord - attaches the fetus to the placenta and carries the umbilical vein (carries oxygenated blood) and umbilical artery (carries deoxygenated blood).
3. Amnion fluid - is a fluid filled sac that supports the fetus and protects it from physical knocks and mechanical damage.
4. What is pregnancy? (3)
5. Describe the functions of the following organs:
a) Placenta.
b) Amnion / water sac.
c) Umbilical cord. (9)
d) State any four problems associated with pregnancy. (4)
6. What are the effects of smoking to pregnant women? (4)

## OlmOCR Image Descriptions

### Image: img-49.jpeg

![img-49.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-49.jpeg.png)


s": [{"description": "The diagram illustrates the placental circulation in a developing fetus. The umbilical vein carries oxygenated blood from the mother to the placenta, where it is transferred to the fetus. The umbilical artery carries deoxygenated blood from the fetus back to the placenta for exchange with maternal blood. The amniotic fluid surrounds the fetus and provides a protective environment. The amnion is a thin membrane that encloses the amniotic fluid. The uterus lining supports the developing fetus."}]}





# Page 45

# HEALTH AND DISEASES 

## Sexually Transmitted Diseases:

$>$ Sexually transmitted diseases or STD's for short are caused by viruses or bacterium passing from one partner or another during sexual intercourse.
$>$ The most spread STD's are gonorrhea and HIV (also known as AIDS).

## Gonorrhea

> Gonorrhea is caused by a bacterium that lives and breeds in damp conditions at 370C called Neisseria gonorrhoeae (also known as Gonnocci/ Gonocococcus).
$>$ It lives in the reproductive system of the carrier person.
$>$ The bacteria could be easily transferred to the partner during sexual intercourse.
$>$ Both males and females can be infected
$>$ Infections usually occur in the urethra, cervix, anal canal and the conjunctiva of the eye.
$>$ The rate of gonorrhea acquisition for males is $35 \%$ after a single exposure and this figure rises to $75 \%$ after multiple sexual contact with the same infected person
$>$ Gonorrhea can also lead to sterility through infecting the prostrate gland in males and fallopian tube in females.

Symptoms of gonorrhea
$>$ in men the symptoms are very clear.
$>$ They include spores on the penis, discharges and burning sensation during urination.
$>$ In women however, the symptoms are less noticeable because women's reproductive organs are inside her body.
> They include discharges which the woman won't be able to differentiate between it and the normal vaginal discharges.
$>$ Women may suffer from swelling of the vulva and abnormal menstrual bleeding
$>$ If a pregnant woman catches the disease, it is likely that the baby will catch it too during giving birth.
$>$ In both sexes untreated gonorrhea may spread to other body parts including the heart valves, the brain and joints
$>$ When it reaches the joints, it causes severe arthritis
Treatment of Gonorrhea
$>$ The disease is easily cured by a course of antibiotics such as penicillin and tetracycline although some strains have become resistant to treatment
$>$ A previously cured infection does not confer immunity. In other words, gonorrhea can be contracted again

## Syphilis

> It is a bacterial infection caused by treponema pallidum and is passed on during sexual intercourse/ during childbirth from mother to child
$>$ The bacteria enter the body through cuts in the epithelium and by penetrating into mucus membranes
$>$ In a pregnant woman the bacteria cross through the placenta to infect the foetus



# Page 46

> Babies with congenital syphilis are usually very weak and ill, living only a few hours after birth Signs and symptoms of syphilis
$>$ The disease develops in three stages
$>$ During the first stage a lump appears on the penis, vagina or cervix
This turns into an ulcer that disappears after about six weeks. This stage may pass unnoticed.
$>$ In the second stage starting six to eight weeks later, the infected person develops a mild fever and a rash or sores around the genitals, anus, mouth and eyes. The lymph glands especially in the neck, may also swell.
$>$ The third stage can occur as many as ten or more years after infection. The bacteria will have invaded most parts of the body and they will affect many tissues and organs. This is the most destructive stage as the bacteria destroy nerves, cause heart disease, blindness, sometimes insanity and eventually death.

Treatment of Syphilis
$>$ Can be treated with penicillin and other antibiotics, but only during the early stages.
$>$ Once the disease has reached the third stage it is difficult to cure as the lesions may have already caused permanent damage to organs

# Chancroid (venereal ulcers) 

$>$ Is an STI caused by the bacterium haemophylus ducreyi
$>$ The bacteria attack the tissue around the external areas of the reproductive organs of both men and women
$>$ An open sore referred to as a chancroid or venereal ulcer, appears on the outside of the genitals.
$>$ The ulcer can bleed or produce a contagious fluid that can spread bacteria during sexual intercourse
$>$ Chancroid can be acquired through touching an open sore as well as through sexual intercourse
Signs and symptoms of Chancroid
$>$ Small bumps appear on the penis or the labia three to five days after sexual intercourse or infection
$>$ In men this develops into open sores on the penis and scrotum
$>$ In females the bumps turn into ulcers that cause a painful burning sensation during urination or bowel movements.
$>$ The sores usually heal quickly but they may persist for months if left untreated
Treatment of Chancroid
$>$ Is treated with antibiotics such as tetracycline and sulphanilamide
$>$ Antibiotics decrease scarring after the healing of the venereal ulcers

## Genital herpes

$>$ The herpes simplex virus is categorized into two groups, the herpes simplex virus type 1 (HSV-1) and the herpes simplex virus type 2 (HSV-2)
$>$ You can get the herpes simplex virus by having sexual intercourse with an infected person. Fluids found in herpes sores also carry the virus and can cause infection
$>$ The virus enters through the skin and thereafter the infection spreads to nerves in the skin
Signs and symptoms of Genital Herpes
$>$ Most people infected by the H.S virus have no signs and symptoms



# Page 47

When signs occur, they are small blisters that eventually break open and become raw painful sores
$>$ This causes itching in the infected area
$>$ The sores later form scabs and heal within a few weeks
$>$ Flu-like symptoms with fever and swollen lymph nodes may also appear
Treatment of Genital Herpes
$>$ There is no cure for genital herpes but the symptoms can be prevented with treatment
$>$ Antiviral medication reduces pain and discomfort from outbreaks of sores
$>$ Taking daily medication can also suppress the virus and reduce the risk of infecting others
Effects of sexually transmitted infections
$>$ STIs are a huge health and economic burden for developing countries
$>$ Herpes and syphilis dramatically increase the chances of getting infected with HIV
$>$ People with STIs are at 2-5\% more risk of getting HIV through sexual intercourse
$>$ Syphilis in pregnant women is linked with a low birth weight of babies, premature birth and stillbirth
$>$ Gonorrhea causes pelvic floor infections and infertility in women
$>$ Controlling sexually transmitted infections
$>$ In Zimbabwe, the Ministry of Health is running health awareness campaigns to educate and inform the public on the effects of sexually transmitted diseases
$>$ Programs promoting condoms, vaccines and screening can help reduce the incidence of STIs
$>$ The mass treatment of vulnerable groups (such as pregnant women) and high-risk groups (such as sex workers) helps to reduce numbers of new infections
$>$ The best way to prevent STIs is abstinence, in other words, not to have sex
$>$ If a person is sexually active, it is important to practice safe sex, by always using a barrier such as latex condoms, during sexual intercourse
$>$ This is not a guarantee against STIs, but condoms can significantly reduce the risk the risk of STIs and HIV
$>$ Limiting the number of sexual partners reduces a person's risk to get STIs
$>$ A sexually active person should get regular tests for STIs
$>$ The guidelines are twice a year for gonorrhea and once a year for syphilis
$>$ Sexually active women should have annual Pap smear to detect cervical cancer
QN. How are these sexually transmitted diseases transmitted?(5)

# Other communicable diseases 

$>$ A communicable disease is a disease that can be passed on from person to person, or in some other way
$>$ Infections are caused by pathogens such as viruses, bacteria or protozoa entering the body and causing illness
$>$ The table below shows some examples of pathogens commonly found in Zimbabwe and the diseases they cause



# Page 48

| PATHOGEN TYPES | INFECTIOUS DISEASE |
| :-- | :-- |
| Bacteria | Cholera, typhoid fever, tuberculosis |
| Protists | Malaria, sleeping sickness |
| viruses | Ebola virus disease, HIV/AIDS, polio, <br> influenza, chicken pox |

> Infectious diseases' spread can be reduced by good health habits such as washing hands, cleaning and disinfecting surfaces, covering your mouth and nose when sneezing, not sharing personal items and staying at home when ill

# Malaria 

> Is caused by a plasmodium, a parasitic protozoan, found in the salivary glands of the female mosquito of the anopheles genus
> The anopheles mosquito is a vector, that is, an insect carrying a parasite to its next host
$>$ The malaria parasite completes its life cycle partly in the female mosquito and partly in humans
The life cycle of the malarial parasite
$>$ When the anopheles female mosquito (first vector) bites a human, the malaria parasites are injected into the bloodstream
> The malaria parasites travel in the blood to the liver and invade the liver cells
$>$ The malaria parasite reproduces asexually in the liver cells, forming thousands of parasites
$>$ The parasites are released from the liver into the blood, where they enter the red blood cells
$>$ In the red blood cells parasites reproduce asexually
> The parasites burst the red blood cells causing cycles of violent feverish attacks of malaria
$>$ The released parasites then infect new red blood cells
$>$ Some of the parasites become male and female gametocytes
$>$ When a mosquito (second vector) bites an infected human, it sucks up the blood and the gametocytes pass into the mosquito's intestine
> Inside the mosquito, the male and female gametocytes become gametes
$>$ Fertilization takes place inside the mosquito and the parasites mature
> Mature parasites finally leave the mosquito's intestine and migrate to its salivary glands



# Page 49

![img-50.jpeg](img-50.jpeg)

# Signs and symptoms of malaria 

$>$ The symptoms appear about two weeks after infection
> These symptoms include high fever, shivers and sweats, headaches, vomiting and an enlarged spleen
$>$ In some cases the malaria parasite attacks the brain and the patient can fall into a coma and die

## Controlling and treating malaria

> There is no vaccine for malaria but the disease can be prevented by taking preventative drugs such as quinine and chloroquine when visiting a malaria prone area
$>$ Other preventative drugs are paludrine, deltaprim, malasone and malaquine
> High rates of malaria occur in the lowveld of Zimbabwe, in the Zambezi escarpment and in Mashonaland Central.
> Other ways of preventing the disease are to sleep under mosquito nets, spray mosquito repellents and to wear long-sleeved clothes from early evening when mosquitos become active
$>$ The best protection against malaria is to avoid being bitten especially for little children who cannot be given antimalarial drugs
$>$ Stagnant waters should be drained to destroy breeding areas
> Spraying oil on the surface of stagnant water such as drains suffocates and kills mosquito larvae
$>$ In some rural areas, the poison DDT is used to spray houses to kill mosquitos
> Biologically anopheles mosquitos can be controlled using toxins produced by bacteria referred to as Bacillus thuringiensis and by stocking ponds with fish that feed on mosquito larvae
$>$ Cutting down tall grasses to destroy their habitat, breeding places and food

## Typhoid

> Is caused by the bacterium salmonella typhosus and is common in most parts of the world but Southern Asia, Africa, Latin America, India and Pakistan are high risk areas
$>$ The bacteria spread through contaminated food and water

## OlmOCR Image Descriptions

### Image: img-50.jpeg

![img-50.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-50.jpeg.png)


s": [{"description": "The diagram illustrates the life cycle of malaria parasites. It shows a mosquito with malaria parasites inside it. The male and female gametocytes become gametes when the infected mosquito bites another person. This triggers recurrent chills and fever cycle."}]}





# Page 50

The bacteria enter the small intestine and the bloodstream of a person that has come into contact with contaminated food or water
$>$ In the blood, the bacteria are carried by the white blood cells to the liver, spleen, gal bladder and bone marrow where they multiply very quickly

# Signs and symptoms of typhoid 

> These include high fevers, weakness, stomach pains, headaches, a poor appetite and a rash (rose spots) on the abdomen and chest
$>$ The first signs of infection are high temperature, stomach pains and diarrhea
$>$ Typhoid can be diagnosed by testing a stool sample or blood sample

## Controlling and treating Typhoid

> Treatment with antibiotics usually leads to patients recovering fully within 7-10 days
$>$ There are vaccines for people travelling to high risk areas
$>$ Other methods of control are putting good sanitation in place, giving people access to clean water, ensuring waste disposal and protecting food supplies from contamination
$>$ Personal hygiene is critical to avoid contracting typhoid
$>$ People with typhoid should not handle or prepare food

## Ebola virus disease (EVD)

$>$ EVD is caused by the deadly Ebola virus that is transmitted to humans through close contact with the blood, secretions and organs of animals such as chimpanzees, gorillas or fruit bats that are infected
$>$ This contact happens mostly when people hunt bush meat in the rain forests
> Human-to-human transmission of the Ebola virus takes place when a person touches the broken skin of an infected person or comes into contact with infected body fluids such as blood, saliva, sweat, vomit, semen and breast milk
$>$ Touching a person who has died from EVD or even touching contaminated bedding or clothing may lead to infection
$>$ A person is infectious as long as one's blood contains the virus

## Signs and symptoms of EVD

$>$ The incubation period of EVD is 2-21 days after infection
$>$ The first symptoms of EVD are headaches, high fever, weakness, muscle pain and a sore throat
$>$ The virus destroys all tissues and organs of the body, except for the skeletal muscles and bones
$>$ The patient will suffer from a high temperature, vomiting, diarrhea and a rash about 10 days after the appearance of the first symptoms
$>$ The rash is caused by blood clots that weaken blood flow and the spots get bigger as the disease progresses
> By day 11, there will be bruising, brain damage and external bleeding from the eyes, nose, mouth and anus
> By day 12-16, there is massive internal bleeding of the lungs, brain, liver, intestines, kidneys, testicles, and breast tissue
$>$ The person loses consciousness, will have seizures and will eventually die

## Controlling and treating EVD



# Page 51

There is no cure for EVD so that treatment is limited to supportive therapy
> Very ill patients require intensive supportive care: balancing the patient's fluids and electrolytes, maintaining their oxygen levels and blood pressure and treating complicating infections early
$>$ The Ebola virus kills about $65 \%$ of its victims
$>$ To protect yourself from getting EVD, make sure you wash your hands with soap and water or with an alcohol-based disinfectant
> People should cover their nose and mouth when coughing and sneezing, using a handkerchief or tissue
$>$ Avoid contact with blood and bodily fluids
$>$ Do not handle clothes, bedding, needles, and medical equipment that may have been contaminated with an infected person's blood or body fluids
$>$ Do not touch someone at a funeral who has died of EVD

# Cholera 

$>$ Is a bacterial disease caused by some strains of Vibrio cholerae
$>$ It is mostly waterborne and is common in areas with poor sanitation and poor water purification facilities
> The disease also spreads through food that is contaminated by human or animal faeces, by human carriers, flies and rodents

## Signs and symptoms of cholera

$>$ A cholera patient will suffer from watery diarrhea (rice water) and vomiting
$>$ This can lead to dehydration and, if fluids and electrolytes are not replaced, the patient will go into coma and die

## Controlling and treating cholera

$>$ Can be treated by administering tetracycline and chloramphenicol to the patient
$>$ There are vaccinations against cholera
$>$ To prevent the spread of cholera, good food hygiene is essential
> Proper use of toilet facilities is vital such that faeces do not end up in water sources; e.g. building Blair pit toilets in rural areas
$>$ Washing of hands with soap and water after using the toilet is necessary
$>$ Having enough treated or boiled clean water for drinking and cooking

## Lifestyle diseases and substance abuse

> These are diseases caused by a person's habits or the way people live their lives
$>$ Common examples are alcohol and substance (drug) abuse, smoking, a lack of physical exercise and unhealthy eating

## Effects of tobacco smoking on health

$>$ Tobacco smoke contains over 4000 harmful and poisonous substances
$>$ Among these tar and carbon monoxide are known carcinogens, i.e. cancer-causing substances

## Effects of tobacco smoke on human health



# Page 52

| Chemicals in tobacco smoke | Properties of the chemical | Effects on the body |
| :--: | :--: | :--: |
| Nicotine | $>$ Addictive <br> $>$ Causes release of the hormone adrenaline <br> $>$ Makes blood clot easily | $>$ Increase in heartbeat and blood pressure <br> $>$ Increased risk of blood clots in blood vessels |
| Carbon monoxide | $>$ Combines with haemoglobin to form carboxyhaemoglobinreduces oxygen transport efficiency of red blood cells <br> $>$ Increases the rate of fatty deposits on the inner arterial walls <br> $>$ Damages the lining of blood vessels | $>$ Death if concentrations in the air are increased by $1 \%$ <br> $>$ Causes coronary heart diseases <br> $>$ Increased risk of atherosclerosis <br> $>$ Increased risk of blood clotting in the arteries |
| Tar | $>$ Is carcinogenic (contains cancer causing chemicals) <br> $>$ Paralyses cilia lining the air passages | $>$ Blockage in the air sacs and reduction in gas exchange efficiency <br> $>$ Dust particles trapped in the mucus lining the airways cannot be removed |
| Irritants (e.g. hydrogen cyanide, $\quad$ acrolein, formaldehyde) | $>$ Paralyses cilia lining the air passages | $>$ Increased risk of chronic bronchitis and emphysema |

- The cilia of the epithelium are paralysed. Mucus and dust particles cannot be removed
- The airways become blocked, making breathing difficult
- The person has to cough persistently to clear his airways in order to breathe. This increases risk of getting lung infections


# Emphysema 

$>$ Tar irritates alveoli walls causing persistent and violent coughing which may lead to emphysema.
$>$ The signs of emphysema are as follows

- Violent coughing breaks the partition walls between the air sacs leaving large spaces or blebs
- The blebs fill up with mucus and thus surface area for gaseous exchange decreases
- The lungs become inflated with air
- The lungs lose their elasticity



# Page 53

- Breathing becomes difficult. The person wheezes and suffers severe breathlessness
- Carbon dioxide also collects in the blebs, eventually leading to suffocation

Coronary heart disease
$>$ Carbon monoxide is absorbed from the lungs into the blood stream where it combines with haemoglobin forming carboxyhaemoglobin in the red blood cells
$>$ With carbon monoxide attached to the haemoglobin, less oxygen is carried to the cells for respiration
$>$ The body increases its breathing and heart rates because of the oxygen shortage
$>$ Therefore, the heart works harder increasing chances of heart attacks
$>$ New-born babies whose mothers smoked while pregnant usually have lower birth weights and often have breathing problems
$>$ Passive smoking is also dangerous, i.e. inhaling smoke from a cigarette smoker
Excessive alcohol consumption
$>$ Alcohol is a depressant
$>$ It can enter the brain and change the way you think and feel
$>$ It affects the proper functioning of the nervous system
$>$ When under the influence of alcohol, pain messages are impaired and it is difficult to coordinate body movements
$>$ It can make the user feel happy and carefree and have impaired judgement especially in dangerous situations such as driving
$>$ Alcohol results in reduced self-control and reduces reaction time
$>$ The long-term use of alcohol causes liver cirrhosis or liver damage
$>$ The liver is severely scarred so that it shrinks and hardens
$>$ The hardened tissue reduces blood flow through the liver, leading to poor liver function.
$>$ This, in tur, affects many body functions
$>$ Alcohol, being a depressant, can lead to addiction, depression, memory loss, aggression and anxiety
$>$ Alcohol abuse leads to people losing their inhibitions so that they behave impulsively
$>$ It can even lead to actions such as self-harm and suicide
$>$ Alcoholism is also linked to mental conditions such as having hallucinations and believing that you are being persecuted
$>$ Alcohol has social implications such as neglecting families financially, emotionally and morally, leaving members being destitute
$>$ Other social issues are that the alcoholics are often on sick leave more than the nonalcoholics
$>$ Social immorality can result in unacceptable behaviour such as prostitution and crime
$>$ Alcohol drinkers are often unaware of their problems
$>$ Alcohol abuse may lead to unemployment which in turn may lead to more drinking out of hopelessness
$>$ A developing foetus is affected by the drinking of the mother during pregnancy
$>$ The first four months of pregnancy are important for brain development
$>$ The usage of alcohol during pregnancy can make the baby addicted to alcohol



# Page 54

- Some babies are born brain- damaged and will have learning disabilities
$>$ This condition is known as Foetal Alcohol Syndrome (FAS)
Effects of use of mandrax and cannabis/mbanje
$>$ Alteration of personality
$>$ Loss of self-control or maniac behaviour
> Criminal tendencies like violence or murder
> Increased chances of HIV infection
$>$ Addiction
$>$ Can cause blood poisoning
Effects of inhaling solvent e.g. glue sniffing
$>$ Results in :
- Hallucinations
- Reduced self control
- Nasal passage damage
- Heart muscle damage



# Page 55

# FORM 3 NOTES 

## PHYSICS SECTION

## DATA PRESENTATION

- Scientists carry out some observations and experiments and in the process, record the data in form of tables, tallies, line graphs, pie charts etc.


## Pie Chart

- Is a diagram used to represent data in a circle form for example a class of learners which is grouped into gender i.e. males and females.
- Also can be used to show marks got by few pupils in a maths test.

How to construct a pie chart
Table 1 below shows average rainfall of a region over six months

| Months | Average rainfall $(\mathrm{mm})$ |
| :-- | :-- |
| January | 40 |
| February | 50 |
| March | 45 |
| April | 35 |
| May | 20 |
| June | 10 |

a) Calculate the percentage of your data relative to the total. E.g. the percentage for June $=$ average rainfall in June divided by total rainfall over six months.
b) Calculate the angle which corresponds to the percentage out of $360^{\circ}$ e.g. $5 \% \times 360^{\circ}=18^{\circ}$
c) Draw a circle to represent the total quantity and find the central point.
d) Draw a vertical line from the centre to the top of the circumference.
e) Draw in segments measuring them using a protractor starting with the largest segment.
f) Different shading may be used.
g) Label the pie chart either by numbering or writing in some words.

The interpretation and explanation of the pie
Pie charts are visually appealing as they are easy to understand.

## Line Graphs

- A line graph is used to show some relationships between two sets of results / comparing two sets of quantities that depend on each other e.g. the size of a family and the food required for that family.
- It may be used to show changes over a period of time for example growth rate of maize broilers over a period of one month or changes in temperature of water being heated at given time intervals.
How to draw a line graph



# Page 56

a) Draw the x - axis and the y -axis.
b) Label the scale using variables (the scale which we are controlling should be the x -axis and the one which we cannot control should be the $y$-axis).
c) Select a suitable scale both axis.
d) Mark points using a dot.
e) Join the points using a line which must pass through all the marked points.

Bar and line graphs give more information than pie charts hence they are more useful.
Question 1
Exercise 16.2 page 128. (5)
Question 2
Use data on table 1 on page 1, draw a bar graph. (4)

# MEASUREMENT 

Physics experiments involve the measurement of a variety of quantities, and a great deal of effort goes into making these measurements as accurate as possible.

- Before a measurement can be made, a standard or unit and appropriate instrument must be chosen.
- Three quantities measured in physics include, length, mass, voltage, current and time.
- The SI (System International Units) system is a set of metric units now used in many countries.
- It is a decimal system in which units are divided or multiplied by 10 to give smaller or larger units.


## Length

- Is the distance between two points.
- The SI unit for length is the metre (m).
- A rule (ruler) is rigid piece of wood, plastic or perspex with markings.
- It is used to measure length for distances between 1 mm and 1 metre;
- Your eye must be directly over the mark on the scale to avoid parallax errors.
![img-51.jpeg](img-51.jpeg)
- $1 \mathrm{~cm}=10 \mathrm{~mm} ; 1 \mathrm{~m}=100 \mathrm{~cm} ; 1 \mathrm{~km}=1000 \mathrm{~m} ; 1 \mathrm{~km}=100000 \mathrm{~cm}$.

## OlmOCR Image Descriptions

### Image: img-51.jpeg

![img-51.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-51.jpeg.png)


s": [{"description": "The diagram illustrates a comparison between correct and wrong visual perceptions. On the left side, there is an arrow labeled 'correct' pointing towards a horizontal line at 70 units. This indicates that the perception is accurate when aligned with this mark. On the right side, another arrow labeled 'wrong' points to a horizontal line at 80 units, showing incorrect perception if not aligned properly. The diagram also includes a dashed line connecting these two perceptions, emphasizing the difference in alignment and accuracy."}]}





# Page 57

Convert
210 cm to $\mathrm{m} ; 33 \mathrm{~mm}$ to $\mathrm{cm} ; 96 \mathrm{~m}$ to km and 840 m to km .

Activity: 17.1 Step Ahead f3 page 130
Measuring tape

- Is a flexible piece of material with markings similar to those on the ruler.
- It is used to measure objects that are not flat or straight such as the circumference of a pipe.


# Voltage 

- Voltage is the difference in in electric potential between two points or objects. Voltage is measured in volts $(\mathrm{V})$ and is measured by a voltmeter (connected in parallel). If a cell has 1 Volt, it delivers 1 Joule of energy to each coulomb of charge (J/C).
- Voltage = Energy / Charge
- Volts = Joules / Coulomb
- $\mathrm{V}=\mathrm{E} / \mathrm{C}$


## Measuring Electricity / Current

- Electric current is the flow of electricity in a complete circuit. Or flow of electrons through a conducting circuit.
- An ammeter measures the strength of an electrical current, that is, how many charges move through a circuit per second.
- Measured in Amperes usually abbreviated as Amps / (A).
- The ammeter is connected in series in a circuit.
- State the formula for current. [1]

Activity 17.3 Step Ahead f3 page 131

## Vernier Calliper

- Is a tool used to take highly accurate measurements.
- It has two scales, the main scale with markings similar to those on a ruler and a vernier scale with markings in 0.1 mm increments.
- This measures diameter of very small objects to 0.1 mm .

How to use Vernier callipers

- Close the jaws to allow for zero errors.
- Open the jaws slowly to fit the object firmly.
- To take a reading, first look at the main scale and then from the Vernier scale
- Record the measurement.



# Page 58

![img-52.jpeg](img-52.jpeg)

Activity: 17.2 Step Ahead f3 page 131

# Density 

- This is the mass per unit volume of a substance. The SI unit of density is the grams per cubic metre.

Density $=\underline{\text { mass }}$
volume

- To convert a density from $\mathrm{g} / \mathrm{cm} 3$, normally the most suitable unit for the size of sample we use, to $\mathrm{kg} / \mathrm{m} 3$, we multiply by 10 to the power of 3 .
- Using the symbols $\rho$ (rho) for density, $m$ for mass and $V$ for volume, the expression for density is

$$
\mathrm{p}=\frac{\mathrm{m}}{\mathrm{v}}
$$

Rearranging the expression gives
$\mathrm{M}=\mathrm{V} \times \mathrm{p}$ and $\mathrm{V}=\frac{\mathrm{m}}{\mathrm{p}}$

To determine the density of a liquid

- Weigh a measuring cylinder on a balance.
- Fill the measuring cylinder with some liquid and weigh.
- Subtract the two measurements of mass from one another i.e. the change in mass is the mass of the liquid and the volume is shown on the scale, then use the formula:

$$
\mathrm{p}=\frac{\mathrm{m}}{\mathrm{v}}
$$

Activity: 17.5 Step Ahead f3 page 132

Density of irregular objects

- Weigh an irregular object and record its mass.
- Pour water in a measuring cylinder and take a reading.
- Place an object in the cylinder and measure new level of water.

## OlmOCR Image Descriptions

### Image: img-52.jpeg

![img-52.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-52.jpeg.png)


s": [{"description": "The diagram illustrates a vernier caliper, a precision measuring instrument. The caliper features two jaws: internal and external. The internal jaws are used for measuring the inside diameter of objects, while the external jaws measure outside diameters or other distances. The caliper includes a locking screw to secure the jaws in place after measurement.\n\nThe vernier scale is an auxiliary scale that provides greater precision than the main scales. It is aligned with the metric scale and imperial scale for accurate readings. The depth measuring blade allows for precise measurements of depths or heights.\n\nKey components include:\n- Internal jaws: Used for inside diameter measurements.\n- External jaws: Used for outside diameter or distance measurements.\n- Locking screw: Ensures the jaws remain in place during measurement.\n- Vernier scale: Provides additional precision.\n- Metric scale: Main scale for metric measurements.\n- Imperial scale: Main scale for imperial measurements.\n- Depth measuring blade: For depth or height measurements."}]}





# Page 59

- Subtract the first reading from the second reading to get the volume of the irregular object.
- Divide the mass by the volume to get its density.

Activity: 17.6 Step Ahead f3 page 133

# Force 

- Is a push or a pull. It can cause a body at rest to move, or if the body is already moving it can change its speed or direction of motion. A force can also change a body's shape or size.
- The unit of force is the newton $(\mathrm{N})$.

Force of friction

- Is force that opposes motion.
- It produces heat, stops moving objects and causes wearing away of materials which are in contact.
- Gives balance to bodies,

Qn 1. State any four ways of reducing friction. [4 ]
2. State the principle of moments.
3. Explain the turning effects of force. [2]

## Weight

- is the amount of gravitational force that acts on an object, measured in Newtons, and given by the formula:
Weight $=$ mass $\times$ acceleration due to gravity $/ \mathrm{W}=\mathrm{mg}$.
- The weight of a body can be measured by hanging it on a spring balance marked in Newtons.
- Weights (and hence masses) may be compared using a balance.


## Mass

- Is the amount of matter in a substance.
- Is measured using a balance.
- Mass depends only on the inertia of an object.
- The more the inertia, the more the mass it has.
- A more massive object has great tendencies of resisting change in its state of motion.
- E.g. if two bricks are made of different substances, one can tell which brick is made of foam or cement by pushing the bricks and change its motion.
- The one with least resistance has least inertia, mass and thus made of foam.


## Centre of Mass

- Is a point where the mass of an object is centred.


## Momentum

- Is a useful quantity to consider when bodies are involved in collisions and explosions.
- It is defined as the mass in motion. That is, all objects have mass so if all moving, have momentum.
- Is measured in kilogram metre per second ( $\mathrm{kg} \mathrm{m} / \mathrm{s}$ ) or newton second ( N . s).
- Momentum = mass x velocity.



# Page 60

- A 2 kg mass moving at $10 \mathrm{~m} / \mathrm{s}$ has momentum $20 \mathrm{~kg} \mathrm{~m} / \mathrm{s}$, the same as the momentum of a 5 kg mass moving at $4 \mathrm{~m} / \mathrm{s}$.

Inertia

- Newton's first law states that an object at rest stays at rest and an object in motion stays in motion with the same speed and direction unless acted on by an unbalanced force.
- Objects tend to keep on doing what they are doing.
- This natural tendency of objects to resist change in their states of motion is called inertia. e.g. The reluctance of a stationary object to move can be shown by placing a large coin on a piece of card on your finger. If the card is flicked sharply the coin stays where it is while the card flies off.

Newton's first law of motion

- Movement in uniform motion is a state of all objects.
- An object in uniform motion will remain in uniform motion unless something changes its motion.
- Thus, if you roll a ball, it will eventually slow down and stop due to friction (external force).

Summary: A body stays at rest, or if moving it continues to move with uniform velocity, unless an external force makes it behave differently.

Newton's second law

- It shows that the acceleration a is

1. directly proportional to the applied force F for a fixed mass, i.e., a $\alpha \mathrm{F}$, and
2. inversely proportional to the mass m for a fixed force, i.e., a $\alpha 1 / \mathrm{m}$.

Combining the results into one equation, we get a $\alpha \mathrm{F} / \mathrm{m}$ or $\mathrm{F} \alpha \mathrm{ma}$
$\mathrm{F}=\mathrm{kma}$
where k is the constant of proportionality.
One newton is defined as the force which gives a mass of 1 kg an acceleration of $1 \mathrm{~m} / \mathrm{s} 2$, i.e., $1 \mathrm{~N}=1 \mathrm{~kg}$ $\mathrm{m} / \mathrm{s} 2$.
So if $\mathrm{m}=1 \mathrm{~kg}$ and $\mathrm{a}=1 \mathrm{~m} / \mathrm{s} 2$, then $\mathrm{F}=1 \mathrm{~N}$.
Substituting in $\mathrm{F}=\mathrm{kma}$, we get $\mathrm{k}=1$ and so we can write $\mathrm{F}=\mathrm{ma}$
Example 1: A force of 10 N is applied to the body of mass 15 kg . Calculate the acceleration.
Solution: $\quad \mathrm{F}=\mathrm{ma}$
$\mathrm{F}=10 \mathrm{~N}$
$\mathrm{M}=15 \mathrm{~kg}$
$10 \mathrm{~N}=15 \mathrm{a} \div 15$ both sides
$\mathrm{a}=0.6666$ therefore $\mathrm{a}=0.67 \mathrm{~m} / \mathrm{s}^{2}$
Experiment
Aim: Using a ticker timer to measure time



# Page 61

Materials: a ticker timer, ticker tape, stop watch or clock, a machine trolley or wind up/pull back toy car (optional)

Procedure

1. Thread a short length of ticker tape through the ticker timer. If there is a carbon paper disc, make sure the tape goes underneath the disc.
2. Turn the ticker timer on for a few seconds. It vibrates rapidly and hits the top of the carbon paper. It makes a lot of dots on the tape, at regular intervals.
3. Remove the tape from the ticker timer. If the tape didn't move when the ticker timer was switched on, then all the dots will be in the same place.
4. Thread a longer piece of ticker tape, about 1 metre long, through the ticker timer. Switch the ticker timer on. Pull the tape slowly through the ticker timer.
5. Check the tape to see if you can see each individual dot, with a space between. We can say that each dot-to-dot space stands for a 'tick' of time.
6. Thread another 1 metre piece of tape through the ticker timer.
7. You need a 'start' signal and a 'stop' signal. These could be hand-claps by one of your group or by your teacher. They should be just a few seconds apart. Pull the tape slowly and switch the ticker timer on at the start signal. Switch it off at the stop signal.
8. Count the number of dot-to-dot spaces between the start and the stop. That is the time between the signals, measured in 'ticks'.
9. Use a fresh piece of tape, and a stopwatch or stopclock. Pull the tape through the ticker timer for 3 seconds. Find out how many 'ticks' there are in 3 seconds. Find out how many there are in 1 second. Work out the time in seconds that is the same as 1 tick.

# Results 

Once you have determined how many dots are made in 1 second (or 3 seconds), you can measure the time by dividing the number of dots by how many are made in 1 second.



# Page 62

# MACHINES 

- A machine is mechanical system that makes hard work easier to do e.g., bottle opener, pliers, levers, pulleys, and gears and incline planes.
- The principles of machines are : Mechanical Advantage (MA), Velocity Ratio (VR) and Efficiency.


## I. Levers

-Levers are simple machines
-It is a bar or string tool used for lifting or moving bearing stiff objects. Levers have got a pivot/fulcrum where the lever turns, the point where the load is placed and another end where effort is applied e.g. wheelbarrows, crowbar, hammer, e.t.c.

- Size of effort depends on distance of load and effort from the pivot.
- The greater the distance of effort from the pivot, the smaller the size of the effort e.g. borehole can be made more efficient by putting a longer handle i.e. increasing the distance of the effort from the pivot.
![img-53.jpeg](img-53.jpeg)

Mechanical advantage

- Is the ratio of the load lifted to the effort applied. A machine makes big jobs lighter and thus an advantage, called Mechanical Advantage.

Mechanical advantage $(\mathrm{MA})=$ load (L)
Effort (E)
E.g. if effort of 40 N is used to lift 80 N of soya beans. Calculate the MA
$\mathrm{MA}=\mathrm{L} / \mathrm{E}=80 \mathrm{~N} / 40 \mathrm{~N}=2(\mathrm{MA})$

- The lever has in this case enable the effort to raise a load twice as large.
- Thus a lever moved twice the distance of the load.

Velocity Ratio (VR)

- Is the ratio of the distance moved by the effort to the distance of the load.

VR $=\frac{\text { Distance moved by effort }}{\text { Distance moved by load during the same time (AC) }}$
Work done

## OlmOCR Image Descriptions

### Image: img-53.jpeg

![img-53.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-53.jpeg.png)


s": ["The diagram illustrates a lever system with various labeled parts. The load is represented by the weight W at point A, which moves a distance x along the horizontal axis. The fulcrum or pivot point is located at O. The effort moves are shown as the distance y from the fulcrum to point B, where the force is applied. The diagram also indicates that the distance load moves and effort moves are perpendicular to their respective axes. The text labels include 'distance load moves', 'load', 'fulcrum/pivot', and 'distance effort moves'. This setup is typical for understanding mechanical advantage in lever systems."]}





# Page 63

Is the amount of force multiplied by the distance moved in the director of force.
Work done (joules) = force (newtons) x distance (meters)
Example:
A lever is used to lift a 2500 N rock as shown below:
![img-54.jpeg](img-54.jpeg)

Calculate
a) Unknown force F
b) MA
c) VR
d) Efficiency

# Efficiency 

- Is the ability of machine to do work satisfactorily. It can be reduced by friction or the weight of the machine hence no machine is $100 \%$ efficient.

Efficiency $=$ work obtained from machine $\times 100 \%$
work put into machine
Or load x distance moved by load $\times 100 \%$
effort x distance moved by effort

## 2. Inclined planes

-An inclined plane is a sloping which is less than a right angle $\left(90^{\circ}\right)$
-It is a machine used to lift heavy loads using a smaller effort but the load move through a great distance. -The smaller the angle of the inclined plane the smaller the effort applied. It is easier to load a lorry by pushing up an inclined plane than lift the load vertically.
![img-55.jpeg](img-55.jpeg)

$$
\begin{aligned}
& \text { M.A }=\frac{\text { load }}{\text { Effort }} \\
& \text { V.R }=\underset{\text { distance moved by Effort }}{\text { distance moved by load }} \\
& =\underset{\text { CB }}{\mathrm{AB}} \quad=\frac{1}{\sin \varnothing}
\end{aligned}
$$

## OlmOCR Image Descriptions

### Image: img-54.jpeg

![img-54.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-54.jpeg.png)


s":"The diagram illustrates a mechanical system involving forces and distances. A load of 2500N is applied at one end, with an unknown force F acting at another point. The distance between the load and the unknown force is labeled as 1m, while the distance from the load to the ground is marked as 1.5m. The diagram appears to represent a scenario where forces are being balanced or analyzed for equilibrium."}


### Image: img-55.jpeg

![img-55.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-55.jpeg.png)


s": [{"description": "The diagram illustrates a scenario involving the movement of a paraffin drum. A person is shown pushing the drum up an inclined plane labeled AB at an angle θ with respect to the horizontal. The weight W of the drum acts downward along the incline. The drum is connected to a scotch cart via a rope, which is wound around a pulley system. The cart is equipped with a paraffin drum on its side, indicating that it may be used for transporting or storing paraffin. The diagram suggests a mechanical advantage setup where the force applied by the person is multiplied as the drum is pulled up the incline."}]}





# Page 64

# 3. Pulleys 

-A pulley is wheel with a groove through which a rope passes. Two or more pulleys on the same axle is a pulley block.
-Pulleys are used to lift heavy loads. They change the direction in which the effort is applied.
Types of pulleys

1. Single fixed pulley

- enables lifting or load by applying a downward force. if there is no friction, it will have a MA and VR of one but because of friction the effort is always slightly bigger than the load.
![img-56.jpeg](img-56.jpeg)
a. $\quad$ M.A $=\frac{\text { load }}{\text { effort }}$
b. V.R $=1$
c. EFFICIENCY $=\frac{\text { M.A X } 100 \%}{\text { V.R }}$

2. Single movable pulley
-The effort applied is two times the load since two parts of ropes supports one load, if there is no friction, VR and MA would be 2 but in practice is always slightly less due to friction.
![img-57.jpeg](img-57.jpeg)
3. Block and tackle

- Normally used in crane $s$, it consists of two blocks each with one or move pulleys mounted on the same axle.
- Each fixed pulley simply changes the direction in which the effort is applied.
- Each pulley increases the MA of the system by 2 (provided friction is negligible and light parts are used for the lower block.
- This means the more the pulleys; the easier it is to lift a load. A block and tackle combines fixed and movable pulleys.
NB: In pulleys
-Efficiency increase as the load increases.
-Efficiency is reduced by friction in strings and weight of movable pulleys.
![img-58.jpeg](img-58.jpeg)
V.R = No. Of movable pulleys x $2=2$

## OlmOCR Image Descriptions

### Image: img-56.jpeg

![img-56.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-56.jpeg.png)


s": [{"description": "The diagram illustrates a pulley system with a weight of 10 kg hanging from the bottom. The weight is connected to a rope that passes over a pulley and is attached to a force applied at an angle of 10 cm from the vertical. The force applied is 100 N, directed towards the left. The tension in the rope is also indicated as 100 N on both sides of the pulley."}]}


### Image: img-57.jpeg

![img-57.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-57.jpeg.png)


s": [{"description": "The diagram illustrates a simple pulley system. A load is attached to the lower part of the pulley, while an effort is applied at the top. The pulley allows for the lifting of heavy loads with less force compared to direct lifting. The direction of the effort arrow indicates the upward force required to lift the load."}]}


### Image: img-58.jpeg

![img-58.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-58.jpeg.png)


s": [{"description": "The diagram illustrates a pulley system with three wheels. A force of 25 N is applied to the left side of the system, causing it to move in the direction indicated by the arrow. The distance from the point of application to the center of the first wheel is 40 cm. The forces acting on the system are shown as 25 N and 10 kg (with a weight of 98 N). The pulley system reduces the force required to lift the weight, with the effective length of the rope being 10 cm."}]}





# Page 65

## M.A $=\frac{\text { load }}{\text { effort }}$

V.R $=$ Number of pulleys in the system

$$
\text { Efficiency } \underset{\text { VR }}{\underline{\text { M.A }}} \quad \text { X } 100 \%
$$

## 4. Gears

- Are systems of wheels with interlocking teeth so that one wheel drives another.
- Bigger gears is the load gear and the small gear is the effort gear.
![img-59.jpeg](img-59.jpeg)
- M.A = Load

Effort

- $\quad$ V.R $=$ number of teeth on load number of teeth on effort

$$
\text { EFFICIENCY }=\underset{\text { V.R }}{\underline{\text { M.A }} \text { X } 100 \%}
$$

OR No. of effort gear x $100 \%$
No. of teeth on driven gear (load)
Wheel and axle

- Is a system that comprises of a big wheel attached to a small wheel that it turns.
- The direction of effort is opposite to that of load for example on a screw driver and screw, car steering wheel and the windlass.
- When the effort turns the wheel (radius R) a distance of one circumference $(2 \pi R)$, the load (radius r) turns a distance $=2 \pi r$, the circumference of the axle.
- $\mathrm{VR}=$ distance moved by effort Distance moved by load $=\frac{R}{r}$

Energy loses in machines
-In many machines, it is possible to obtain velocity ratio but not high value of mechanical advantage due to energy loses caused by friction.

Ways of improving efficiency
$>$ Lubricating - with oil or grease so that the surfaces can slide more easily over each other.
$>$ Using rollers or ball bearings so that surfaces roll rather than slide over each other.
$>$ Using lighter parts for machines because friction increases as the weight of the machine increases.
$>$ Making surfaces smooth - so that surfaces slide over each other easily.
$>$ Rough surfaces have more friction.
NB: Friction is useful in brakes, for stopping moving vehicles and for balance e.g. when wearing shoes in a rough surfaces.

## OlmOCR Image Descriptions

### Image: img-59.jpeg

![img-59.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-59.jpeg.png)


s": [{"description": "The diagram illustrates a gear system consisting of two gears: the load gear and the effort gear. The load gear is larger than the effort gear, indicating that it has more teeth. This setup is typical in mechanical systems where the load gear transfers torque to the effort gear, which requires less force to rotate due to its smaller size. The diagram labels 'teeth' on both gears, emphasizing their role in transmitting rotational motion and torque."}]}





# Page 66

# PETROL AND DIESEL ENGINES 

- Fuel engines such as petrol and diesel convert chemical energy into heat energy and then into kinetic energy.
Chemical energy $\rightarrow$ Heat energy $\rightarrow$ Kinetic energy
- Both petrol and diesel engines work by internal combustion but in slightly different ways.
- Both engine shave a fuel injection system from the tank to the engine and into the system.
- Fuel injection can be direct or indirect. Direct systems spray the fuel direct into cylinders while indirect uses the carburetor.


## The Carburettor

![img-60.jpeg](img-60.jpeg)

The carburettor is a connection to the engine used to filter petrol and mix it with air in desired proportions.
$\checkmark$ Petrol is cleaned by the petrol filter to remove dirt so that the jet does not get blocked.
$\checkmark$ The air filter filters dust and dirt from the drawn air.
$\checkmark$ The choke controls air supply.
$\checkmark$ The throttle accelerator controls the amount of petrol - air mixture to the engine.
$\checkmark$ Opening the throttle allows more mixture to the engine and speeds it up.

- Newer engines have electronic direct fuel injection instead of carburettors and fuel is delivered straight to the engine, the pressure caused by the quick expansion of the gas pushes piston down, rotating a flywheel connected to the crankshaft.


## The Petrol Engine

1. Intake Stroke

- Downward moving piston sucks a mixture of air and petrol gas into the cylinder through the inlet valve.
- The exhaust valve is closed.

2. Compression Stroke

- The piston moves upwards compressing the gas mixture.
- Both valves are closed.

## OlmOCR Image Descriptions

### Image: img-60.jpeg

![img-60.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-60.jpeg.png)


s": [{"description": "The diagram illustrates the process of air and petrol mixture to an engine. Air enters through an air filter which removes dirt. The filtered air then passes through a jet and is directed towards the petrol-air mixture to the engine. A choke controls the air supply. On the right side, petrol flows into a petrol filter that removes dirt before being directed back into the system."}]}





# Page 67

4. Ignition Stroke

- A spark jumps across a point in the spark plug exploding or igniting the petrol air mixture. This forces the piston to move downwards, rotating a flywheel connected to the crankshaft.
- Thus, the rotation used to drive the wheels of the car.
- Both valves are closed.


# 4.Exhaust Stroke 

- The piston moves upwards pushing the exhaust gases out through the exhaust valve.
- The inlet valve is closed while the exhaust valve is opened.
- And, as the piston moves down, it pulls more of the fuel air mixture in to restart the cycle.
![img-61.jpeg](img-61.jpeg)


## The Diesel Engine

1. Induction stroke

- Air is drawn into the cylinder through the inlet valve.

2. Compression stroke

- The piston moves upward, compressing the air so that so that it heats up.

3. Power or ignition

- Fuel is injected into the hot, compressed air through a central fuel injection valve, making it spontaneously ignite.
- The pressure due to expansion of gas pushes the piston, rotating a flywheel that is connected to the crankshaft. This drives the wheels of the car.

4. Exhaust stroke

- The piston moves upward again in the cylinder and pushes out the gas through the exhaust valve into the exhaust system of the vehicle.
- As the piston moves down, it pulls more fuel air mixture in to restart the cycle.

## OlmOCR Image Descriptions

### Image: img-61.jpeg

![img-61.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-61.jpeg.png)


s": [{"description": "The diagram illustrates the four-stroke cycle of an internal combustion engine. Stroke 1 is labeled as Intake, showing the petrol-air mixture entering through the inlet valve and moving past the piston. Stroke 2 is Compression, where the piston compresses the mixture. Stroke 3 is Ignition, with a spark-plug igniting the compressed mixture. Stroke 4 is Exhaust, where the burned gases are expelled through the outlet valve."}]}





# Page 68

![img-62.jpeg](img-62.jpeg)

State the difference between petrol and diesel engines
(6)

# The Crankshaft 

- It is driven by the pistons to transfer energy to the wheels.
- It is the main rotating shaft running the length of the engine.
- It is supported by main bearings
- As the piston move up and down, the connecting rods move the crankshaft around.
- The turning motion of the crankshaft is transmitted to the transmission and to the driving wheels.
![img-63.jpeg](img-63.jpeg)

## OlmOCR Image Descriptions

### Image: img-62.jpeg

![img-62.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-62.jpeg.png)


s": [{"description": "The diagram illustrates the four-stroke cycle of an internal combustion engine. The first stroke is the Induction Stroke (Stroke 1), where air enters through an open intake valve and the exhaust valve is closed. The second stroke is the Compression Stroke (Stroke 2), where both valves are closed, and the piston compresses the air-fuel mixture. The third stroke is the Power Stroke (Stroke 3), where fuel is injected into the compressed air-fuel mixture, igniting it and causing the piston to move downward, generating power. The fourth stroke is the Exhaust Stroke (Stroke 4), where the exhaust valve opens, allowing burned gases to be expelled from the cylinder as the piston moves upward."}]}


### Image: img-63.jpeg

![img-63.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-63.jpeg.png)


s": ["The image depicts a detailed view of an internal combustion engine's crankshaft and connecting rods. The crankshaft is shown with four pistons attached to it, each connected by a rod. The pistons are positioned at different angles, indicating the motion they undergo during the engine cycle. The crankshaft itself has multiple journals where the connecting rods attach, allowing for smooth rotation. This diagram illustrates the mechanical components essential for converting linear motion into rotational energy in an internal combustion engine."]}





# Page 69

# ENERGY AND HEAT TRANSFER 

## Heat Transfer

Three methods include conduction, convection and radiation.

Heat Transfer in Solids - Conduction
Experiment 1a.
To investigate the rate of heat transfer in different materials.

Materials: Bunsen burner or candle wax, rods, of different materials such as iron, steel, carbon.

Procedure
![img-64.jpeg](img-64.jpeg)

1. Hold the different rods with one end in the burner.
2. Remove the rod the moment you can feel it getting warm.
3. Sort the materials in order of how quickly heat was transferred from the flame to the end of the rod.
Results
Metals conducts heat better than non - metals.
Experiment 1b.
Comparing the rate of heat conduction
![img-65.jpeg](img-65.jpeg)

- After some time, the candle wax will melt and the match stick will fall in the order; copper, brass, aluminium, and iron.
- Therefore, copper conducts heat faster and iron the least.

Heat Transfer in Liquids (convection)
Experiment 2
To determine how well water conducts heat Step Ahead f3 page 154

Materials: a test tube, test tube holder, a bunsen burner, water, ice,

Procedure
![img-66.jpeg](img-66.jpeg)

1. Put a small block of ice into the test tube and add water until it is about three - quarters full.
2. Heat the water at the top as shown.
3. Use your hand to feel the temperature at the bottom of the test tube.

## OlmOCR Image Descriptions

### Image: img-64.jpeg

![img-64.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-64.jpeg.png)


s":"The diagram illustrates a bunsen burner with a hand holding a test tube above it. The bunsen burner is lit and has a flame at the top, indicating that it is in use. A metal rod extends from the hand to touch the flame, suggesting an action of heating or warming the test tube. The test tube appears to be held securely by the hand, ready for some chemical experiment or demonstration."}


### Image: img-65.jpeg

![img-65.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-65.jpeg.png)


s": [{"description": "The diagram illustrates a setup for an experiment involving the transfer of heat. A burner is placed at the bottom center, generating heat that is transferred to various materials. The materials include aluminum, copper, wax, brass, iron rod, and wooden block. Each material is labeled with its respective name, indicating their role in the experiment."}]}


### Image: img-66.jpeg

![img-66.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-66.jpeg.png)


s": [{"description": "The diagram illustrates a laboratory setup for a chemical experiment. A test tube is held by a test tube holder and placed over a Bunsen burner to heat the contents. The test tube contains boiling water at one end and cold water (with ice) at the other end, demonstrating a temperature gradient. This setup could be used for various experiments requiring controlled heating or cooling of substances."}]}





# Page 70

## Results

- The water at the top boiled while at the bottom remained cold.
- Heat does not conduct well through water.
- However, if we heat water at the bottom of the test tube, heat is quickly transferred throughout the liquid due to convection.


## Experiment 3

To demonstrate convection currents in water.
Method
![img-67.jpeg](img-67.jpeg)
i. Fill a beaker with water to about three quarters.
ii. Drop a crystal of potassium permanganate to the bottom edge of the beaker.
iii. Heat the water around the crystal.

## Results

When a liquid is heated, it expands and its density decreases. The liquid nearest heat source is less dense so it rises taking heat in it. The purple colour makes stream of water visible. The cooler, denser liquid moves downwards to heat source where it is warmed and then rises due to convection current.

Heat Transfer in Gases (convection)

## Experiment 4

To demonstrate convection currents in gases.
Apparatus: a box with two chimneys, candle, a rag or rolled paper,

Method
![img-68.jpeg](img-68.jpeg)
i. Position a lit candle inside the chimney to the left as shown.
ii. Place the back of your hand just above left chimney for about two seconds.
iii. Bring the lit brown paper to chimney A.
iv. Watch the movement of smoke through the clear front / glass window and describe the movement of smoke.
Observations and results
$\checkmark$ Smoke moves in the direction shown by the arrow.
$\checkmark$ The smoke in chimney A is dense, so it sinks. Thus, there is high pressure in region X.
$\checkmark$ The candle at the other end of the chimney heats the air around it, causing it to expand and become less dense, rise and escape through chimney B. Thus, region Y has low pressure.
$\checkmark$ Therefore, by pressure difference, smoke particles drift from X to Y . On reaching Y , the candle energizes the smoke which then become less dense and rise through chimney B.

## OlmOCR Image Descriptions

### Image: img-67.jpeg

![img-67.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-67.jpeg.png)


s": [{"description": "The diagram illustrates a beaker filled with water and a purple crystal at the bottom. Arrows indicate convection currents within the water, suggesting movement caused by heating from below. The term 'HEAT' is labeled at the bottom, indicating the source of heat that drives the convection process."}]}


### Image: img-68.jpeg

![img-68.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-68.jpeg.png)


s": [{"description": "The diagram illustrates a demonstration of atmospheric pressure and its effects. A lit candle is placed at the bottom center, creating low pressure around it due to the heat generated by the flame. This low pressure area causes air from the left side (labeled as 'B') to move towards the candle, indicated by the arrow. The glass chimney labeled 'Y' allows this air to flow upwards, maintaining a low-pressure environment below. On the right side, there is a high-pressure area created by smoke movement through a glass window labeled 'X'. This high pressure pushes the air from the left side towards the right, creating a visual representation of atmospheric pressure and its directional effects."}]}





# Page 71

# Experiment 5 

Aim: To investigating the effect of different surfaces on the rate heat is absorbed or emitted. Materials: two thermometers, 2 tins with lids, (one painted black and the other white), tap water, Procedure
![img-69.jpeg](img-69.jpeg)

1. Pour the same amounts of water into both tins.
2. Close the tins and place a thermometer in each tin.
3. Record the initial temperature of water in each tin.
4. Place the tins outside in the sun for about 20 minutes.
5. Record the temperature again.
6. Bring the tins into a shade or classroom for another 20 minutes.
7. Record your results in a table as below:

| Time of measurement | Temperature of black tin | Temperature of other tin |
| :-- | :-- | :-- |
| At start |  |  |
| After 20 minutes |  |  |
| After 40 minutes |  |  |

## Results

- Black or dull painted test tube records higher temperatures than white painted test tube.
- Black absorbs more heat than white surfaces. White reflects heat.
- Black surfaces are good emitters of heat while white are poor emitters of heat.

Heat and transparent objects

- .A house with a window facing the sun get hot in summer.
- Cars get very hot when left in the sun with all windows closed
- Glasshouses get warm quickly when the sun rises.
- Thus, heat moves through transparent objects such as glass and plastic.

Application of heat emission

1. In hot deserts people wear loose white clothes so as to reflect heat.
2. Milk and petrol tanks are painted white or are shiny to avoid heat entrance into the tank.

## OlmOCR Image Descriptions

### Image: img-69.jpeg

![img-69.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-69.jpeg.png)


s": [{"description": "The diagram illustrates an experiment to determine which surface absorbs heat better. Two thermometers are placed in a container labeled 'shiny tin' and another in a container labeled 'black tin'. The containers are exposed to sunlight through a window labeled 'sun'. This setup allows for comparison of the temperature rise between the two surfaces."}, {"description": "Another part of the diagram shows two more containers, one with a shiny tin and another with a black tin. These containers are placed in the shade. The question posed is 'Which surface emits heat better?'"}]}





# Page 72

# ELECTROMAGNETISM 

- There is a relationship between electricity and the force of magnets.
- The flow of current generates a small magnetic field around the wire caring current.


## Magnetic effect of an electric current

## Experiment 2

Aim: To show that a wire carrying an electric current generates a magnetic field.
Materials: three 1.5 V cells, a switch, connecting wire, thin copper wire, iron filings, a $5 \Omega$ resistor, Procedure

1. Connect copper wires as shown.
2. Dip the copper wire into the iron fillings. What happens?
3. Switch the current on and dip the copper wires into the iron filings. What happens?
4. Turn the switch off. What happens to the iron filings on the copper wire?
![img-70.jpeg](img-70.jpeg)

Results

- The electrical wire with current generates a magnet field around it.
- Iron filings are attracted to the wire.
- This type of magnetism is called electromagnetism.


## Motor effect

## Motors

A motor is a device which converts electrical energy to mechanical energy. Generators produce electricity by changing mechanical into electrical energy e.g. in power stations thus, a motor is the reverse of a generator.

## How It Works?

If a magnet is plunged into a coil of wires connected to an electrical meter (galvanometer), a current is induced in the coil. When the magnet is pulled out of the coil, a current is again induced, but in the opposite direction. This is due to the lines of force around the magnet cutting the wire of the coil.

## OlmOCR Image Descriptions

### Image: img-70.jpeg

![img-70.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-70.jpeg.png)


s": [{"description": "The diagram illustrates a simple electrical circuit. It consists of a battery connected to a switch and a resistor. The switch is labeled as 'switch' and the battery is labeled as 'battery'. The resistor is represented by a symbol resembling a zigzag line and is labeled as 'resistor'. The circuit is completed through iron filings, which are depicted as a dark area at the bottom of the diagram. A bare copper wire is also shown, indicating the path for current flow."}]}





# Page 73

# Experiment: Motor effect 

Aim: To demonstrate that a conductor carrying an electrical current experiences a force in the magnetic field.

Materials: a length of flexible wire, crocodile clips, 2 strong magnets / horseshoe magnet, battery with 6 V or more, aluminium foil,

Procedure
![img-71.jpeg](img-71.jpeg)

1. Note: do not close the switch for as long as the circuit is a short circuit. The large current will deplete the battery quickly.
2. Close the switch and observe what happens to the aluminium foil.
3. Reverse the connection of the battery and note the direction the foil moves.

## Results

The aluminium foils moves down as current flows as shown on the diagram.
4. If the terminals are reversed, the moves up.

## Conclusion

A current carrying wire's field and a magnetic field interact with one another to produce the motor effect.
4. The motor effect is used in making electric motors.

Which convert electrical energy into kinetic energy.
Direct Current (DC ) motor

- A wire that carries current is kicked out of a magnetic field in a direction that depends on the direction of flow of current in the wire relative to the direction of the magnetic field.

## OlmOCR Image Descriptions

### Image: img-71.jpeg

![img-71.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-71.jpeg.png)


s": [{"description": "The diagram illustrates a simple experiment involving the interaction between a horseshoe magnet and an aluminum foil strip. The opposite poles of the horseshoe magnet are shown facing each other, creating a magnetic field. An aluminum foil strip is placed in the path of this magnetic field. When the switch is closed, it completes the circuit, allowing electric current to flow through the system. The direction of the current is indicated by an arrow pointing from the positive terminal to the negative terminal of the battery. This setup demonstrates the principle of electromagnetic induction, where a changing magnetic field induces an electromotive force (EMF) in the aluminum foil strip."}]}





# Page 74

- If a wire is bent into a rectangular shape, and a an electrical current flows through it, it can be placed inside a magnetic field o that one side of the wire experiences an upward force, while the other side experience a downward force.
- If the wire is pivoted properly and current supplied is continuous, the wire will rotate.
- The current enters the coil through the right brush of the commutator, and leaves through the left brush.
- As the commutator segments exchange brushes every half cycle, the current that flows through each side of the rectangular coil changes direction hence causes rotation of the coil.
- An electric motor changes electric energy into mechanical energy.
![img-72.jpeg](img-72.jpeg)

Factors Affecting the Speed of the Electric Motor
a) Size of electric current - increases currents and speed of the motor.
b) Strength of magnet - the stronger the magnet, the stronger the magnetic field and the faster the motor/coil will turn.
c) Number of turns of coil - the more the number of turns of coil, the faster the motor moves.

# Generator Principle 

The functioning of a DC generator is based on the generator principle:

- When a conductor is placed in a changing magnetic field, or when a conductor is moved in a magnetic field, an electromotive force (emf) is induced in the conductor.
- Electromotive force is a difference in electrical potential and gives rise to electrical current.

The magnitude of electromotive force depends on -;
a) The strength of the magnet. The stronger the magnet, the more the induced current.
b) The number of turns of coil - The more the number of turns of the coil, the greater the induced current.
c) The rate at which the magnet moves cuts across the coil. The faster the rate of movement, the greater the induced current.
d) Area of the coil.

The Direct Current Generator (DC) generator

## OlmOCR Image Descriptions

### Image: img-72.jpeg

![img-72.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-72.jpeg.png)


s": [{"description": "The diagram illustrates the internal components of an electric motor. The pivot is shown at the center, with a magnet attached to it that produces rotation. The split-ring commutator is located below the pivot, and carbon brushes are connected to it. Arrows indicate the direction of current flow through the motor."}]}





# Page 75

- Electric motors use electrical energy to cause movement (mechanical energy), while electrical generators produce electricity from movement.
- The d.c. generator is similar to the a.c motor except that the coil of the generator is made to rotate. The split rings commutator causes an exchange of ring segments and brushes every time the coil is vertical.
- The overall effect is that the induced current always leaves the generator from one brush and enter through the other. Therefore, one brush stays positive and the other negative
- The current in the external circuit flows in only one direction.
![img-73.jpeg](img-73.jpeg)

Alternating current (AC) generator

- A direct current generator produces direct current while an alternating current produces alternating current.
- A simple change to the circuit of DC will change the type of current generated.
- Slip ring commutator is used so that each side of the rectangular coil is always attached to the same brush.
- Thus, current changes direction with every rotation of $180^{\circ}$.
![img-74.jpeg](img-74.jpeg)

## OlmOCR Image Descriptions

### Image: img-73.jpeg

![img-73.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-73.jpeg.png)


s": [{"description": "The diagram illustrates a simple electric motor. The key components include the split ring commutator, which is connected to the external circuit through brushes. As the motor rotates, mechanical energy is transferred from the rotating parts to the external circuit."}]}


### Image: img-74.jpeg

![img-74.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-74.jpeg.png)


s": [{"description": "The diagram illustrates a simple electric generator. It consists of a rotating coil with two slip rings connected to an external circuit. The coil is wound around a magnetic field created by a permanent magnet. As the coil rotates, it cuts through the magnetic lines of force, inducing an electromotive force (EMF) in the coil. This EMF causes current to flow in the external circuit when the brush makes contact with the slip rings. The mechanical energy input from the rotating coil is converted into electrical energy output by the generator."}]}





# Page 76

# ELECTRICITY AND ELECTROSTATICS 

## Electrostatics

Is the study of static electricity.
Electric charge is due to the presence of extra electrons (- ve) or absence of electrons (+ve) charge.

## Experiment 1

Static electricity
Materials: a woolen cloth or jersey, balloons, a plastic comb and a tap, string

## Procedures

i. Blow up 2 balloons and tie each one closed.
ii. Tie a long thread onto each end of the balloon.
iii. Give each balloon by charging it with a woolen cloth.
iv. Hold each balloon by the end of the thread and bring them together.
v. Observe what happens.

## Results

Because both balloons have like charges on their surfaces, they repel each other.

## Experiment 2

## Procedure

i. Rub a plastic comb with wool.
ii. Open a tap so thin, steady stream of water comes out.
iii. Bring the comb near the stream of water.
iv. What happens?

## Results

The stream of water is attracted to the comb as shown below:
![img-75.jpeg](img-75.jpeg)

Conductors -are materials that allow electrons to move freely in them. They cannot be charged except by holding them in an insulating handle to prevent the charge passing through one's body to the earth e.g. metals and carbon.

## Insulators

- Are materials in which electrons are firmly held by their atoms.
- They can be charged e.g. plastic like polythene and Perspex, nylon, rubber, our thunder clouds, etc
- As one rubs a rod, electron from it atom move into the cloth. The rod will then be short of electron hence become positively charged.
- The cloth will be negatively charged due to excess electron
- Charges generated by friction are called triboelectricity.


## Experiment 3

Aim: To demonstrate the behaviour of like and unlike charge brought together.
Materials: 2 polythene rods, 1 glass or Perspex rod, thread, 2 copper stirrups, a retort stand, a piece of fur , a piece of silk

## OlmOCR Image Descriptions

### Image: img-75.jpeg

![img-75.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-75.jpeg.png)


s": [{"description": "The diagram illustrates a water tap labeled \"water tap\" with a thin stream of running water flowing from it. The water is directed towards a statically charged comb labeled \"statically charged comb.\" This setup demonstrates an experiment to show the interaction between water and static electricity."}]}





# Page 77

# Procedure 

i. Set the experiment as shown below. Charge the polythene by rubbing it with fur. Place the charged rod on a stirrup suspended by a thread. Charge a second polythene rod in the same way and bring it towards the suspended rod.
ii. Charge a glass rod by rubbing it with silk. Now bring glass rod towards the suspended polythene rod.
iii. Record what happens.
![img-76.jpeg](img-76.jpeg)

## Results

- Rubbed polythene is therefore said to contain a negative charge.
- When a glass/Perspex is rubbed in hair or on a woolen cloth, it loses electrons, thus gaining a positive charge.
- A rubbed Perspex/glass is therefore said to contain a positive charge. When a polythene rod is rubbed, electrons are transferred into it but when a Perspex rod is rubbed, electrons move to it.


## Conclusion

- Like charges repel each other.
- Unlike charges attract each other.
- Charges exert force at a distant (the suspended rod was repelled or attracted).
- The field created by electrostatic charge is similar to the magnetic field.


## Questions

a) What are conductors and insulators?( 4)
b) Give two examples of conductors and two examples of insulators. (4)

The electroscope

- If an object with negative charges is placed near the ball of the electroscope, electrons in the electroscope plate or ball will be repelled down to the metal rod and to the metal leaves.
- Since each leaves will have a negative charge, they will repel each other and open out.

## OlmOCR Image Descriptions

### Image: img-76.jpeg

![img-76.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-76.jpeg.png)


s": [{"description": "Diagram (a) shows a setup with a stirrup, thread, and two polythene rods labeled A and B. Diagram (b) displays a similar setup but replaces the polythene rod with a glass rod."}]}





# Page 78

- Laboratory electroscopes detects static charges and magnitude of the charge. Lightning
- Rapid movement of air and small frozen water droplets in a thundercloud causes the frozen water droplets to be charged.
- The smaller water droplets charge positive and rise to the top of the cloud and the large droplets become negative and occupy the bottom of the cloud.
- Charging continues as violent movement continues in the cloud.
- Very high voltage builds up between positive and negative charges within the cloud.
- The negative charges at the bottom of the thundercloud repel electrons at the surface of the ground, pushing them deeper into the ground.
- The ground becomes positively charged.

Conduction path ways

- Conduction between positive and negative charges within the same cloud.
- Conduction between two clouds shown.
- Conduction between the bottom of the cloud and the ground.
![img-77.jpeg](img-77.jpeg)

Qn 7. Describe the houses below are protected from lightning? (6)
A lightning Conductor

- Protects tall buildings by providing electrons with an easy path to the ground.
- Lighting conductors are made of a metal rod with a sharp point, conducting wires must connect a conductor to a metal rod in the ground o that lightning strikes the building, the charges will flow through the conductor and safely into the ground.
- Electricity poles and telecommunication towers act as lightning conductors.

## OlmOCR Image Descriptions

### Image: img-77.jpeg

![img-77.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-77.jpeg.png)


s": [{"description": "The diagram illustrates the process of lightning formation within a cloud. It shows discharges occurring between the negative base and positive top (intra-cloud) of the cloud. There are also inter-cloud strikes where lightning occurs between different clouds. Additionally, typical cloud-to-ground lightning is depicted between the ground and negative charge centres."}]}





# Page 79

![img-78.jpeg](img-78.jpeg)

Precautions against Lightning

- Construct a lightning conductor.
- Do not shelter under tree or isolated ones during a thunderstorm.
- Disconnect roof - top television aerials and unplug computers and radios.
- Do not use landline telephones.
- Keep away from metallic objects like fences and electrical appliances and water sources.
- It is dangerous to be near hill tops, large rocks and tall objects.
- Make sure there is at least five metres between you and other people.

## OlmOCR Image Descriptions

### Image: img-78.jpeg

![img-78.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-78.jpeg.png)


s": [{"description": "The diagram on the left illustrates a lightning protection system. It shows a lightning rod mounted on a building with a copper cable and ground rod clamp connected to it. The copper cable strap is also shown leading to the ground rod. The GEM (Ground Enhancement Material) is indicated as part of the grounding process."}, {"description": "The diagram on the right depicts an electrical system involving a metal plate, pole, and conducting wire. The pole supports the metal plate, which is connected by a conducting wire to another structure or component."}]}





# Page 80

# OHM'S LAW AND RESISTORS 

## Resistance

- When applying a fixed potential difference across different components in a circuit, different values of current flows.
- This is due to that different components resist the flow of electrons by different amounts.
- Copper and aluminum offer little resistance to the flow of electric current hence used as electrical conductors.

Measuring resistance
Experiment 1
Aim: To measure resistance
Materials: 3 torch cells, a rheostat, some nichrome wire, a voltmeter, an ammeter, some conductors
Procedure
i. Connect a circuit as shown below:
ii. Starting with the rheostat at its minimum resistance, close the switch and record the voltmeter and ammeter readings.
iii. Increase the resistance of the rheostat by small amount and again record the readings of voltmeter and ammeter.
iv. Repeat step three until you have six pairs of readings.
v. Record the results in table and calculate the ratio $\frac{v}{I}$ for each pair of reading.
vi. Plot a graph.

Results
The ratio $\frac{v}{R}$ is a constant for a particular resistor.
Factors affecting resistance

- Length of a conducting wire and its cross - sectional area:
- If you measure the resistance of different length of wire with same cross - sectional area, you will find that doubling the length of wires will double its resistance. Thus, resistance is directly proportional to length of wire.
- If you measure the resistance of two pieces of wire of same length, but of different thickness, you will find that the resistance is inversely proportional to the cross - sectional area. Thus, the larger the diameter, the lower the resistance, and the thinner the wire, the higher the resistance.
Ohm`s law
It gives the relationship between voltage and current. It states that current passing through a wire is proportional to the potential difference across it ends, provided temperature remains constant.
$\frac{\text { potential difference }}{\text { current }}=\mathrm{a}$ constant, the constant is the resistance. Thus, Ohm`s can be summarised as:
$\frac{\mathrm{v}}{\mathrm{I}}=\mathrm{R}$



# Page 81

- Conductors that obey the ohms`s law are called ohmic conductors e.g. metals and certain alloys.
- Semi - conductors such as diodes and conduction through gases do not obey ohm`s law and are called non - ohmic conductors.
Limitations of Ohm`s law
Under the following circumstances, Ohm`s law is not obeyed by ohmic conductors.
- The temperature of the conductor changes (examples are bulbs and heater elements).
- The conductor is coiled e.g. filament of bulb.
- The conductor does not have a uniform cross - sectional area when it is under tension.
- The conductor is placed in a strong magnetic field that alters the internal structure ot the metal so that its conducting capacity changes.
Resistors in Series and Parallel
Resistors are connected in series when they are connected end to end and the same current flow through them. Parallel connection implies that one is placed above one another and their corresponding ends joined together.

Total Resistance
This means combined resistance.
Calculate total resistance of circuits below:
![img-79.jpeg](img-79.jpeg)

Qn. State and explain the factors that affect resistance. [6]

# Power 

It is the rate at which electrical energy is changed to other forms of energy e.g. electrical to light energy. That is the rate of using energy. It is measured in watts or joules / second using the formula:

Power $=$ current x volt OR Watts $=$ Amps x Volts
Electrical energy $=$ Voltage X Current X Time
$\mathrm{E}=\mathrm{VIt}$
[Worked examples: Step A head Combined Science Form 3 page 176]

## OlmOCR Image Descriptions

### Image: img-79.jpeg

![img-79.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-79.jpeg.png)


s": [{"description": "The diagram on the left shows a series circuit with resistors $R_1 = 10\\Omega$, $R_2 = 20\\Omega$, $R_3 = 30\\Omega$, and $R_4 = 40\\Omega$. The total resistance in a series circuit is given by $R = R_1 + R_2 + R_3 + \\ldots$."}, {"description": "The diagram on the right illustrates a parallel circuit with resistors $R_{21} = 2\\Omega$, $R_{22} = 2\\Omega$, and $R_{23} = 2\\Omega$. The reciprocal of the total resistance in a parallel circuit is given by $\\frac{1}{R} = \\frac{1}{R_{21}} + \\frac{1}{R_{22}} + \\frac{1}{R_{23}}$. Therefore, the total resistance $R$ can be calculated as $R = \\frac{1}{\\frac{1}{R_{21}} + \\frac{1}{R_{22}} + \\frac{1}{R_{23}}}$. "}]}





# Page 82

# FORM 3 NOTES <br> CHEMISTRY SECTION 

## SEPARATION

## Simple Distillation

- Simple Distillation - separation of pure liquid from a solution by condensing vaporised liquid.


## Process of Distillation:

- Solution is heated, and steam (pure vapour) is produced.
- The steam is cooled in condenser to form pure liquid.
- Liquid collected in the beaker is called distillate
- Solute remains in the flask.


## Experiment 1

## Aim: To separate salt from salt water

Materials: round-bottomed flasks, a condenser, a thermometer, a beaker, a clamp, rubber tubing, burner, salt solution.

Procedure
3. Set up apparatus as shown.
4. Turn on the water tap to allow steam to be cooled in the condenser.
5. Heat the flask until all liquid evaporates.
6. Record the temperature at which steam is collected.
7. Reduce the heat to allow crystals to be formed in the flask.
![img-80.jpeg](img-80.jpeg)

## OlmOCR Image Descriptions

### Image: img-80.jpeg

![img-80.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-80.jpeg.png)


s": [{"description": "The diagram illustrates the process of distillation for purifying water. A flask containing seawater is heated on a stand with a thermometer inserted to monitor temperature. Anti-bumping granules are added to ensure smooth boiling. The condenser is connected to collect the distilled water, which is then collected in a beaker labeled as 'distillate (pure water).'"}]}





# Page 83

Results

- At sea, steam is collected at 100 degree Celsius, but in Zimbabwe is at 96 degrees Celsius.
- Salt remains at the bottom of the flask.
- In distillation the liquid can be retained and in evaporation is lost.


# Fractional Distillation 

- Fractional Distillation - separates mixture of miscible (soluble) liquids with widely differing boiling points.
- Use of fractionating column separates them.


## Process of Fractional Distillation:

Aim: To Separating a mixture of ethanol and water.

- Mixture of ethanol and water is placed in flask and heated. Ethanol with lower boiling point boils and vaporises first and reach fractionating column then cools and condenses into ethanol as it passes through condenser.
![img-81.jpeg](img-81.jpeg)

Results

## OlmOCR Image Descriptions

### Image: img-81.jpeg

![img-81.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-81.jpeg.png)


s": [{"description": "The diagram illustrates a distillation setup. At the bottom, there is a flask containing a mixture of ethanol and water with anti-bumping granules for smooth boiling. The setup includes a fractionating column connected to a condenser. Cool water enters the condenser from the top right, while the condensed vapor exits at the bottom left as a distillate (ethanol). The thermometer is placed in the fractionating column to monitor the temperature."}]}





# Page 84

1. The boiling point of ethanol is 78,37 degrees Celsius.
2. Ethanol is the first fraction.
3. Water boils at 100 degrees Celsius so it's above that of ethanol.
4. To make the second fraction pure, we should be distilled the same way and collected in the beaker on the other side.

Uses of fractional distillation

- Separates pure oxygen and pure nitrogen from liquefied air.
- Separates substances in petroleum (crude oil) into fractions.
- Separates alcohol to produce alcoholic drinks.



# Page 85

# MATTER 

- Dalton suggested the existence of atoms in all matter, thus mater is made up of atoms.
- An atom is the smallest unit of an element.
- Atoms cannot be divided any further or cannot be created or destroyed.
- Are identical or have same properties if are of the same substance
- Are too small and cannot be seen using the naked eye.
- Atoms consist of sub-atomic particles. These are as follows:
![img-82.jpeg](img-82.jpeg)

Electrons

- Negatively charged particles that revolve around the nucleus. They are found in shells.

Protons
These are positively charged particles found in nucleus.
Proton number for hydrogen atom $=1$
Proton number for helium atom $=2$
Neutrons

- These are neutral (no charge) and found in nucleus.
- The nucleus is composed of protons and neutrons.

## OlmOCR Image Descriptions

### Image: img-82.jpeg

![img-82.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-82.jpeg.png)


s": [{"description": "The diagram on the left illustrates an atom with a central nucleus composed of protons and neutrons. Surrounding the nucleus are orbiting electrons, depicted as negatively charged particles. The overall structure represents the atomic model where electrons move in specific energy levels or shells."}, {"description": "On the right side of the image, there is another diagram that details the electron shell configuration within an atom. This diagram shows multiple concentric circles representing different energy levels (shells) with electrons arranged around the nucleus. The nucleus contains protons and neutrons, which are positively charged and neutral particles, respectively."}]}





# Page 86

Name the sub-atomic particles, their relative charges, masses and position in the atom

| Particle | Position | Charge | Mass | Symbol |
| :--: | :--: | :--: | :--: | :--: |
| Proton | Nucleus | +1 | 1 | p |
| Neutron | Nucleus | 0 | 1 | n |
| Electron | Atomic shells | -1 | $\frac{1}{1840}$ | e |

# Nuclide Notation 

![img-83.jpeg](img-83.jpeg)

- E.g. the element carbon may be represented like this
${ }_{6}^{12} \mathrm{c}$ Meaning carbon has 12 nucleons of which 6 are protons. C is the chemical symbol for the element.


## Define relative mass / mass number

- Is the number of protons and neutrons in a nucleus (nucleons)


## Define the proton number / atomic number

- Is the number of protons in the nucleus of an atom.
- The atom has no charge (electrically neutral) because the number of electrons is equal the number of protons.

Isotopes are atoms of the same element with the same atomic /proton number, but different atomic mass.
E.g. Carbon 12; 13 and Carbon 14.

Isotopes have same proton number, but have different numbers of neutrons hence their masses are different.
The fact that they have different numbers of neutrons does not make a difference in the way they react during chemical reactions. The chemical properties of an atom depends on the number of electrons and their arrangement.

1. Chlorine has two isotopes i.e. ${ }_{17}^{35} \mathrm{Cl}$ and ${ }_{17}^{37} \mathrm{Cl}$
2. Oxygen has two isotopes i.e. ${ }_{8}^{16} \mathrm{O}$ and ${ }_{8}^{18} \mathrm{O}$

## OlmOCR Image Descriptions

### Image: img-83.jpeg

![img-83.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-83.jpeg.png)


s": [{"description": "The diagram illustrates the relationship between nucleon number (A), proton number (Z), and element symbol (X). The nucleon number is represented by 'A', which includes both protons and neutrons. The proton number is denoted by 'Z', representing only the protons within an atom. The element symbol, 'X', is derived from the combination of the nucleon number and proton number."}]}





# Page 87

3. Carbon has two isotopes i.e. ${ }_{6}^{12} \mathrm{C}$ and ${ }_{6}^{16} \mathrm{C}$

# Calculation of number of neutrons 

Number of neutrons $=$ mass number - proton number

Chlorine 35 has $(35-17)=18$ neutrons
Chlorine 37 has $(37-17)=20$ neutrons
Oxygen 16 has $(16-8)=8$ neutrons
Oxygen 18 has $(18-8)=10$ neutrons
Carbon 12 has $(12-6)=6$ neutrons
Carbon 16 has $(16-6)=10$ neutrons

## THE PERIODIC TABLE

- Scientists have developed a modern way of arranging elements by their proton numbers.
- Elements are arranged in order of increasing proton number.
- Elements with similar properties are in the same column or group.

GROUP 1: The alkali metals
Group 2: The alkaline earth metals
GROUP 17: The halogens.
GROUP 18: The noble gases

- The horizontal rows are called periods, which are numbered from 1 to 7 . Between group 2 and 13, there is a group of elements called transition metals such as copper, iron, nickel, zinc and chromium.

This shows that metals are mostly found on the left and in the middle of the periodic table and most nonmetals are on the far right side. There are more metals than non-metals on the table.



# Page 88

![img-84.jpeg](img-84.jpeg)

## OlmOCR Image Descriptions

### Image: img-84.jpeg

![img-84.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-84.jpeg.png)


s": [{"description": "The image contains a detailed periodic table of elements. The table is organized in rows and columns, with each element represented by its atomic number, symbol, and name. The elements are arranged based on their atomic numbers, with groups and periods clearly marked. The table includes a variety of colors to differentiate between different categories of elements, such as metals, non-metals, and metalloids. There is also a small inset diagram showing the electron configuration for some elements."}]}





# Page 89

Name the first 20 elements in the periodic table stating their symbols

| 1. | Hydrogen | H | 11. Sodium | Na |
| :-- | :-- | :-- | :-- | :-- |
| 2. | Helium | He | 12. Magnesium | Mg |
| 3. | Lithium | Li | 13. Aluminium | Al |
| 4. | Beryllium | Be | 14. Silicon | Si |
| 5. | Boron | B | 15. Phosphorus | P |
| 6. | Carbon | C | 16. Sulphur | S |
| 7. | Nitrogen | N | 17. Chlorine | Cl |
| 8. | Oxygen | O | 18. Argon | Ar |
| 9. | Fluorine | F | 19. Potassium | K |
| 10. | Neon | Ne | 20. Calcium | Ca |

Write the electronic configuration of the first 20 elements

- Is the arrangement of electrons in an atom

| Hydrogen | 1 | Sodium | 2.8 .1 |
| :-- | :-- | :-- | :-- |
| Helium | 2 | Magnesium | 2.8 .2 |
| Lithium | 2.1 | Aluminium | 2.8 .3 |
| Beryllium | 2.2 | Silicon | 2.8 .4 |
| Boron | 2.3 | Phosphorus | 2.8 .5 |
| Carbon | 2.4 | Sulphur | 2.8 .6 |
| Nitrogen | 2.5 | Chlorine | 2.8 .7 |
| Oxygen | 2.6 | Argon | 2.8 .8 |
| Fluorine | 2.7 | Potassium | 2.8 .8 .1 |
| Neon | 2.8 | Calcium | 2.8 .8 |

# Electronic Configuration 

- Atoms are electrically neutral. Thus, the number of protons is equal to the number of electrons.
- Electrons are placed in orbits / series of energy shells around the nucleus. This nature of arrangement is called electronic configuration.
- Energy shells can hold a certain number of electrons. The shells become larger as they are further from the nucleus hence a larger shell can hold more electrons.
- First energy shell contains maximum 2 electrons. Second shell and so on has maximum of 8 electrons. The fourth shell can hold a maximum of 18 .



# Page 90

![img-85.jpeg](img-85.jpeg)

# To write electronic configuration: Sodium example 

* Look up the atomic number in the periodic table. The number is 11 .
* The number of electrons and protons are equal in neutral sodium atom.
* Arrange the electrons in shells. Fill up the lower energy shell before going to the outer one.
* In sodium, the electrons are arranged as two (2) in the first shell, eight in the second shell and one in the third. This is written as: $(\mathrm{n}, \mathrm{n}, \mathrm{n})$ i.e. $2,8,1$.


## Other Configuration diagrams

![img-86.jpeg](img-86.jpeg)

## Significance of the electronic configuration

* The number of electrons 9 n the outmost shell of an atom determines the chemical properties of an element including how it forms bonds with other elements.
* There are a group of element called noble gases eg. Helium, neon, argon, krypton, xenon and radon. All have 8 electrons in the outmost shell except helium which has only 2 .
* The gases are completely inert or nonreactive.

## OlmOCR Image Descriptions

### Image: img-85.jpeg

![img-85.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-85.jpeg.png)


s": [{"description": "The diagram illustrates the structure of an atom. At the center is the nucleus, which contains protons and neutrons. Surrounding the nucleus are concentric circles representing energy levels. The first level has 2 electrons, the second level has 8 electrons, and the third level also has 8 electrons. The arrows indicate that as you move away from the nucleus, the energy of the electron increases."}]}


### Image: img-86.jpeg

![img-86.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-86.jpeg.png)


s": [{"description": "The electronic configuration of hydrogen is very simple. There is only one electron to place in the first energy shell closest to the nucleus."}, {"description": "Carbon's six electrons are arranged in the first two energy shells."}, {"description": "Argon has 18 electrons to be placed. They use up all the space in the first three shells."}]}





# Page 91

# Chemical Bonding 

- Is the combination of elements to form compounds. A compound is a chemical composition of two or more elements.
- E.g. salt is composed of one atom of sodium and one of chlorine. Hydrogen is made up of two hydrogen atoms and on oxygen atom.
- To bond is to join and this makes a compound. When reacting, atoms will denote and receive electrons so as to form ionic compounds or will share electrons to form molecular compounds.


## Ionic bonding / electrovalent bonding

An ion is a charged atom. It is an atoms which has too many or too few electrons to be neutral. Ions of opposite charges attract one another to form ionic bonds as shown:
![img-87.jpeg](img-87.jpeg)

- When atoms gain electrons and others loose electrons, there is attraction between two ions to form a compound. This is called ionic bonding.
- Metals form positive ions (cations) because they lose electrons while non-metals form negative ions (anions) because they gain electrons and become negative. The electrons that form are called valence electrons.
- Valency of an atom is the number of electrons which an atom should gain or lose to attain a nobble gas configuration.
- Metals in group 1 have a valency of 1 because they lose 1 electron to became a cation. Group 2 have a valency of 2 and group 13 and 14 elements have a valency of 3 and 4 respectively.
- For example: ${ }_{11}^{22} \mathrm{Na}$ and ${ }_{17}^{35} \mathrm{Cl}$

Charge atom is $\mathrm{Na}^{+}$and is $\mathrm{Cl}^{-}$
Sodium + Chlorine $\rightarrow$ Sodium chloride.

## OlmOCR Image Descriptions

### Image: img-87.jpeg

![img-87.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-87.jpeg.png)


s": [{"description": "The diagram illustrates the formation of an ionic compound. It shows two ions, A+ and B-, with arrows pointing to their respective charges. The text explains that A has lost one of its electrons, becoming positively charged, while B has gained an extra electron, becoming negatively charged. The two oppositely charged ions attract each other to form an ionic compound."}]}





# Page 92

![img-88.jpeg](img-88.jpeg)

Bonding in Magnesium oxide
Magnesium has two electrons in its outer shell so it can become stable by losing these two valence electrons. It therefore becomes a magnesium ion with a charge of $2+$.

An oxygen atom has 16 electrons it needs two valence electrons in order for it to attain a stable outer shell hence the combination will give MgO as shown below:
![img-89.jpeg](img-89.jpeg)

# Covalent Bonding

## OlmOCR Image Descriptions

### Image: img-88.jpeg

![img-88.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-88.jpeg.png)


s": [{"description": "The diagram illustrates the formation of sodium chloride (NaCl) through a chemical reaction. At the top, two atomic structures are shown: one for sodium (Na) and one for chlorine (Cl). Sodium has 1 electron in its outer shell, while chlorine has 7 electrons in its outer shell. An arrow indicates that an electron is transferred from sodium to chlorine. This results in sodium losing its single electron to become a positive ion [Na⁺], and chlorine gaining this electron to become a negative ion [Cl⁻]. The combination of these ions forms the compound NaCl, which represents sodium chloride."}]}


### Image: img-89.jpeg

![img-89.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-89.jpeg.png)


s": [{"description": "The diagram illustrates the formation of an ionic bond between magnesium (Mg) and oxygen (O). The outer electron configurations of Mg and O are shown with crosses representing valence electrons. Mg loses two electrons to achieve a stable configuration, becoming Mg²⁺, while O gains two electrons to become O²⁻. These charged ions attract each other due to their opposite charges, forming an ionic bond."}]}





# Page 93

- Involves sharing of electrons.
- When atoms combine by sharing electrons to attain a nobble gas configuration.
- Example 1: $\mathrm{H}_{2}+\mathrm{O}_{2}=\mathrm{H}_{2} \mathrm{O}$.
- Oxygen has six electrons in its outermost shell. It therefore needs to gain or share another two to achieve stability.
- Hydrogen atoms each have one electron in their outermost shell(s) therefore, two hydrogens have to bond covalently with one oxygen atom to form water molecule.
![img-90.jpeg](img-90.jpeg)
- Example 2: carbon + oxygen $\rightarrow$ carbon dioxide.

Example 3
![img-91.jpeg](img-91.jpeg)

Example 4
![img-92.jpeg](img-92.jpeg)

Properties of Covalent \& Ionic Compounds

## OlmOCR Image Descriptions

### Image: img-90.jpeg

![img-90.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-90.jpeg.png)


s": [{"description": "The diagram illustrates the molecular structure of water (H₂O). It shows three hydrogen atoms (H) and one oxygen atom (O). The hydrogen atoms are located at opposite ends of a line that passes through the center of the oxygen atom. The oxygen atom is surrounded by six electrons, which represent the bonding pairs and lone pairs of electrons in the molecule. The diagram uses circles to represent the atomic spheres, with the size indicating the relative atomic radius."}]}


### Image: img-91.jpeg

![img-91.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-91.jpeg.png)


s": [{"description": "The diagram illustrates the formation of an oxygen molecule, $O_2$, from two oxygen atoms, O. Each oxygen atom consists of a single red sphere representing the nucleus and eight blue spheres representing electrons. The process begins with two separate oxygen atoms, each depicted as a red sphere with eight blue electrons surrounding it. An arrow indicates the movement or interaction between these two atoms, leading to the formation of an oxygen molecule, $O_2$. This molecule is shown as two red spheres connected by a bond, with the same number of blue electrons surrounding them."}]}


### Image: img-92.jpeg

![img-92.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-92.jpeg.png)


s": [{"description": "The diagram illustrates the formation of a hydrogen molecule, $H_2$. It shows two hydrogen atoms, each represented by an orange circle with the symbol 'H'. The process begins with two separate hydrogen atoms. As they come together, they form a bond pair indicated by blue lines connecting their nuclei. This bond results in the creation of a hydrogen molecule, $H_2$, which is depicted as a single red circle with the symbol 'H' and an arrow pointing to it."}]}





# Page 94

# Covalent Compound 

- Are usually gases and liquids.
- Does not conduct electricity in any state (because does not contain ions)
- Low melting point "less than $200^{\circ} \mathrm{C}$ " (because weak forces of attraction between molecules).
- Insoluble in water, Soluble in organic solvents.


## Ionic Compound

- Conduct electricity when molten, Aqueous state - because it contains moving ions - does not conduct on solid as ions cannot move.
- High Melting point "More than $1000{ }^{\circ} \mathrm{C}$ " hence ionic compounds are generally solids at room temp because of strong forces of attraction between ions.
- Soluble in water


## Stoichiometry and the Mole Concept

## Avogadro number ( $\mathbf{L}$ )

- Is the number of particles in one mole of an element or compound.

$$
\mathrm{L}=6.02 \times 10^{23}
$$

- A mole is atomic or molecular mass expressed in grams.
- A mole is the amount of substance which contains the same number of molecules or atoms as there are atoms in 12 g of ${ }_{6}^{12} \mathrm{C}$
1 mol of $\mathrm{MgO}=24+16=40 \mathrm{~g}$
2 mol of $\mathrm{HCl}=2[1+35.5]=73 \mathrm{~g}$
1 mol of $\mathrm{O}_{2}=2[16]=32 \mathrm{~g}$

Number of moles $=\frac{\text { mass }}{\text { molecular mass }}$ or $\quad \mathbf{n} \stackrel{\mathbf{m}}{\stackrel{\mathbf{M r}}{=}}$
Examples

1. Express the following in moles
(a) $10 \mathrm{~g} \mathrm{NH}_{3}$

$$
\begin{aligned}
& 1 \mathrm{mole}\left(\mathrm{NH}_{3}\right)=14+(1) 3=17 \mathrm{~g} \\
& 10 \mathrm{~g} \mathrm{NH}_{3}=\frac{10}{17}=0.59 \text { moles }
\end{aligned}
$$

(b) 5 g Na
(c)



# Page 95

2. Calculate the mass
(a) 0.2 moles $\mathrm{C}_{2} \mathrm{H}_{4}$

$$
\begin{aligned}
& 1 \mathrm{mole}\left(\mathrm{C}_{2} \mathrm{H}_{4}\right)=2(12)+4(1)=28 \mathrm{~g} \\
& 0.2 \text { moles }=28 \times 0.2=5.6 \mathrm{~g}
\end{aligned}
$$

(b) 0.25 moles of carbon monoxide

# Molecular Mass (Mr) 

- Is given by the sum of atomic masses of the elements.

$$
\begin{aligned}
& \mathrm{Mr}(\mathrm{NaCl})=23+35.5=58.5 \mathrm{~g} \\
& \mathrm{Mr}\left(\mathrm{Na}_{2} \mathrm{O}\right)=2(23)+16=62 \mathrm{~g}
\end{aligned}
$$

$\mathrm{Mr}\left(\mathrm{Na}_{2} \mathrm{CO}_{3}\right)$
$\mathrm{Mr}(\mathrm{HCl})$
$\mathrm{Mr}\left(\mathrm{CO}_{2}\right)$
$\mathrm{Mr}\left(\mathrm{NH}_{3}\right)$

## Empirical formula

- Is a formula that shows the simplest ratio combination of atoms that form up a given substance,


## Example

1. 6 g of Magnesium is heated in oxygen, after cooling and reweighing it is found that there is 10 g of Magnesium Oxide. Find the empirical formula for Magnesium Oxide

$$
\begin{aligned}
& \text { Ratio: } \mathrm{Mg} \quad: \quad \mathrm{O} \\
& \frac{6}{24} \quad: \quad \frac{4}{16} \\
& =0.25 \quad: \quad 0.25 \\
& \text { (divide by the smallest) } \\
& 1 \quad: \quad 1
\end{aligned}
$$

## $\therefore$ empirical formula $=\mathbf{M g O}$

2. Calculate the empirical formulae of substances which have the following compositions by mass; $43.4 \%$ Sodium, $11.3 \%$ Carbon, $45.3 \%$ Oxygen

$$
\begin{aligned}
& \text { Ratio: Na : C : O } \\
& \frac{43.4}{23} \quad: \quad \frac{11.3}{12} \quad: \quad \frac{45.3}{16} \\
& =1.89 \quad: \quad 0.942 \quad: \quad 2.83 \\
& \text { (Divide by the smallest) }
\end{aligned}
$$



# Page 96

$$
\begin{array}{lll}
\frac{1.89}{0.942} & : & \frac{0.942}{0.942} \quad: \quad \frac{2.83}{0.942} \\
=2.01 & : & 1 \quad: \quad 3
\end{array}
$$

$\therefore$ empirical formula $=\mathrm{Na}_{2} \mathrm{CO}_{3}$

# Concentration 

- It is the ratio of number of moles of a solute to the volume of a solution.

$$
\text { Concentration }=\frac{\text { number of moles }}{\text { volume }}
$$

- Units are $\mathrm{mol} / \mathrm{dm}^{3}$ or $\mathrm{g} / \mathrm{dm}^{3}$


## Examples

1. Find the number of moles of Sodium hydroxide in $25 \mathrm{~cm}^{3}$ of solution of concentration $0.1 \mathrm{~mol} / \mathrm{dm}^{3}$

Number of moles $=$ concentration x volume

$$
\begin{aligned}
& =0.1 \times 25 \\
& =0.0025
\end{aligned}
$$

2. Find volume of solution of concentration $2 \mathrm{~mol} / \mathrm{dm}^{3}$ that contain 0.005 moles of hydrochloric acid.

Volume $\quad=\frac{\text { number of moles }}{\text { concentration }}$

$$
\begin{aligned}
& =\frac{1000 \times 0.005}{2} \\
& =25 \mathrm{~cm}^{3}
\end{aligned}
$$



# Page 97

# Acid, Bases and Salts 

- All substances are divided into acids, basis and salts or neutral.
- When one puts these compounds in water, they break down or dissociate and either release hydrogen ions $(\mathrm{H}+$ ) or hydroxides ion $(\mathrm{OH}-$ )
- Acids or bases can be strong or weak and all are dangerous as they are corrosive.
- In the laboratory acids and alkali used are always diluted with water.
pH is a measure of acidity or alkaline.
The p.H Scale
![img-93.jpeg](img-93.jpeg)

4 It ranges from zero to fourteen $(0-14)$
4 It shows how acidic or alkaline a solution is. Acids have pH values less than 7 while alkaline have pH values greater than 7
4 If a substance has a pH of 7 , it is neutral e.g. pure water

## Indicators

Litmus paper is an example of an indicator and the universal indicator being most important - it is a mixture of dyes that change colour gradually over a range of pH .

| Indicator | Colour in acid | Colour in alkali |
| :-- | :-- | :-- |
| litmus | red | blue |
| methyl orange | red | yellow |
| phenolphthalein | colourless | red |
| universal | red | purple |

Strong and weak acids

## OlmOCR Image Descriptions

### Image: img-93.jpeg

![img-93.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-93.jpeg.png)


s": [{"description": "The diagram illustrates the pH scale and its corresponding colors. The pH scale ranges from 0 to 14, with 7 being neutral. Values below 7 indicate acidity (acids), while values above 7 indicate alkalinity (alkalis). The colors range from red for strong acids at pH 1 to purple for strong bases at pH 14. Intermediate colors include orange (weak acids), yellow (neutral), and blue (weak bases)."}]}





# Page 98

- When acids dissolve in water, they give away their hydrogen ions. Adding water dilutes an acid but does not make it weaker as only few hydrogen ions given away.

Strong and weak alkali

- Some alkali dissolve in water to give away their hydroxyl ions. Alkali that completely dissociate in water are strong alkali. E.g. sodium hydroxide and potassium hydroxide.
- Weak alkali such as ammonia can partially dissociate in water and does not give away their hydroxyl ions.


# Experiment 1 

Testing the pH of common substances

- In this activity a range of household and everyday products are tested for their pH .
- Using universal indicator paper or red and blue litmus.


## Materials

White tiles, Dropping pipettes, Universal indicator paper and a colour chart, Red and blue litmus paper, a range of household substances (include fruit juices, soft drinks, vinegar, different soap solutions, floor cleaner containing ammonia and toothpaste.)
You could also include some of the dilute acids and alkalis in the kit (e.g. HCl , Ammonia solution)

NB: Acids and alkalis are corrosive, extreme care must be taken' wash with large ' amounts of water if they come in contact in eyes. Splashes on the skin, should be washed off as soon as possible. Always wipe up any small spills.

## Method

1. Put a small drop of one of the substances you wish to test on a white tile.
2. Tear off small pieces of blue and red litmus paper and universal indicator.
3. Drop the three pieces of paper in the substances. Record your results in a table like the one below:
N.B. You can also carryout this experiment in test tubes, but this involves lots more washing up!

| Substance | Colour of red <br> litmus paper | Colour of blue <br> litmus paper | Colour of Universal <br> Indicator | Acid, alkali, or <br> neutral | pH <br> value |
| :-- | :-- | :-- | :-- | :-- | :-- |
| Hydrochloric <br> acid |  |  |  | Strong acid | $1-2$ |
| Sodium <br> hydroxide |  |  |  | Strong base | $12-14$ |
| Distilled <br> water |  |  |  | neutral | 7 |
| Tooth paste |  |  |  | Weak alkali | 9 |
| Lemon juice |  |  |  | Acid | 2.5 |
| coffee |  |  |  | Weak acid | 5 |



# Page 99

QN: How many acids are there?
Complete the table above.

Preparation of Acids
Non - metallic oxide + water $\rightarrow$ acid.
E.g. carbon dioxide + water $\rightarrow$ carbonic acid.

Sulphur dioxide + water $\rightarrow$ sulphuric acid.

# Reactions of acids with metal 

- Some metals react with acids while some do not react for example gold and silver do not react with acids.
- Metal react with acids to form a salt and hydrogen gas.
- metal + acid $\rightarrow$ salt + hydrogen gas.

Magnesium + sulphuric acid $\longrightarrow$ magnesium sulphate + hydrogen
$\mathrm{Mg}(\mathrm{s})+\mathrm{H}_{2} \mathrm{SO}_{4}(\mathrm{aq}) \longrightarrow \mathrm{MgSO}_{4}(\mathrm{aq})+\mathrm{H}_{2}(\mathrm{~g})$

## Experiment

Aim: To investigate the reactions of acids with metals
Materials: test tubes, dilute hydrochloric acid, sulphuric acid, nitric acid, ethanoic acid, magnesium ribbon, metal turnings of zinc, iron and copper.

Procedure
i. Fill 5 test tubes - one quarter full with one of the acids.
ii. Drop a piece of magnesium ribbon into each test tube. Observe what happens.
iii. Repeat the experiment using different acids and a set of all metals.
iv. Record the results in a table as shown:

Results

- Not all metals react with acids to form hydrogen.
- Copper only reacted with nitric acid and a brown gas evolved.

Example: Magnesium + hydrochloric acid $\rightarrow$ magnesium chloride + hydrogen gas.
QN : write down the chemical equation for the above reaction. (2)
Zinc + hydrochloric acid $\rightarrow$ zinc chloride + hydrogen gas.
$\mathrm{Zn}(\mathrm{s})+2 \mathrm{HCl}(\mathrm{aq}) \longrightarrow \mathrm{ZnCl}_{2}(\mathrm{aq})+\mathrm{H}_{2}(\mathrm{~g})$
*Use other metals to come up with the above equation. (8)



# Page 100

BASES - are substances with pH above 7.
Preparation of basis
Metal oxide + water $\rightarrow$ base.
Calcium oxide + water $\rightarrow$ calcium hydroxide.
Magnesium oxide + water $\rightarrow$ magnesium hydroxide.
Some materials used in everyday are acidic and acids are identified by considering their properties as summed below:

Comparison of acids and base

| Acid | Bases |
| :-- | :-- |
| Has a sour taste (never taste it). | Has a slippery feel and tastes bitter <br> (never taste it). |
| Turns blue litmus paper to red. | Turns red litmus paper to blue. |
| Acids are corrosive | Some bases are caustic e.g. potassium <br> hydroxide. |
| Reacts with a base to form salt and water. | Reacts with bases to form salt and <br> water. |
| Universal indicator paper changes to a <br> series of various colours as acidity and <br> alkalinity of the solution changes. |  |

# Bases 

Bases can be made by dissolving metal oxides or adding water to reactive metals. Bases are chemicals that contain hydroxyl ions $\left(\mathrm{OH}^{-}\right)$and metal or metal like ions.

## Salts

The salt we eat is sodium chloride or common salt. The term salt can mean other combination of elements too, some of which are poisonous.

The reaction between an acid and base to form salt and water is called neutralization. Acid + base $\rightarrow$ salt + water e.g. hydrochloric acid + sodium oxide $\rightarrow$ sodium chloride + water.

Qn: Write down the chemical equation for the above reaction. (2)
$\mathrm{H}_{2} \mathrm{SO}_{4}$ (aq) +2 NaOH (aq) $\longleftrightarrow 2 \mathrm{NaSO}_{4}$ (aq) + $\mathrm{H}_{2} \mathrm{O}$ (1)
Qn: Write down the word equation for the above reaction. (2)



# Page 101

# Experiment 2 

Making salt, copper sulphate.
Materials: a beaker, stirrer, filter paper, filter funnel, evaporating dish, burner, and stand, dilute sulphuric acid, copper oxide

Method
![img-94.jpeg](img-94.jpeg)
$\checkmark$ Warm a mixture of a small spatula load of copper oxide and 15 ml of sulphuric acid in a beaker.
$\checkmark$ Continue adding copper oxide until no more will dissolve.
$\checkmark$ Filter the solution to remove the undissolved copper oxide.
$\checkmark$ Heat the filtrate over a burner to remove excess water, a saturated solution will be formed.
$\checkmark$ Leave the evaporating dish over a window sill for few days.
$\checkmark$ Observe the results.
Results
When copper oxide is added to dilute sulphuric acid, it starts to dissolve and a blue filtrate is collected in the evaporating dish.

When the filtrate allowed to cool for some days, forms crystals of copper sulphate.

## Conclusion

Copper oxide reacts with dilute sulphuric acid to form copper sulphate and water.
Copper oxide + dilute sulphuric acid $\rightarrow$ copper sulphate + water.
Qn: Write down the chemical equation for this reaction. (2)

## OlmOCR Image Descriptions

### Image: img-94.jpeg

![img-94.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-94.jpeg.png)


s": [{"image": "A", "description": "Diagram A shows a beaker containing dilute sulphuric acid with a spatula and stirring rod. Copper oxide is also present in the beaker."}, {"image": "B", "description": "Diagram B illustrates the process of filtration, showing a filter paper placed on top of a funnel, which is then used to filter a solution into an evaporating dish."}, {"image": "C", "description": "Diagram C depicts the setup for evaporation. An evaporating dish is heated over a source of heat, with the filtrate being concentrated and eventually dried."}]}





# Page 102

# Reaction of acids with carbonates 

- Carbonates react with acids to give salt, water and carbon dioxide. There is fizzing or effervescence.

| $\mathrm{CaCO}_{3}(\mathrm{~s})$ | $+$ | $2 \mathrm{HCl}(\mathrm{aq}) \longrightarrow \mathrm{CaCl}_{2}(\mathrm{aq})$ | $+$ | $\mathrm{H}_{2} \mathrm{O}(\mathrm{l})+$ | $\mathrm{CO}_{2}(\mathrm{~g})$ |
| :--: | :--: | :--: | :--: | :--: | :--: |
| $\mathrm{MgCO}_{3}$ (s) | $+$ | $\mathrm{H}_{2} \mathrm{SO}_{4}(\mathrm{aq}) \longrightarrow \mathrm{MgSO}_{4}(\mathrm{aq})$ | $+$ | $\mathrm{H}_{2} \mathrm{O}(\mathrm{l})+$ | $\mathrm{CO}_{2}(\mathrm{~g})$ |
| $\mathrm{CaCO}_{3}$ (s) | $+$ | $2 \mathrm{HNO}_{3}(\mathrm{aq}) \longrightarrow \mathrm{Ca}\left(\mathrm{NO}_{3}\right)_{2}$ | $+$ | $\mathrm{H}_{2} \mathrm{O}(\mathrm{l})+$ | $\mathrm{CO}_{2}(\mathrm{~g})$ |



# Page 103

# INDUSTRIAL PROCESSES 

## Production of Nitrogen and oxygen

## Liquefaction of air

![img-95.jpeg](img-95.jpeg)

Air is cooled to -78 degrees Celsius. Water and carbon dioxide are removed at this point since they freeze below this. The remaining air is compressed to about 150 atm . The gas becomes hot. The compressed gases are allowed to expand, thus cooling them. The compression is repeated several times so temperature drops to -200 degrees Celsius hence gases turn into liquids except helium and neon. The liquid air is reheated to -196 degrees Celsius and nitrogen evaporates and is collected at the top of the distillation. Oxygen which boils at -183 degrees Celsius remains a liquid and is collected at the bottom of the tower.

Electrolysis - is the decomposition of a compound molten or in solution, by electricity.
Components of an electrolytic cell
![img-96.jpeg](img-96.jpeg)

## OlmOCR Image Descriptions

### Image: img-95.jpeg

![img-95.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-95.jpeg.png)


s": [{"description": "The diagram illustrates the process of separating nitrogen and oxygen from air. Air is fed into a system where CO₂ and water vapor are removed to prevent solids from blocking the pipes. The remaining gases are cooled until they reach a temperature of -200°C, at which point the air liquefies. This results in a mixture of N₂ + O₂ + noble gases. These gases are then compressed to 200 atm and further cooled. The cooled gases are allowed to expand through a fine jet, which cools them even more. The final product is very cold N₂ + O₂ + noble gases."}]}


### Image: img-96.jpeg

![img-96.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-96.jpeg.png)


s": [{"description": "The diagram illustrates a basic electrochemical cell. It consists of two electrodes: the cathode (negative electrode) and the anode (positive electrode). The cathode is connected to the negative terminal of the d.c. power source, while the anode is connected to the positive terminal. The direction of electron flow is indicated by arrows from the anode to the cathode. The electrolyte, which can be molten or dissolved, contains ions that move in response to the electric field created by the applied voltage. Cations (positive ions) migrate towards the cathode, and anions (negative ions) migrate towards the anode."}]}





# Page 104

- Electrode is a rod or plate where electricity enters or leaves electrolyte during electrolysis. Reactions occur at electrodes.
- Electrolyte is an ionic compound which conducts electric current in molten or aqueous solution, being decomposed in the process.
- Cathode is negative electrode connected to negative terminal of d.c. source. Reduction occurs here. Cathode gains negative charge as electrons flow from the battery towards the cathode, making cathode negatively charged. This causes cation to be attracted and gains electrons to be an atom.
- Anode is positive electrode connected to positive terminal of d.c. source. Oxidation occurs here. Anode loses negative charge as electrons flow towards the battery, leaving anode positively charged. This causes anion to discharge its electrons here to replace lost electrons and also, negative charge are attracted to positive charge.
- Discharge is the removal of electrons from negative ions to form atoms or the gain of electrons of positive ions to become atoms.
- Cation is positive ion. It's attracted to cathode.
- Anion is negative ion. It's attracted to anode.

Electrolysis of Molten Compounds

- Molten/aqueous ionic compounds conduct electricity because ions free to move.
- In solid state, these ions are held in fixed position within the crystal lattice.
- Hence solid ionic compounds do not conduct electricity.


# Electrolysis Of Molten Lead Bromide 

Describe anode and cathode reactions for electrolysis of molten lead bromide
State observations for the electrolysis of molten lead bromide
![img-97.jpeg](img-97.jpeg)

## OlmOCR Image Descriptions

### Image: img-97.jpeg

![img-97.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-97.jpeg.png)


s": [{"description": "The diagram illustrates a voltaic cell for the electrolysis of molten lead(II) bromide. The cell consists of two electrodes: a graphite anode and a graphite cathode. The anode is labeled as 'graphite anode' and contains molten lead(II) bromide, while the cathode is labeled as 'graphite cathode'. A flow of electrons is indicated by arrows from the anode to the cathode. An ammeter (A) is connected in series with the cell to measure the current. The cell is heated, as indicated by the arrow labeled 'heat', which suggests that external heat is applied to maintain the molten state of the electrolyte."}]}





# Page 105

- To make molten lead (II) bromide, $\mathrm{PbBr}_{2}$, we strongly heat the solid until it melts. To electrolyse it, pass current through the molten $\mathrm{PbBr}_{2}$.
- Ions Present are $\mathrm{Pb}^{2+}$ and $\mathrm{Br}^{-}$
- At the cathode lead ions gains electrons to form lead atoms. The lead will form a liquid at the bottom of the reaction vessel.
$\mathrm{Pb}^{2+}+\quad 2 \mathrm{e}^{-} \longrightarrow \mathrm{Pb}$ (lead metal)
- At the anode bromide ions loses electrons to form bromine atoms which combine to form molecules of bromine gas/vapour. Bromine appears as a brown gas at the anode.
$2 \mathrm{Br}^{-}(\mathrm{aq}) \longrightarrow \mathrm{Br}_{2}(\mathrm{~g})+\quad 2 \mathrm{e}^{-}$

Overall Equation
$\mathrm{PbBr}_{2}(I) \longrightarrow \mathrm{Pb}(I)+\quad \mathrm{Br}_{2}(\mathrm{~g})$

# Electrolysis of Water 

Describe the electrolysis of water

- Inert platinum/carbon electrodes are used as electrodes.
- Water is acidified
- Water is broken into hydrogen and oxygen in the ratios $2: 1$ respectively
- While current is flowing positive $\mathrm{H}^{+}$ions migrate to the cathode, accept electrons to form hydrogen atoms, which then combine to form molecules of hydrogen gas.
![img-98.jpeg](img-98.jpeg)
- Negative hydroxide ions migrate to the anode and give up electrons forming water and oxygen molecules.

## OlmOCR Image Descriptions

### Image: img-98.jpeg

![img-98.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-98.jpeg.png)


s": [{"description": "The diagram illustrates a simple electrochemical cell. On the left side, labeled as test tube A, is the anode where oxygen gas is produced and connected to the battery. The anode produces OH⁻ ions which are shown moving towards the cathode. On the right side, labeled as test tube B, is the cathode where hydrogen gas is produced and also connected to the battery. Hydrogen ions (H⁺) move from the cathode to the anode. The overall reaction represented by the diagram is 2H⁺(aq) + 2e⁻ → H₂(g)."}]}





# Page 106

# State products formed during electrolysis of water 

- The gas at the cathode is twice the gas at the anode.
- Hydrogen is produced at the cathode. It burns with a pop sound when a burning wooden splint was brought near the mouth of the test tube.
- Oxygen is produced at the anode. It relights a glowing wooden splint.


## State uses of oxygen and hydrogen

## Uses of oxygen

1. Manufacture of steel
2. Cutting and welding metals
3. Medical purposes

Uses of hydrogen.

1. Manufacture of ammonia at Sable Chemicals
2. Manufacture of margarine
3. Welding

Experiment 1

## Chrome Plating

Aim: To chrome plate a nickel cathode
Materials: nickel-plated electrode, lead electrode, beaker, chromic acid
Method

1. Set up an electrolytic cell using a nickel plated cathode from this experiment.
2. Place 200 cm 3 of chromic acid solution in a beaker.
3. Warm it up to $40^{\circ} \mathrm{C}$.
4. Pass a current through the solution for about 20 minutes.
5. Switch off the current and disconnect the cathode

Observations and results
$>$ The nickel plated cathode is covered by chrome and achieves a glossy finish.
$>$ It does adhere well even during polishing
$>$ Chrome shines more than nickel.

## Experiment 2

Nickel plating a piece of copper sheet.
Aim: To nickel plate a piece of copper
Materials: beaker, nickel sulphate, boric acid, burner, nickel electrode, 1.5 v cell, copper electrode/copper plated item, universal indicator



# Page 107

![img-99.jpeg](img-99.jpeg)

1. In a beaker make 20 cm 3 a solution using 54 g nickel sulphate and 6 g boric acid.
2. Warm the solution to about $70^{\circ} \mathrm{C}$.
3. Test the pH and add more boric acid if it is too high (i.e. if is greater than 4).
4. Immerse a copper cathode and a nickel anode into the solution.
5. Allow a current to flow for about 20 minutes.
6. Switch off the current and disconnect the cathode.

Results and Observation
$>$ The copper sheet is covered (plated) with nickel.
$>$ The nickel is shiny i.e. it has a bright sheen.
$>$ It does adhere well to the copper even during polishing.

# Experiment 3 

Copper plating an iron nail.
Aim: Copper plating an iron nail
Materials: beaker, copper sulphate, dilute sulphuric acid, iron nail, copper electrode, amateur, 1.5 V torch cells, sandpaper

Method

## OlmOCR Image Descriptions

### Image: img-99.jpeg

![img-99.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-99.jpeg.png)


s": [{"description": "The diagram illustrates a setup for an electroplating process. It includes a beaker containing nickel sulphate and boric acid solution with a copper plated nail immersed in it. A switch is connected to the circuit, which also includes a nickel anode and an ammeter. The flow of electricity is indicated by arrows, showing the direction of current through the solution."}]}





# Page 108

![img-100.jpeg](img-100.jpeg)

1. In a beaker, make up 100 cm 3 of solution containing 40 g of copper sulphate.
2. Carefully add 100 cm 3 copper sulphuric acid.
3. Clean the iron nail using sandpaper.
4. Immerse a copper electrode and the iron nail into the solution.
5. Allow a current to flow for about 20 minutes.
6. Switch off the current and disconnect the cathode.

Results and observations
$>$ The iron nail is coated with a thin layer of copper after the process.
$>$ The copper coat is shiny.
$>$ It does not adhere very well and comes off if cleaned using sandpaper.
$>$ The copper electrode will be thinner after the process.
State reasons for electroplating materials

1. Prevent corrosion or rusting
2. Decoration

Painting- ensures that metals are not in contact with water and oxygen (rusting).
Galvanizing-is coating material (iron and steel) with zinc. What are the advantages of using zinc when galvanizing.

Assignment 1
b. Descried chrome plating. (6)
c. What are the reasons for plating metals? [4]

## OlmOCR Image Descriptions

### Image: img-100.jpeg

![img-100.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-100.jpeg.png)


s": [{"description": "The diagram illustrates a simple electrochemical cell setup. It consists of a beaker containing copper sulphate solution and sulphuric acid. A steel/iron nail is used as the cathode, while a copper anode is placed in the solution. The circuit includes a switch, an ammeter labeled 'A', and a copper anode connected to the switch. The diagram also shows the flow of ions within the beaker."}]}





# Page 109

# OXIDATION AND REDUCTION 

Oxidation - is a chemical reaction in which a substance gains oxygen or loses hydrogen. For example, oxidation occurs during combustion/burning of elements e.g. carbon + oxygen $\longrightarrow$ carbon dioxide Magnesium + Oxygen $\longrightarrow$ magnesium oxide

| $\mathrm{S}(\mathrm{s})+\mathrm{O}_{2}(\mathrm{~g}) \rightarrow \mathrm{SO}_{2}(\mathrm{~g})$ | Sulphur is oxidised to sulphur dioxide by gaining oxygen. |
| :-- | :-- |
| $\mathrm{H}_{2} \mathrm{~S}(\mathrm{~g})+\mathrm{Cl}_{2}(\mathrm{~g}) \rightarrow 2 \mathrm{HCl}(\mathrm{g})+\mathrm{S}(\mathrm{s})$ | Hydrogen sulphide is oxidised to sulphur by losing hydrogen. |

- In the above processes, oxygen is the oxidizing agent.
- Oxidation can also be a reaction in which hydrogen is removed. In this case, the oxidizing agent removes hydrogen. For example water is the oxidizing agent in the reaction below:-
Magnesium + water (steam) $\longrightarrow$ magnesium oxide + hydrogen gas
Reduction - is the removal of oxygen but can also be the addition of hydrogen. A reducing agent adds hydrogen or removes oxygen.

| $\mathrm{N}_{2}(\mathrm{~g})+3 \mathrm{H}_{2}(\mathrm{~g}) \rightarrow 2 \mathrm{NH}_{3}(\mathrm{~g})$ | Nitrogen is reduced to ammonia by gaining hydrogen. |
| :-- | :-- |
| $\mathrm{PbO}(\mathrm{s})+\mathrm{H}_{2}(\mathrm{~g}) \rightarrow \mathrm{H}_{2} \mathrm{O}_{2}(l)+\mathrm{Pb}(\mathrm{s})$ | Lead oxide is reduced by losing oxygen. <br> (Hydrogen is oxidised to water by gaining oxygen.) |

Reduction of Metal Oxides

- Metals cannot be obtained by heating the oxides.
- The oxides must be heated with something to remove the oxygen.


## Experiment 1

Aim: To show that hydrogen can act as a reducing agent

Materials: hard glass test-tube with a small hole near the end, copper oxide, burner, cork with a short glass tube, rubber tube
Method



# Page 110

![img-101.jpeg](img-101.jpeg)

- Place a spatula load of black copper oxide in the test tube.
- Set up the apparatus as shown above.
- Insert a rubber cork with a short glass tube in the test tube.
- Connect a rubber tube from a gas cylinder containing Bunsen gas to the glass tube.
- Allow a very slow stream of gas to flow through the apparatus and burn it at the small hole. Adjust the gas so that the flame is no more than 2 cm in height.
- Heat the copper oxide with a burner until there is a change in colour.
- Remove the heat.
- Turn off the Bunsen gas and allow the test tube to cool.

NB Bunsen gas which contains hydrogen is used instead of using hydrogen which is dangerous and difficult to handle.

Results and Observation

- The copper oxide glows.
- While the copper oxide is black the copper oxide inside the tube starts to turn brown/metallic red as it is reduced from copper oxide into copper.
- When the experiment is completed copper element remains in the tube as residue.
- The colour change from black to brown/metallic red/orange shows that the remaining residue is copper as opposed with the copper oxide which is used at the start of the experiment.
- Hydrogen in the Bunsen gas reduces copper oxide into copper.
- The hydrogen combines with the oxygen in the copper oxide to form water vapour (steam).


# Conclusion 

- Hydrogen acts as a reducing agent.
- It reduces copper oxide into copper and gives steam as a by product

The word equation can be written as:

## OlmOCR Image Descriptions

### Image: img-101.jpeg

![img-101.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-101.jpeg.png)


s": [{"description": "The diagram illustrates a chemical reaction setup. A bunsen burner is shown on the right side, labeled as 'bunsen gas', which provides heat to the system. The heat is directed towards a tube labeled 'copper oxide'. The reaction results in the formation of copper and excess gas burning. The setup includes a clamp stand for stability."}]}





# Page 111

Copper oxide + hydrogen $\rightarrow$ copper + water.
Qn: Write down the chemical reaction. (2)

# Experiment 2 

To reduce zinc oxide with carbon
Method
4. Mix carbon and zinc oxide together in a crucible lid.
4 Using tongs, hold the lid over flame and heat strongly.
4 Observe the changes.
Observations
Carbon is able to remove oxygen from zinc oxide. The process is called reduction.
When zinc oxide is heated with coke (carbon), zinc and carbon dioxide are obtained.
Word equation: carbon + zinc oxide $\rightarrow$ zinc + carbon dioxide.
Qn: State the chemical equation. (2)
Conclusion
Metals are obtained by reducing their oxides by carbon as a reducing agent.
Experiment 3
Reducing copper with carbon
Aim: To reduce copper oxide with carbon.
Materials: black copper oxide, tongs, crucible lid, powdered carbon, burner

## Method

1. Mix the copper oxide and powdered carbon together in the crucible lid.
2. Using tongs, hold the lid over the hottest part of the flame and heat strongly until you see some change in the mixture
Observation and Results
$>$ The mixture smokes and burns.
$>$ The copper oxide is reduced while carbon dioxide is reduced.

## Conclusion

Copper can be reduced by carbon to give carbon dioxide and copper.
Copper oxide + carbon $\rightarrow$ copper + carbon dioxide.
Qn: Write down the chemical equation. (2)



# Page 112

# Experiment 4 

Oxidation of iron (Rusting)

- The oxidation of iron is called rusting. Oxygen is added to the iron and iron objects look unsightly and eventually start to disintegrate.


## Experiment

Rusting of Iron
Method: see focus on science bk 3 pg 119
![img-102.jpeg](img-102.jpeg)

Observations
The iron nail in water rusts the most
The steel nail is alloyed with other elements hence resist corrosion.
The iron nail in dry air does not rust.
The nail with magnesium ribbon is protected from rusting; magnesium corrodes instead of the nail. Boiled water contains no oxygen so nail does not rust.

## Conclusion

Oxygen and water must be present for iron to rust.
Reversible reactions
Have a forward reaction and a backward reaction happening at the same time e.g. water boils to steam, solid iodine (grey) turns into a purple vapour when heated and reforms crystals solid when cooled.

Physical changes are reversible reactions or processes.

## Metals - Iron

Occurrence
Occurs as haematite (iron iii oxide), found at Redcliff and Buchwa. Main use is to make steel.

## Extraction of Iron

## OlmOCR Image Descriptions

### Image: img-102.jpeg

![img-102.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-102.jpeg.png)


s": [{"description": "Diagram A shows an iron nail placed in water. Diagram B displays a steel nail also submerged in water. Diagram C contains calcium chloride and cotton wool without any water present. Diagram D features an iron nail in water with magnesium ribbon. Finally, Diagram E includes oil on top of boiled water with an iron nail."}]}





# Page 113

Done in the blast furnace, iron iii oxide is reduced to iron using reducing agents carbon and carbon monoxide.

Raw materials

| Raw materials | Source | Uses |
| :-- | :-- | :-- |
| Limestone/CaCO | Redcliff | Removes impurities in the form of slag. |
| Haematite/Iron <br> ore/Fe2O3 | Redcliff/Buchwa/Ripple <br> creek | The source of iron. |
| Coke/ Carbon | Hwange | Burns to produce heat for the smelting <br> purpose. It reducing agent, |
| Hot air/Oxygen | Sable Chemicals | Hot air- contains oxygen for burning coke i.e. <br> Causes coke to burn. |

The Blast Furnace
![img-103.jpeg](img-103.jpeg)

## OlmOCR Image Descriptions

### Image: img-103.jpeg

![img-103.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-103.jpeg.png)


s": [{"description": "The diagram illustrates a blast furnace used in the iron and steel industry. The hopper for loading charge is at the top, where new charge is added. Waste gases exit through the blast of hot air out. Carbon monoxide forms and rises at 800 °C. Iron forms and trickles down at 400 °C. Carbon dioxide forms and rises at 1400 °C. Molten slag is produced, and molten iron exits through the plug hole."}]}





# Page 114

# Describe reactions in the blast furnace 

1. Near the bottom of the furnace, the carbon in coke combines with oxygen to give carbon dioxide.

$$
\mathrm{C}(\mathrm{~s})+\mathrm{O}_{2} \longrightarrow \mathrm{CO}_{2}(\mathrm{~g})+\mathrm{Heat}
$$

2. In the middle of the furnace, more carbon reacts with carbon dioxide to form carbon monoxide.

$$
\mathrm{C}(\mathrm{~s})+\mathrm{CO}_{2}(\mathrm{~g}) \longrightarrow 2 \mathrm{CO}(\mathrm{~g})
$$

3. In the to, carbon monoxide reacts with iron(III) oxide to produce molten iron, which runs down to the bottom of the furnace

$$
\mathrm{Fe}_{2} \mathrm{O}_{3}(\mathrm{~s})+\mathrm{CO} \longrightarrow 2 \mathrm{Fe}(\mathrm{l})+\mathrm{CO}_{2}(\mathrm{~g})
$$

- The molten iron collects at the bottom of the furnace

4. The limestone is decomposed by heat to give calcium oxide

$$
\mathrm{CaCO}_{3}(\mathrm{~s}) \longrightarrow \mathrm{CaO}(\mathrm{~s})+\mathrm{CO}_{2}(\mathrm{~g})
$$

5. Iron ore contains many impurities (silicon, sulphur, phosphorus, etc.) Sand (silica), $\mathrm{SiO}_{2}$, reacts with calcium oxide to produce slag (calcium silicate). Slag runs down to the bottom of the furnace, floating on top of molten iron

$$
\mathrm{CaO}(\mathrm{~s})+\mathrm{SiO}_{2}(\mathrm{~s}) \longrightarrow \mathrm{CaSiO}_{3}(\mathrm{l}) \text { (slag) }
$$

- Molten iron \& slag tapped off separately in furnace. Slag is for road construction.


## Waste gases

- These are carbon dioxide and nitrogen. They come out at the top of the furnace.
- Explanation: The carbon dioxide is from the reduction reaction in stage 3. The nitrogen is from the air blast. It has not taken part in the reactions so has not been changed.



# Page 115

# Oxygen lance process 

![img-104.jpeg](img-104.jpeg)

Is a batch process i.e. the products are manufactured at a given time before adding more raw materials (like pig iron) in the process.

- Oxygen is blown into molten iron (pig iron) through a tube called a lance.
- Temperature increases, all impurities are oxidised.
- Impurities like carbon, sulphur and phosphorus burn into gaseous oxides which quickly escape.
- A pure iron called pig wrought iron is obtained ( $99 \%$ iron).
- Wrought iron is then mixed with other metals to form ALLOYS.

Alloy is a mixture of one metal with one or more other metals and or carbon.
Alloys of iron are pig iron (cast iron), mild steel and stainless steel.
Question 1
State 2 properties and 2 uses of each of the above alloys of iron. (12)

## OlmOCR Image Descriptions

### Image: img-104.jpeg

![img-104.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-104.jpeg.png)


s": ["The diagram illustrates a process involving the use of pure oxygen to treat molten pig iron and scrap iron. The pure oxygen is introduced into the vessel from the top, creating a gaseous environment that facilitates the removal of impurities. The gaseo impurities escape through the upper part of the vessel, while the molten pig iron and scrap iron remain at the bottom. This process likely involves the refining or purification of the metal through oxidation and separation."]}





# Page 116

# ORGANIC CHEMISTRY 

Organic chemistry is a branch of chemistry connected with compounds of hydrogen and carbon (hydrocarbons).

## Hydrocarbons

- Are compounds of hydrogen and carbon only e.g. Alkanes, alkenes, alkyne and alcohols.

Name the members of the homologous series with 3 carbon atoms
Homologous Series:

- These are families of compounds that differ only in the length of their carbon chain.

Alkanes

- Are hydrocarbons that have only a single $\mathrm{C}-\mathrm{C}$ or $\mathrm{C}-\mathrm{H}$ bond.
- They have a general formula $\mathbf{C}_{\mathbf{n}} \mathbf{H}_{\mathbf{2 n}+2}$ e.g. Methane $\left(\mathrm{CH}_{4}\right)$, Ethane $\left(\mathrm{C}_{2} \mathrm{H}_{6}\right)$ and Propane $\left(\mathrm{C}_{3} \mathrm{H}_{8}\right)$.
- Alkanes have only single carbon - carbon bonds, so are saturated.)


## Alkenes

- Are hydrocarbons with a double $\mathrm{C}=\mathrm{C}$ bond.
- They have a general formula $\mathbf{C}_{\mathbf{n}} \mathbf{H}_{\mathbf{2 n}}$ e.g. ethene $\left(\mathrm{C}_{2} \mathrm{H}_{4}\right)$ and Propene $\left(\mathrm{C}_{3} \mathrm{H}_{6}\right)$.
- They contain $\mathrm{C}=\mathrm{C}$ double bonds, they are called unsaturated.
- Draw the displayed structures of methane, ethane, propane, ethene and propene
![img-105.jpeg](img-105.jpeg)

## OlmOCR Image Descriptions

### Image: img-105.jpeg

![img-105.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-105.jpeg.png)


s": [{"description": "The diagram illustrates the structures of alkanes and alkenes. Alkanes are saturated hydrocarbons with single covalent bonds between carbon atoms. Methane (H₄C) is a simple alkane with one carbon atom bonded to four hydrogen atoms, forming a tetrahedral structure. Ethane (H₂C₂H₂) has two carbon atoms and six hydrogen atoms, with each carbon bonded to three hydrogens and the other carbon bonded to two. Propane (H₃CCH₃) consists of three carbon atoms and eight hydrogens, with each carbon bonded to two hydrogens and the other carbons bonded to one each. Alkenes are unsaturated hydrocarbons containing at least one double bond between carbon atoms. Ethene (H₂C=CH₂) has a single carbon-carbon double bond, with each carbon bonded to two hydrogens. Propene (H₃CC=CH₂) contains a carbon-carbon double bond and an additional single bond, with each carbon bonded to three hydrogens."}]}





# Page 117

# Biogas Production 

The Biogas Digester
![img-106.jpeg](img-106.jpeg)

Cow dung is collected while fresh and mixed with water to keep it in a semi - solid state which enables chemical reactions to effectively take place and to ensure the pH of about 7 is kept. The bacteria that digest cow dung are anaerobic bacteria. The decomposition of organ matter is without oxygen is fermentation. Biogas is a mixture of methane, some carbon dioxide, hydrogen and hydrogen sulphide. The products of fermentation are biogas and sludge used as farm manure. Manure, human waste, plant matter can be fed into the digester.

Factors Affecting Biogas Production
Type of waste, the temperature (optimum are between 35 and 55 degrees Celsius), pH not too acidic or alkaline, metals such as zinc will stop fermentation of waste by bacteria and time that the waste is in the digester.

QN What are the uses of biogas? [ 4]

1. Cooking
2. Lighting
3. Operating a refrigerator

## OlmOCR Image Descriptions

### Image: img-106.jpeg

![img-106.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-106.jpeg.png)


s": [{"description": "The diagram illustrates a composting process. It shows a mixture of decomposing wastes and water being placed in a container at a depth of 3 meters below the ground. The container is lined with a brick wall to contain the mixture. The pH of the mixture is suitable for decomposition, which occurs here. Completely rotted wastes (slurry) are collected in another container and used as fertilizer."}]}





# Page 118

# FORM 4 

## BIOLOGY

## Cells and Levels of Organisation

## ECOLOGY

Is the study of the interaction of living things with their environment.

## ECOSYSTEMS

An ecosystem is a community of living things together with their non living environment with which they interact. e. g a pond, garden, soil e.t.c. the earth being a large ecosystem with plant and animal species and their physical sorroundings put together.
![img-107.jpeg](img-107.jpeg)

Components of an Ecosystem

## Abiotic and Biotic

## Abiotic / Physical components

a) Soil-soils support plants .Soils provide plants with nutrients and water. However, not all ecosystems contain soil. Lakes and ponds contain water.
b) Air-oxygen and carbon dioxide are important for respiration and photosynthesis (define these terms).
c) Light-is the ultimate source of energy for all living organisms and vital for photosynthesis to take place.
d) Temperature- it varies from season to season and is related to sunlight and its changes is very important abiotic factor.
e) Water- the quantity and quality of water varies from one ecosystem to another. Water affects the type of plants and animals found in an ecosystem

## OlmOCR Image Descriptions

### Image: img-107.jpeg

![img-107.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-107.jpeg.png)


s": [{"description": "The diagram illustrates an ecosystem, showing the interdependence of various components. At the center is a plant community surrounded by nutrients and habitat. The sun provides energy, while moisture is essential for growth. Soil organisms and minerals are also crucial elements. The diagram emphasizes the complexity and interconnectedness of ecological systems."}]}





# Page 119

f) Humidity- areas of low and high humidity has an influence on ecosystems. For example desrts and coastal areas with low and high humidity respectively.
g) Land- the topography can influence rainfall type, amount and sunlight and area receives.

Biological / living / biotic components

- Producers and consumers are two kinds of living things in any ecosystem.
- The plants that make their own food and the animals that feed on them. The plants are the producers which supply energy to the consumers in the system.
- Consumers are grouped into primary ( leaf eater or herbivores), secondary ( carnivores \& omnivores) and tertiary consumers (decomposers).
- When plants and animals die ,their bodies still contain energy and complex chemicals. These chemicals are broken down and decomposed by micro-organisms, mostly bacteria and fungi. These organisms are called decomposers.

NB: 1. The distribution of living components in an ecosystem is influenced by physical components like shelter and food availability.
2. Energy from the sun flows into an ecosystem and is lost in various ways and stages.

# Role of biological components in the soil 

-Micro-organisms - Include bacteria and fungi. They improve soil fertility by decomposing plant and animal matter
-Earthworms-they improve drainage and aeration by making tunnels in soil hence water penetrates easily. They increase organic matter by pulling plants and grass into the soil. Recycling of nutrients and mixing topsoil and subsoil thereby increasing soil depth.
-Termites - help to stick soil particles together as they make fertile moulds. They secret an alkaline substance which reduces soil acidity.
-Nematodes - they digest plant sticks, stems and grass helping in humus formation.
Feeding Relationships in a Natural Ecosystem
Plants are producers of food and animals are consumers. Organisms in an ecosystem depend on each other for living. The relationships amongst organisms are shown by food chains and food webs.

## Types of Ecosystems

Two types are the natural and artificial ecosystem.

## Natural Ecosystems

- There are no human interferences.
- Pests and diseases are part of the ecosystem and no control measures taken.
- Animals graze freely and no fertilizer application.
- There is natural balance of nature.


## Feeding relationships



# Page 120

## Food Chains

A food chain is a feeding relationship in which energy in producers is transferred to consumers at different trophic levels. Food chains start from the producer to consumers. e.g.

Grass $\rightarrow$ locusts $\rightarrow$ lizards $\rightarrow$ birds.
![img-108.jpeg](img-108.jpeg)

- Grass is the producer. It is eaten by locusts as primary consumers. Locusts are eaten by lizards(secondary) and lizards are eaten by birds.
- Short food chains are advantageous than long food chains as they influence the amount of energy that gets to the last link in the chain.
- If one organism is removed, the chain is affected to an extent a new source of food is needed or face extinction.

Each stage of the food chain is called a trophic level.

Trophic level is the position of an organism in the food chain. The four trophic levels are:

- Producers
- Primary consumers
- Secondary consumers and
- Tertiary consumers


## Food Webs

Food webs are interconnections of food chains or show a complex feeding relationship between organisms. An organism may feed on more than one organism and in turn it may be eaten by others. However, plants are the primary food source and the sun is the only energy input.
![img-109.jpeg](img-109.jpeg)

Exercise
QN3. Draw a food web and extract two food chains from the food web. (8)

## OlmOCR Image Descriptions

### Image: img-108.jpeg

![img-108.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-108.jpeg.png)


s": [{"description": "The diagram illustrates a food chain in an ecosystem. At the base of the food chain, there are grasses and reeds, which serve as primary producers. They are consumed by rabbits, which are primary consumers. The rabbits, in turn, are preyed upon by coyotes, who are secondary consumers. Further up the food chain, snakes feed on frogs, which also consume the grasses and reeds. Eagles, at the top of this particular food chain, hunt for snakes."}]}


### Image: img-109.jpeg

![img-109.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-109.jpeg.png)


s": [{"description": "The diagram on the left illustrates a food web with various organisms and their feeding relationships. Organisms include baboon, scorpion, locust, impala, grass, bird, tick, snake, and hawk. Arrows indicate the direction of energy flow from prey to predator."}, {"description": "The diagram on the right depicts an ecosystem with a tree at its center, surrounded by various animals such as giraffe, lion, elephant, zebra, and birds. The arrows indicate the flow of energy through the food web, starting from the tree and moving up to the top predators."}]}





# Page 121

## Ecological pyramids

The feeding relationships between organisms in a community is represented in pyramid of numbers and biomass.

## Pyramid of Numbers

A pyramid of numbers illustrates the number of organisms at each trophic level in a food chain. Here, organisms interact with each other through energy transfers and are linked by their feeding habits. On the higher levels of the pyramid of numbers can be a tertiary consumer or a decomposer for example hawk. The number of organisms decreases as you go up the pyramid. Again, energy is lost at each level. However, some pyramid of numbers may be inverted if one producer supports many consumers.
![img-110.jpeg](img-110.jpeg)

## Pyramid of Biomass

It shows the mass of organic material at each trophic level. It decreases because of energy which is lost at each level. Producers have the largest total biomass than those at high levels. Thus, high trophic levels have very small numbers of large organisms with low biomass per unit area of the ecosystem.
![img-111.jpeg](img-111.jpeg)

## Energy Flow

- The sun is the source of energy.
- It is converted to chemical energy during photosynthesis.
- As energy moves from one level to another, some is lost.
- From the $100 \%$ energy we will have, about $10 \%$ of the energy can be consumed.
- Energy lost through the process of respiration (as heat).
- Energy used up for movement (to search for food, find a mate, escape from predators...).
- Warm-blood animals (birds and mammals) maintain a standard blood temperature - they lose heat to the environment.
- Warm-blood animals lose heat energy in faeces and urine.
- Some of the material in the organism being eaten is not used by the consumer, for example a locust does not eat the roots of maize, and some of the parts eaten are not digestible.
- So, we can say that cosumers can pass about $10 \%$ of the total energy they receive to the next trophic level.
![img-112.jpeg](img-112.jpeg)

## OlmOCR Image Descriptions

### Image: img-110.jpeg

![img-110.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-110.jpeg.png)


s": [{"description": "The diagram illustrates a food web with land plants at the base, supporting insects and lizards. Lizards are preyed upon by snakes and hawks. Insects and lizards are both consumed by carnivores such as snakes and hawks. The diagram also shows that herbivores feed on producers (land plants), while carnivores can be either herbivores or carnivores themselves."}]}


### Image: img-111.jpeg

![img-111.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-111.jpeg.png)


s": [{"description": "The diagram illustrates a food pyramid with four levels. At the base is the producer level, represented by grass, which has an abundance of 2,000 kg/ha. The primary consumer level consists of locusts, with an abundance of 340 kg/ha. Above that, the secondary consumer level includes lizards, with an abundance of 60 kg/ha. At the top is the tertiary consumer level, represented by hawks, with an abundance of 3 kg/ha."}]}


### Image: img-112.jpeg

![img-112.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-112.jpeg.png)


s": [{"description": "The diagram illustrates an energy flow in a food web. The producers, which are the trees, receive energy from the Sun and convert it into chemical energy through photosynthesis. This energy is then transferred to primary consumers such as rabbits, which are eaten by secondary consumers like snakes. The energy continues to be transferred through the tertiary consumer, the eagle. Throughout this process, there is a significant amount of heat loss at each level."}]}





# Page 122

Question 4. What are the main causes of energy loss at each trophic level in pyramids of biomass?(3)

# Nutrient Cycles in Ecosystems 

Living organisms need substances such as oxygen, water, nitrogen, carbon and phosphorus. These chemicals are recycled through ecosystems and will be available time and again.

## Carbon Cycle

![img-113.jpeg](img-113.jpeg)

- Carbon in ecosystems comes from carbon dioxide in the atmosphere.
- Plants remove carbon from the air during photosynthesis and build it into food compounds.
- Animals obtain carbon by eating plants.
- Decomposers get carbon from remains of dead plants and animals.
- During respiration, carbon is released in the atmosphere by micro-organisms, plants and animals.
- Is also accelerated by human activities such as burning fuels and deforestation.
- Calcium carbonates in shells react with acid rain to release carbondioxide back into the atmosphere.

Green House Effect
Carbon dioxide is a gas which acts as an insulator to keep the earth warm. It traps the sun's energy in the atmosphere. As carbon dioxide increases, so does the temperature of the earth (Global warming).

## OlmOCR Image Descriptions

### Image: img-113.jpeg

![img-113.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-113.jpeg.png)


s": [{"description": "The diagram illustrates the carbon cycle. It starts with Carbon in plants, which undergoes photosynthesis powered by sunlight. The carbon is then transferred to Carbon in soil/earth through respiration/burning and fossilisation + death and decay. From there, it can be released back into the atmosphere as CO2 through burning/chemical reactions or as acid rain. Carbon in animals also contributes to this cycle through respiration. The diagram highlights the continuous flow of carbon between different forms and environments."}]}





# Page 123

Nitrogen Cycle
![img-114.jpeg](img-114.jpeg)

- Nitrogen is present in all proteins of animals and plants.
- When animals and plants die, proteins are decomposed by bacteria and fungi.
- Plants reabsorb nitrates and are transferred to animals through ingestion.
- Soil organisms such as bacteria, millipedes, worms and fungi act on plant and animal matter to change material to ammonium compounds.
- Ammonium compounds are further decomposed by nitrifying bacteria (Nitrosomonas and Nitrobacter).
- Nitrosomonas converts ammonium compounds into nitrites and nitrobacter converts nitrites to nitrates.
- Nitrates are in form of nitrogen which is mainly absorbed by plants.
- About $79 \%$ of the atmosphere is nitrogen and a small amount is changed by lightning into ammonia then to ammonium compounds which can be absorbed by plants.
- A small fraction of nitrogen in the air is converted into nitrates by nitrogen -fixing bacteria (Rhizobium -live in the nodules of legumes).
- If soil aeration is poor, bacteria uses oxygen contained in the nitrates and in the process, nitrogen gas is released into the air (denitrification).


# Artificial ecosystems 

- It is a natural ecosystem that has been interfered with and altered by people. It is one reflecting human interference and change e.g. fish pond, garden, orchard etc.
- Artificial ecosystems are usually characterized by low species diversity e.g. mono-culture.
- The natural balance that allows an ecosystem to be self-sustaining is disrupted in an artificial one. The system may be forced to produce more than it would naturally.
- Crops and animals produced are removed. To maintain self-sustaining artificial ecosystem energy, water and fertility must be supplied.

## OlmOCR Image Descriptions

### Image: img-114.jpeg

![img-114.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-114.jpeg.png)


s": [{"description": "The diagram illustrates the nitrogen cycle in an ecosystem. Nitrogen gas in the air is depicted as a cloud with lightning striking it, leading to the formation of nitric oxide (NO) and nitrous oxide (N2O). These gases dissolve in rainwater, forming acid rain. Soil bacteria fix nitrogen from the atmosphere into nitrates, which are then taken up by plant roots. Nitrogen compounds are converted to nitrogen gas by denitrifying bacteria. Bacteria decompose ammonium compounds into nitrates. Nitrogen is also found in plants and animals."}]}





# Page 124

- Seeds which are supposed to be dispersed naturally are introduced from elsewhere, planted in prepared soil close together.
- Natural predators and control mechanisms are removed in an artificial system and where monocultivation is practiced; pest numbers build up alarmingly leading to the introduction of outside control.


# Biodiversity 

Refers to a variety of life in an area ( plants and animal species). It includes a variety of plants and animals in artificial and natural ecosystems for exapmles in grasslands, national parks, farms and plantations.

## Causes of limited species diversity

- Unsustainable farming practices. List examples of these practices.
- Slash and burning.
- Hunting and poaching.
- Overharvesting.
- Pollution.
- Invasion by alien species ( Kariba weed, water hycinth and cherry pie).


## Consequences of limited species diversity in artificial ecosystem

- Soil erosion.
- Soil infertility.
- Need for the use of artificial fertilisers.
- Plants and animals pests and diseases built up.
- Extinction of some species.
- Loss of ecosystems and land degradation.
- Much human and fuel energy and water is spent in maintaining an artificial productivity level which is intended to produce more biomass than a natural ecosystem would.


## Home Work

QN 2.What are the advantages and disadvantages of artificial and natural ecosystems? (8).

## Management of Ecosystems

Humans play a major role in managing ecosystems if they are aware of the importance of conserving ecosystems.

Ways

- Ground cover- people can help an ecosystem by maintaining ground cover.
- Making use of marginal lands. This can be achieved by improving methods of farming, manuring, mulching and afforestation.

Carrying capacity- the maximum number of organisms the area can support without deterioration.



# Page 125

# Human Activities on Ecosystems 

- Poor farming methods.
- Burning fuels (pollution).
- Deforestation.

Question

1. a) What is limited species diversity? (2)
b) What are the problems caused by limited species diversity? (4)
c) State the advantages of biodiversity. (4)



# Page 126

# NUTRITION 

## Diet

A good diet on its own will not make you skillful or fit as a performer or a sportsperson, but will help you make the most of your abilities through nutrition; hence, nutrition is very important. Your body has the ability to maintain a constant body temperature and a lot of energy is needed to do so. Thus it is important that you should have a good balanced diet to get all the seven components beneficial for nutrition.

## Balanced Diet

- Is a diet that contains all the main nutrients in the correct amounts and proportions to maintain good health. Everyone, whether involved in sport or not should try to eat a healthy balanced diet.


## Components of a Balanced Diet and Functions

## Carbohydrates

They are needed for energy to do all types of work and are required in large quantities. Sugars and starch are important carbohydrates in a diet. Starch includes maize, rice and other cereals. Sugars are in fruits such as mangoes and apples and biscuit and sweet drinks.

## Proteins

These are for building of tissue (growth) and repair of worn out tissues or cells. Are also used to speed up chemical reactions in the body. Proteins are obtained from lean meat, fish, milk, eggs, round nuts, peanut butter, cow peas and e.tc. When proteins are digested, they are broken down into amino acids. These acids are absorbed into blood stream and build up the cytoplasm of cells and tissues. The unused amino acids are changed to glycogen and then stored or oxidized to provide energy.

## Fats

Fats help the body from losing heat therefore, one feels warmer. Fats also provide energy, but fats only contain carbon, hydrogen and oxygen in different proportions as to the carbohydrates. Sources of fats are peanut butter, cooking oil, fat meat and margarine.

## Mineral salts

They are sometimes referred to as fast salts or minerals. Protein, carbohydrates and fats provide the body with carbon, hydrogen, sulphur, oxygen and phosphorus. However, there are more elements found in food we eat e.g. calcium, sodium, iron and others. Calcium is for building bones and teeth and other salts maintain the body in shape and function and iron makes up blood (forms a part of haemoglobin molecule found in red blood cell). Iodine produces a hormone called thyroxin that is needed for growth. Food such as fish, eggs, dried vegetables, liver meat, ishwa contain mineral salts and dairy products.

## Vitamins

They are for health of the body and protection against diseases. Vitamins do not form body structures or provide energy but are needed in the body for chemical reactions in cells. Once a diet lacks vitamins people may suffer from vitamin- deficiency diseases. Vitamin A is neededfor good eye sight, health skin, growing bones and immune system. Vitamin C is an antioxidant that protects the body from harmful



# Page 127

radicals and help in absorption of iron. Vitamin D or califerol helps absorption of calcium They are from plants and animals for example from cabbages, butter, cheese, tomatoes okra, milk, fruits, eggs and carrots.

# Water 

It is an important part of cytoplasm. Substances are carried around the body in watery solution in blood e.g nutrients, oxygen and wastes. It is also important in the digestion of food by softening it and moving it. Soft tissues and joints rely on the cushioning that water provides for them. In addition, water is obtained from fruits such as oranges and cucumbers and melons.

## Roughage

It is the indigestible parts of plant foods food in cereals such as oats and bran. It absorbs water, providing bulk to faeces. It binds with cholestrol to reduce cholestrol levels in blood. Helps in digestion i.e. help movement of waste matter in the colon and the rectum ( making them softer) so that constipation is prevented and also absorbs poisonous substances and are ejected as faeces. Define the term constipation. (2)

## Malnutrition

is the result of not eating a balanced diet. There may be:

- Wrong amount of food: too little or too much.
- Incorrect proportion of main nutrients.
- Lacking in one or more key nutrients.

Effects of malnutrition
a) Obesity - Too much food (carbohydrate, fat or protein).
b) Coronary heart disease

- Too much saturated/animal fat in the diet results in high cholesterol levels.
- Cholesterol can stick to the walls of arteries, gradually blocking them.
- If coronary arteries become blocked, the results can be angina and coronary heart disease.
c) Starvation
- Too little food can result in starvation.
- Extreme slimming diets, such as those that avoid carbohydrate foods, can result in the disease anorexia nervosa.
d) Childhood protein-energy malnutrition (Kwashiorkor)
- Wrong proportion of nutrients e.g. too much carbohydrates (starchy foods) and a lack of protein can lead to kwashiorkor in young children.


## Deficiency Diseases - define.

## Kwashiorkor

Is due to lack of protein. The symptoms include underweight, enlarged abdomen and the children is inactive.

## Rickets



# Page 128

Are skeletal disorder as a result of lack of calcium and vitamin D which is made in animal cells with the help of sunlight It results in weak bones hence the bones bend under the body weight, resulting in rounded legs and deforities of the pelvis, skull and ribcage. What are the corrective measures to this disease? (3)

# Bleeding gums 

This occurs when one lacks vitamin A. The symptoms are weak gums and bleeding gums especially when one is brushing the teeth. Eating of fruit such as oranges help to prevent bleeding of gums.

Anemia - lack of iron in the body results in lack of haemogolobin formation hence low oxygen is transported to cells hence less energy is made in cells, leading to tiredness and weakness. How can it be controlled? (4)

## Goiter

Is due to lack of iodine since iodine is needed by the thyroid gland in the neck. The swelling of the thyroid gland in the neck is goiter. In children, mental and physical development is retarded. People must include iodine in their diets and use iodine salt in food.

## Night blindness

It is caused by lack of vitamin A rich foods. A person cannot see proper during the night. One should eat liver, green vegetables and carrots.

## Scurvy

Vitamin C deficiency caauses scurvy. A person with scurvy bruises easily, has joint and muscle pains. It is treated by taking vitamin tablets and eating a lot of fruits.

## Food Tests

Foods can be tested so that we find food groups they contain. This is crucial in the sense that people are able to plan their diets and plan diets for other people.

## Experiments

| NUTRIENT | REAGENT(S) | PROCEDURE | RESULTS <br> WHEN <br> NUTRIENT <br> PRESENT | WHEN <br> NUTRIENT IS <br> ABSENT |
| :--: | :--: | :--: | :--: | :--: |
| Starch | -Iodine Solution | -Add iodine to <br> food sample <br> -Observe colour <br> changes | -Brown to blue <br> black | -Brown |
| Simple/reducing <br> sugar(glucose) | a)Benedict's Solution <br> b)Clinistix | -add benedict to <br> the food sample. <br> - heat over a <br> water bath. <br> - shake the test <br> tube and examine <br> colour. <br> - State the mtd. | a) Blue to <br> orange/brick red <br> b) Pink to purple | a) Blue <br> b) pink |



# Page 129

| Protein | a)Biuret Test copper sulphate solution and sodium hydroxide solution (equal quantities) | - prepare food sample. <br> -add sodium hydroxide into the test tube. <br> -add copper sulphate not so rapidly. <br> -shake at each drop. <br> - State the mtd. | a)Blue to purple/violet | a) Blue |
| :--: | :--: | :--: | :--: | :--: |
|  | b)Albustix |  | b) Green to Dark green | b) Green |
| Fats | a)Ethanol/Emulsion Test | - add ethanol to the food sample and shake well. -add water and shake. | a) milky white emulsion | clear |
|  | b) Transparent Test | - State the mtd | b) Transparent Mark |  |

# RESPIRATORY SYSTEMS 

## Respiration

Is the breaking down of glucose to release energy.

## Aerobic Respiration

It is the complete breakdown of food (glucose) to release a relatively large amount of energy. The food is oxidized or burnt using oxygen to release energy.

Energy carrier molecules

1. ATP ( Adenosine triphosphate)- is formed when a phosphate group is joined to ADP (Adenosine diphosphate) with two phosphate groups.
$\mathrm{ADP}+\mathrm{P}+$ Energy $\rightarrow$ ATP
In ATP molecule, energy is stored as chemical energy. One glocuse molecule yields 38 ATP molecules. ATP MOLECULE will release energy when required and releases a phosphate group to form ADP.



# Page 130

ATP $\rightarrow$ ADP $+\mathrm{P}+$ energy.
Oxygen is needed for a glucose molecule to be broken down.
Word equation
enzymes
Glucose + oxygen $\rightarrow$ carbon dioxide + water + energy.
Energy is released when glucose is burnt. Glucose and oxygen are supplied to body cells in blood. Water and carbon dioxide are released as wastes.

Aerobic respiration process
It occurs in three stages: glycolysis, the krebs cycle, Oxidative phosphorylation.
![img-115.jpeg](img-115.jpeg)

1. Glycolysis- splitting up of glucose without oxygen and produces ATP molecules.
2. The krebs cycle- it starts in the mitrochondia. Pyruvic acid is broken into energy rich hydrogen atoms and carbon dioxide which will be released into the air.
3. Oxidative phosphorylation- occurs in the mitochondria. In the first phases, rich hydrogen atoms are given off but in this stage, they are processed into 36 ATP molecules. Once energy is stored, the low-energy or tired out hydrogen atoms combine with oxygen to form water molecules.

Question 1
What are the differences between photosynthesis and respiration? (5)

# Anaerobic Respiration 

Respiration takes place without oxygen. The food is not completely broken down and small amount of energy is released.

Yeast, a fungus, respires anaerobically. Human muscle is able to respire anaerobically when the demand for oxygen exceeds the supply.

Alcoholic fermentation
enzymes
Glucose $\rightarrow$ carbon dioxide + alcohol + energy.
Lactic acid fermentation

* Occurs in animals. During strenuous exercise, circulatory system cannot supply enough oxygen to muscles hence get extra energy by respiring anaerobically. The glucose is broken down into lactic

## OlmOCR Image Descriptions

### Image: img-115.jpeg

![img-115.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-115.jpeg.png)


s": [{"description": "The diagram illustrates the process of cellular respiration. Glucose enters the cell and undergoes glycolysis in the cytoplasm, producing pyruvate. Pyruvate then enters the mitochondrion where it is converted into acetyl-CoA, which enters the Krebs cycle (also known as the citric acid cycle). The Krebs cycle produces energy-rich hydrogen atoms that are used in oxidative phosphorylation to generate ATP. Oxygen and water are required for this process. Carbon dioxide is produced as a waste product."}]}





# Page 131

acid. After the exercise, lactic acid is broken into carbon dioxide and water. In order to do this, a lot of oxygen is needed and thus why people continue to be quite hard after exercise for some time. The advantage of being able to do this is that the muscles can still function and obtain some energy even though there isn't much oxygen available.
Lactic acid causes stiffness in muscle (muscle fatigue).
enzymes
Glucose $\rightarrow$ lactic acid + energy.
Experiment 1
Which gas is released by respiring organisms/animals?
Apparatus: potassium hydroxide, lime water or bi-carbonate indicator, gas jar, a frog/ rat, test tubes e.t.c Method
![img-116.jpeg](img-116.jpeg)

4 Arrange the apparatus as shown:
4 Put an animal in a jar or flask No 3.
4 Put equal amounts of indicator in test tubes1 (A), 2 (X) and 4 (Y).

Observations
At 1 carbon dioxide is removed from the air coming in.

At 2, the indicator is a check to make sure there is no carbon dioxide.

The respiring organism is at 3 .
At 4, there is the carbon dioxide which turns milky.

Results
Lime water in 4 or D turns milky.
Conclusion
Respiring organisms release carbon dioxide.

Experiment 2
To prove that germinating seeds produce heat energy

Materials: 2 vacuum flasks, thermometers, cotton wool, 2 stands, soaked seeds, disinfectant, boiled seeds,

## OlmOCR Image Descriptions

### Image: img-116.jpeg

![img-116.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-116.jpeg.png)


s": [{"description": "The diagram illustrates an experiment to remove carbon dioxide from the surroundings. It consists of four main parts:\n\n1. A container labeled 'Liquid A (To remove carbon dioxide)' with a valve and a tube leading to a test tube.\n2. Test tube X (Limewater) connected to the container through a valve, indicating the flow of gas or liquid.\n3. A glass tank labeled 'valve' with a rat inside, suggesting the presence of the subject for the experiment.\n4. Test tube Y (Limewater) connected to the suction air pump, showing the setup for removing carbon dioxide from the surroundings."}]}





# Page 132

Method
![img-117.jpeg](img-117.jpeg)
4. Soak the seeds to soften them.
4. Boil half of the soaked seeds to kill them. Allow them to cool, wash them in disinfectant.
4. Place them in an insulated container and set thermometer in unboiled seeds and another in boiled seeds.
4. Record the temperature of each container and leave for few days.
4 Record the temperature of each day.
Changes in temperature

| Day | Flask A | Flask B |
| :-- | :-- | :-- |
| 1 | 25 | 25 |
| 2 | 26 | 25 |
| 3 | 27 | 25 |

Results

- Temperate in flask A rises by 2 while temperature in flask B remain unchanged.
- Identify the error in the experiment.

Conclusion
Germinating seeds produce heat energy.

# TRANSPORT SYSTEMS 

## Transpiration

## Adaptations of a leaf for transpiration

* Leaf size and surface- some trees have leaves with small surface area so they can transpire less.
* Have waxy leaf cuticle which reduces excessive water loss. Water cannot escape waxy layer. e.g. pumpkin leaves.
* Presence of hairs on the leaf - hairs trap water vapour and air and thus lessen the loss of more water.
* Stomata- opens during the day and closes at night.during drought, stoma will close to save water
* They develop few stomata on the upper surface. This ensures that direct rays from the sun are prevented from striking most of the stomata as they are on the lower surface / underside thus there will be less water loss.
* Leaf arrangement- some leaves will be butterfly shaped, some will move closer and hang vertically for example mopane leaves.

Experiment 1
To determine which surface of a leaf loses more water vapour

Method

## OlmOCR Image Descriptions

### Image: img-117.jpeg

![img-117.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-117.jpeg.png)


s": [{"description": "The diagram illustrates an experiment comparing germinating seeds with boiled seeds. Two containers labeled A and B are shown side by side. Container A contains germinating seeds placed on wet cotton, while container B contains boiled seeds also placed on wet cotton. Both containers have thermometers inserted to measure the temperature."}]}





# Page 133

1. Take 4 leaves of similar size.
2. Carefully smear both surfaces of leaf A with petroleum jelly / vaseline.
3. Cover the ventral surface (underside) of leaf B with petroleum jelly.
4. Cover the dorsal surface or (upper side) of leaf C with petroleum jelly.
5. Leave the one remaining leaf (D) / both surfaces uncovered .
6. Weigh each of the leaves on the balance.
7. Place a little vaseline on the cut end of the leaf stalk and suspend a piece of string between two retort stands and attach each of the 4 leaves to the string. Leave until next lesson.
8. Observe the appearance of the leaves and reweigh them.
9. Calculate the loss in mass of each of the leaves.
![img-118.jpeg](img-118.jpeg)

Observations

- Leaf A does not lose water at all.
- Leaf B loses water.
- Leaf C loses little water.
- Leaf D dries out most or fast.

Results

- More water is lost at D because more stomata are on the ventral surface of the leaf.

Conclusion

- The ventral surface loses more water than the dorsal surface of the leaf.


# Interpretation 

- The vaseline prevents evaporation.
- The untreated leaf and the leaf with its dorsal surface sealed show the greatest degree of shrivelling, so it is from the ventral surface that leaves lose most water by evaporation.
- More rapid results can be obtained by sticking small squares of blue cobalt chloride paper to the dorsal and ventral surface of the same leaf using transparent adhesive tape.
- Cobalt chloride paper changes from blue to pink as it takes up moisture. By comparing the time taken for each square to go pink, the relative rates of evaporation from each surface can be compared.

## OlmOCR Image Descriptions

### Image: img-118.jpeg

![img-118.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-118.jpeg.png)


s": [{"description": "The diagram illustrates a setup involving four leaves labeled A, B, C, and D. Each leaf is suspended from a string attached to a stand. The leaves are arranged in a line with the following observations:\n\n- Leaf A: Positioned upright, indicating no significant force acting on it.\n- Leaf B: Slightly tilted, suggesting a gentle force applied.\n- Leaf C: More pronounced tilt compared to leaf B, showing an increased force.\n- Leaf D: Leaning further, demonstrating the greatest force among the leaves.\n\nThe diagram uses labels such as 'string' and 'stand' to denote the components of the setup. The arrangement and angles of the leaves provide a visual representation of varying forces applied."}]}





# Page 134

# Blood 

Blood is a circulating tissue which consists of blood cells and blood plasma. Blood cells include red blood cells, white blood cells and platelets.

Question 1
a) What are the function of the following blood cells?
i. Red blood cells.
ii. White blood cells.
iii. Platelets.
b) What is blood plasma? (6)

Blood Plasma
Plasma is a yellowish fluid consisting of water, nutrients, wastes, gases and plasma proteins. It is the medium in which blood cells are moved to all parts of the body. Plasma transports digested food substances, absorbed from the ileum to all parts of the body. It moves excretory products from tissues to the excretory organs e.g. urea to the kidneys and carbon dioxide to the lungs. It also distributes heat of the body.

Red Blood Cells
Red blood cells are small, round biconcave discs without a nucleus. They transport oxygen. Red blood cells have haemoglobin which combines with oxygen to form oxyhaemoglobin which is taken to all tissue where it releases the oxygen.

White Blood Cells
These are larger than the red blood cells, have no definite shape and have a nucleus. White blood cell protect the body from infection and disease. They attack invading foreign particles and germs such as bacteria and viruses in two ways. 1. Some are phagocytic - they engulf and destroy invading bacteria and viruses, thus preventing them from spreading to the rest of the body. 2. By secretion of antibodies by some white blood cells. Antibodies attack and neutralize disease agents.

Blood Platelets
Are the smallest numerous bodies found in blood. They have no nuclei and are oval shaped. They are responsible for clotting of blood. They secret enzymes which assist in conversion of special plasma proteins which form thread like structures on the wound. The thread form clot which prevent loss of blood and further entry of germs.

Structures of Red blood cells, white blood cells and blood platelets



# Page 135

![img-119.jpeg](img-119.jpeg)

Functions of blood
$\checkmark$ Is a medium that carries nutrients, oxygen and plasma proteins to where they are needed.
$\checkmark$ Carries waste substances produced by the body to organs of secretion such as lungs and kidneys.
$\checkmark$ Has a homeostatic function i.e. maintaining of temperature and water, salt and glucose levels at constant optimum conditions.
$\checkmark$ Distributes heat and protects the body against infection.

# Blood Vessels 

is a tube with a space in the centre, called the lumen
The Arteries.
Arteries transport blood from the heart to all parts of the body except the pulmonary artery.
They are thick walled muscular and elastic in order to resist surges of high pressure caused by the pumping action of the heart. They have a narrow passage (lumen). Carry blood of high pressure. Have no valves.
![img-120.jpeg](img-120.jpeg)

## OlmOCR Image Descriptions

### Image: img-119.jpeg

![img-119.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-119.jpeg.png)


s": [{"description": "The diagram consists of three sections labeled 1, 2, and 3. Section 1 shows two elongated shapes with a central indentation, resembling cells or bacteria. Section 2 depicts a circular shape with a dark nucleus-like structure inside, possibly representing a cell or a similar biological entity. Section 3 illustrates a cluster of small, round objects, which could be interpreted as particles or droplets."}]}


### Image: img-120.jpeg

![img-120.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-120.jpeg.png)


s": [{"description": "The diagram illustrates the structural differences between an artery and a vein. The artery is depicted on the left side of the image, showing a single layer of endothelial cells lining the inner lumen, which is one cell thick. The outer layer consists of muscle tissue and elastic fibers. The vein, shown on the right side, also has a single layer of endothelial cells lining the inner lumen, which is one cell thick. The outer layer includes muscle layers and elastic tissue."}, {"description": "The capillary section at the bottom of the diagram highlights its unique structure compared to arteries and veins. It shows a single layer of endothelial cells surrounding the lumen, with the nucleus of an endothelial cell visible within this layer. This simplicity in structure is characteristic of capillaries, which facilitate the exchange of materials between blood and tissues."}]}





# Page 136

The Veins
Veins transport blood from all parts of the body to the heart except the pulmonary vein. They are thinwalled, less muscular and have wider lumen than arteries. Have valves to prevent backflow of blood. They transport blood under very little pressure.

Home Work
2. a) What are capillaries? (2)
b) State two functions of capillaries. (2)

The Capillaries
These are small / microscopic fine tubes connecting the arteries to the veins. Their walls are one cell thick. They are permeable, allowing exchange of materials. Water and dissolved substances are allowed to pass in and out of the capillaries while oxygen, carbon dioxide, dissolved food and excretory substances are exchanged within tissues round the capillary. Transport blood with low pressure and have valves.
![img-121.jpeg](img-121.jpeg)

## OlmOCR Image Descriptions

### Image: img-121.jpeg

![img-121.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-121.jpeg.png)


s": [{"description": "The diagram illustrates the microcirculatory system focusing on capillaries. It shows an arteriole branching into numerous capillaries that form a network of tiny blood vessels. These capillaries connect to a venule which eventually leads to a vein. The diagram also highlights tissue cells through which blood flows, ensuring nutrient delivery and waste removal."}]}





# Page 137

# REPRODUCTIVE SYSTEM 

## Vegetative Reproduction in Plants

- Is also called propagation or reproduction without seeds.
- It is the production of new plants by methods other than seed formation.
- This is a non-sexual form of reproduction. Only one parent is involved to produce other plants by use of stem buds with or without leaves or roots.
Methods of vegetative reproduction
Natural vegetative reproduction
- Some plants develop specialized structures that can be used as organs of nature vegetative reproduction.
- Shoots develop from these structures and grow till they develop their own adventurous root system and later become independent parent plant.
Examples are:-
- Rhizomes -is an underground stem that grows parallel to the ground and develop shoots from buds at nodes on underground stems. The stem become swollen with stored food. e.g. ginger, sweet potatoes, grass / lawn, canna lilies etc.
- Tubers- are underground stems that are swollen with food e.g.
- $\quad$ Stem tubers - these are the swollen ends of stem structures that develop shoots which grow horizontally at first and grow down into the soil heaped around the plant e.g. potatoes, yams.
- Root tubers - are lateral root that has been modified to function as a storage organ. The middle part that store nutrients is enlarged and can involve the whole root. The food reserves are used to produce new tubers e.g cassava and sweet potatoes.

Artificial vegetative propagation

- Buds - can be induced to produce new plants from cuttings by layering and bud grafting e.g. sugar cane, cassava etc.
- Cuttings -are small parts of plants. These are cut off and used for producing other plants e.g. sugar cane, sweet potato, cassava etc.
- Suckers - these are outgrowth which grow from the stem below ground level. The terminal bud of a sucker grows upwards through the soil and form leaves above the surface. Roots form in the underground potion of the sucker and an independent plant is formed which losses its connection with the parent. e.g. covo, and bananas.



# Page 138

Experiment:
Growing plants using vegetative means.
Materials: trays of soil, plant cuttings of sugarcane, mulberry, sweet potatoes, roses

Method
![img-122.jpeg](img-122.jpeg)
$\checkmark$ Cut pieces into sections and leave the bud/eye.
$\checkmark$ Remove most of the leaves.
$\checkmark$ Plant sections into the soil and make sure the sweet potato sugarcane cutting is covered with soil.
$\checkmark$ Record number of cuttings planted.
$\checkmark$ Irrigate the trays or beds.
Results
$\checkmark$ The cuttings develop roots and grow after some weeks.
$\checkmark$ Removing leaves reduces transpiration.
$\checkmark$ Plants grow from the buds hence more plants grow than cuttings planted.

Advantages of vegetative reproduction

- Plants are identical to the parent plant
- Grow quickly as long conditions are favourable.
- Good chances of survival due to availability of stored food.
- Maturing more quickly than seed planted at the same time.
- Don't rely upon pollination, fertilization and seed dispersal.


## Disadvantages

- No variety (not showing any genetic variation for parent plant).
- Vulnerable to the same pests and diseases as parent plant.
- Cannot reproduce in large numbers as in seeds.
- Cannot be dispersed away from the parent plant thereby causing overcrowding.

## OlmOCR Image Descriptions

### Image: img-122.jpeg

![img-122.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-122.jpeg.png)


s":"The image shows a person planting small sticks into a bed of soil. The sticks are arranged in a pattern, possibly for a garden or landscaping project. The soil appears to be well-prepared and ready for planting. In the background, there is a chair and some other items that suggest this activity is taking place indoors or in a controlled environment."}





# Page 139

![img-123.jpeg](img-123.jpeg)

# Question 3 

a) State the different between stem tubers and root tubers. (4)
b) Outline the differences between sexual and asexual reproduction. [6]

## Solution b)

| Sexual | Asexual |
| :-- | :-- |
| Two plants | One plant |
| Variation occurs in offsprings | Offsprings are genetically identical to each other <br> and their parent |
| Fertilisation takes place | No fertilisation takes place |
| Gametes are involved | No gametes involved |
| Mixing of hereditary material | No mixing of hereditary material. |

## OlmOCR Image Descriptions

### Image: img-123.jpeg

![img-123.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-123.jpeg.png)


s": [{"image": "Rhizomes", "description": "The diagram illustrates a rhizome with various labeled parts. A new plant is growing from the rhizome, and it has a scale leaf, adventitious root, bud, and node. The rhizome itself is shown as a horizontal underground stem that stores food and water for the plant."}, {"image": "Rhizomes", "description": "This diagram shows a close-up view of a rhizome with green leaves and fibrous adventitious roots. It highlights the runner, scale leaf, node, and green leaf, emphasizing the root system's structure and growth pattern."}, {"image": "Tuber", "description": "The diagram depicts a tuber with labeled parts such as young shoot, germinating eye bud, roots, and eye. The tuber is shown to be a storage organ for plants, containing food reserves that support new growth."}, {"image": "Cuttings", "description": "This diagram illustrates the process of cutting propagation. It shows a stem cutting with new shoots developing from it. The cutting is placed in moist, loose soil, and the diagram highlights the importance of proper conditions for successful rooting."}]}





# Page 140

# Methods of Human Contraception 

There are a number of contraception methods for preventing fertilisation or conception. Some methods are very effective and safe while others are less reliable.

## Natural methods

|  | Abstinence | Woman avoids sexual intercourse completely |
| :--: | :--: | :--: |
| How they work | Rhythm method | Woman keeps track of her body temperature (that rises at ovulation) and doesn't have sex during this period |
|  |  | Woman checks if the mucus produced in her vagina has become slippery or not |
|  | Withdrawal | Man withdraws his penis before ejaculation. |
| Advantages | Useful for couples who don't want to use other measures of birth control for religious or other reasons |  |
|  | No side effects |  |
| Disadvantages | It is never possible to be $100 \%$ certain about ovulation period High risk of STIs |  |

## Hormonal Methods

Contraceptive Pills

## Contraceptive Pills

- Contraceptive pills containing sex hormones can be taken by the woman; this stops the production of egg cells in the ovaries
- Sometimes contains copper.

| - A very effective method only when contraceptive pills are taken at the right time. |  |
| :--: | :--: |
| Disadvantages | - It is important to have regular checkups by a doctor as some women do experience side effects of contraceptive pills |



# Page 141

- Contraceptive pills play a vicious part in river pollution and cause some male fish to change gender as well!


# Mechanical/ Barrier Methods 

- A condom is a piece of rubber sheath
- A condom is placed upon the erect penis and acts as a barrier between the sperm and the vagina.
- A femidom is a female version of a condom and is used similarly
- A diaphragm is a circular and slightly domed piece of rubber
- Inserted into the vagina on the top of the cervix
- Diaphragms are often used with spermicide for the best results

IUD(Intra-UterineDevice)

A device called as an IUD can be used.

- An IUD releases hormones that prevent implantation and development of any fertilized egg cell.

Condom is a very safe method of contraception only if it is used correctly.
Condom helps in the prevention of HIV and gonorrhoea
Spermicides - Spermicides can be used to kill sperm that enter the vaginı
Diaphragm is also a very safe and reliable method IF used with spermicide

## Advantages

Disadvantages

Suggests advantages of some barrier methods above. (8)

Care must be taken when using a condom or a femidom; no sperm should escape through it.



# Page 142

# Surgical Methods 

|  | Vasectomy | - In a man the sperm ducts are cut and tied, thus preventing the passage of any sperms produced. |
| :--: | :--: | :--: |
| How it works | Tubal ligation | - In a woman the oviducts are cut or tied, sopping egg cells from travelling down the oviduct. |
| Advantages | - Extremely reliable and sure method of contraception. |  |
|  | - Have no side effects. |  |
| Disadvantages | - The tubes cannot be often opened. |  |
|  | - Not suitable for young couples who may wish to have children later. |  |



# Page 143

# HEALTH AND DISEASES 

Immunity - is the ability of the body to resist infection.

1. Acquired Immunity/Active Immunity
-When one suffers from a disease like small pox or measles, they develop immunity. One will not suffer from the disease again. This is because antibodies are produced against the pathogen and they remain active in the blood ready for new attack.
2. Natural Passive Immunity
-Passed on through the placenta or from mother to child during breast feeding.
-Antibodies are transferred from the mother to the child to gain immunity.
3.Artificial Immunity
-Antibodies are produced after vaccination. A vaccine containing dead and weakened pathogen of a disease. When they are injected into the body, the body produces antibodies that destroy the weak pathogens.

Infants acquire immunity through breast feeding and immunization.
Immunisation
-Is to offer artificial immunity.
In Zimbabwe children are vaccinated to:
a) Eliminate diseases e.g. to eliminate measles.
b) Protect children against the killer diseases such as Polio, Diphtheria, Measles, whooping cough, Tetanus, T.B. Hepatitis B.
c) Introduce a vaccine of certain diseases for the first time e.g. rubella vaccine.
N.B. B.C.G is a vaccine against T.B.

Vitamin A supplements are provided to prevent vitamin A deficiency in children (6 months to 59 months).
The programmes are carried out for free.
NB: H.IV. Causes a destruction of the immune system (bodies defence system) that is why a person suffers from many diseases. It interferes or destroys the white blood cell that produces antibodies.

Advantages of Breast Feeding
It is hygienic, it has all food nutrients, more of a balanced diet and it contains antibodies.
Question 4
Describe passive and active and artificial immunity. (9)
HIV / AIDS
HIV and Its effects
> HIV stands for Human Immunodeficiency Virus.



# Page 144

$>$ It lives in the body fluids including blood, saliva, semen, tears etc
$>$ It enters the body in the following ways:
a) During unprotected sex with an infected person.
b) Through sharing contaminated (by HIV) needles when administering drugs.
c) During blood transfusion if the blood is contaminated by the virus.
d) From infected mother to child during pregnancy, at birth and during breastfeeding.
$>$ The virus reduces the body's ability to fight infection and disease by destroying the body's white blood cells responsible for producing the antibodies.
$>$ A person is deemed to be HIV positive if that person's blood is tested for the HIV virus and it is found to be present in his/her blood.
$>$ A person can look healthy and yet be HIV positive

# AIDS 

$>$ Stands for Acquired Immuno Deficiency Syndrome.
$>$ It is a stage during the HIV infection when the HIV has destroyed the body's defence system, causing the individual to become susceptible (vulnerable) to multiple infections and failing to recover.
$>$ This stage can (and will likely) lead to death
$>$ There is no cure for AIDS
> .Exercising a healthy diet, maintaining a positive attitude, seeking early treatment when an opportunistic infection surfaces and
$>$ Taking Antiretroviral drugs (ARVs).
$>$ All significantly prolong a person's life.



# Page 145

# FORM 4 <br> CHEMISTRY SECTION 

## SEPARATION

## Paper chromatography

## Paper Chromatography

- Is a method of separating and identifying mixtures.

Application of paper chromatography

- Separates and identify mixtures of coloured substances in dyes.
- Separates substances in urine, drugs \& blood for medicinal uses.
- To find out whether athletes have been using banned drugs.

Separating Mixtures of Coloured Substances

1. Obtain a dye sample then put a drop of the sample on a pencil line drawn on the filter paper then dip the paper into a solvent with the level below the spot.
2. The dye will dissolve in solvent and travel up the paper at different speed. Hence they are separated.

Identifying Mixtures of Coloured Substances

- In the diagram on the right, drop of sample dye is placed on pencil line. The result shows that:
a) The sample dye is made of 3 colours.
b) Comparison dyes are of one of the compositions of the original dye as the spots are of same colour and distance.
c) A comparison dye isn't part of sample.
![img-124.jpeg](img-124.jpeg)

## OlmOCR Image Descriptions

### Image: img-124.jpeg

![img-124.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-124.jpeg.png)


s": [{"description": "The diagram illustrates a glass container filled with a solvent and an original dye. Several comparison dyes are placed at the bottom of the container. The solvent separates these dyes into distinct bands, creating a pencil line that indicates the separation points. The separated colors are clearly visible above the pencil line."}]}





# Page 146

# Tends in the periodic table 

The elements in each numbered group shows trends in their properties. For example as you go down group 1, the elements become more reactive or as you go down group 7 the elements become less reactive and so on.

## Group 1: The alkali metals

## Their physical properties:

1. Like all metals, they are good conductors of heat and electricity.
2. They are softer than most other metals and they have low density.
3. They have low melting and boiling points, compared to most metals.

## Their chemical properties:

1. All alkali metals react vigorously with water, releasing hydrogen gas and forming hydroxides. The hydroxides give alkaline solutions.
2. They react with non-metals. With chlorine they react to make chlorides and with oxygen they make oxides.

They form ionic compounds in which the metal ion has a charge of $1+$. The compounds are white solids, which dissolve in water to give a colorless solution.

## The trend in physical properties

![img-125.jpeg](img-125.jpeg)

Why they have similar properties?
Because atoms with the same number of valency electrons react in a similar way.

## OlmOCR Image Descriptions

### Image: img-125.jpeg

![img-125.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-125.jpeg.png)


s": [{"description": "The diagram illustrates the trends in physical properties of Group 1 elements (Lithium to Caesium) as we move down the group. Lithium is at the top and Caesium at the bottom. As we move from lithium to caesium:\n\n- Softness increases, indicated by the arrow pointing downwards.\n- Density increases, shown by another downward arrow.\n- Melting points decrease, marked with a third arrow.\n- Boiling points decrease, represented by the final arrow."}]}





# Page 147

As you go down the group reactivity increase.
Why?
Because the atoms get larger down the group because they add electron shells.

# Group 7: The halogens 

A non-metal group.
Form colored gases.
Are poisonous
Are brittle and crumbly in their solid form, and do not conduct electricity.
Form diatomic molecules (means they exist as 2 atoms)

Trends in their physical properties
![img-126.jpeg](img-126.jpeg)

Trends in their chemical properties
Reactivity increases as you go up group 7.
Why?
Because the smaller the atom, the easier it is to attract the electron - so the more reactive the element will be.

Why are they so reactive?
Because their atoms are only one electron short of a full shell.

## OlmOCR Image Descriptions

### Image: img-126.jpeg

![img-126.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-126.jpeg.png)


s": [{"description": "The diagram illustrates the trend of properties for halogen elements from fluorine to iodine. It shows that as we move down the group, the size and mass of the atom increase, leading to an increase in density and melting and boiling points."}]}





# Page 148

# Group 0: The noble gases 

A non-metal group
$\square$ Contains colorless gases, which occur naturally in air
$\square$ Monatomic - they exist as single atoms
$\square$ Unreactive because they have a full outer shell.
Trends in their physical properties
![img-127.jpeg](img-127.jpeg)

## Uses of noble gases

Noble gases are unreactive, making them safe to use. They also glow when current is passed through them at low pressure.

| Gas | Use |
| :--: | :-- |
| Helium | -Used to fill balloons and airships, because <br> it is much lighter than air and will not catch <br> fire |
| Neon | -Used in advertising signs. It glows red, but <br> the color can be changed by mixing it with <br> other gases. |
| Argon | -Used as a filler in ordinary tungsten light <br> bulbs. (oxygen would make the tungsten <br> filament burn away) <br> -Used to protect metals that are being <br> welded. It won't react with the hot metals <br> (unlike oxygen) |
| Krypton | -Used in lasers. For example for eye <br> surgery and in car headlamps |
| Xenon | -Used in lighthouse lamps, lights for <br> hospitals operating theatres, and car <br> headlamps. |

## OlmOCR Image Descriptions

### Image: img-127.jpeg

![img-127.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-127.jpeg.png)


s": [{"description": "The diagram shows a flowchart with four elements at the top: Helium, Neon, Argon, and Xenon. Each element is connected to a box that describes a property of the noble gases. The first box states 'Size and mass of atom increases' for Helium, Neon, Argon, and Xenon. The second box indicates 'Density of gas increases' for all elements. The third box notes 'boiling points increase' for all elements."}]}





# Page 149

# The transition elements 

The transition elements are the block of 30 elements in the middle of the periodic table. They are all metals.

## Their physical properties

Hard, tough and strong
High melting points (mercury is an exception)
Malleable and ductile
Good conductors of heat and electricity
High density

## Their chemical properties

1. They are much less reactive than the metals of group 1.
2. They show no clear trend in reactivity, unlike the metals of group 1.
3. Most transition metals form colored compounds
4. Most can form ions with different charges (they have variable valency)
5. They can form more than one compound with another element
6. Most transition metals can form complex ions

## Uses of transition metals

The hard strong transition metals are used in structure such as bridges, buildings, cars etc.
Many transition metals are used in making alloys.
Transition metals are used as conductors of heat and electricity.
Many transition metals and their compounds act as catalysts



# Page 150

Group II - the alkaline earth metals
Group II consists of the five metals beryllium, magnesium, calcium, strontium and barium, and the radioactive element radium. Magnesium and calcium are generally available for use in school.

These metals have the following physical properties:

- They are harder than those in Group I.
- Have low melting and boiling points.
- Have low densities, but not low as those in group 1.
- They are silvery-grey in colour when pure and clean.

Chemical properties

- Magnesium reacts extremely slowly with cold water, but easily with steam.
- Calcium reacts with water to produce calcium hydroxide.
- They tarnish quickly, however, when left in air due to the formation of a metal oxide on their surfaces.

Experiment 1
Aim: Heating a mixture of iron filings and sulphur.
Materials: iron filings, sulphur powder, evaporating dish, burner, burner stands
Method:

- Add equal amounts of sulphur and iron into an evaporating dish.
- Bring a magnet near the mixture and observe what happens.
- Heat the mixture and when the mixture starts to glow stop heating.
- Leave the apparatus to cool and bring a magnet to the solid after it cooled.

Observations
On the first instance, the iron filings are picked / attracted to the magnet. Iron and sulphur retained their original colours.

When heated a new substance is form which is red. The substance is not attracted to the magnet.
Iron + sulphur + heat $\rightarrow$ iron sulphide (compound).
Experiment 2
Aim: Burning magnesium ribbon.
Materials: magnesium ribbon, burner, sand paper, tongs
Method:



# Page 151

![img-128.jpeg](img-128.jpeg)

- Clean a strip of magnesium with sand paper.
- Examine and describe the physical properties of the cleaned magnesium.
- Heat the mag strip holding it with the tong until it catches fire.
- Remove it from the flame. It will continue burn for some minutes.
- Examine the new compound after the magnesium has finished burning.


# Observation 

When cleaned the magnesium strip is silver in colour. When it burns, a white brilliant dazzling flame is produced resulting in a white powder being formed (magnesium oxide).

Magnesium + oxygen $\rightarrow$ magnesium oxide.
Metals and Non- Metals
Elements are categorized into metals and non-metals.
Examples of metals include aluminium, silver, iron, tin zinc etc and non-metals are hydrogen, chlorine, carbon etc.

Heating metals in air
Other metals react when heated to form oxides; however some will not react and are said to be noble metals.

## Experiment 1:

Heating magnesium in air.
Methods: See Science Today Bk 3 Pg 92
![img-129.jpeg](img-129.jpeg)

Results

## OlmOCR Image Descriptions

### Image: img-128.jpeg

![img-128.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-128.jpeg.png)


s": [{"description": "The diagram illustrates a laboratory setup for heating a metal sample. A flame is shown at the bottom, indicating a Bunsen burner or similar heat source. Tongs are used to hold the metal sample above the flame, allowing for controlled heating. The labels 'metal', 'tongs', and 'flame' clearly indicate the components of this setup."}]}


### Image: img-129.jpeg

![img-129.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-129.jpeg.png)


s": [{"description": "The diagram illustrates a demonstration involving the use of tongs to handle a metal object near a flame. The metal is being heated by the flame, which is depicted as a bright yellow-orange color. The tongs are shown gripping the metal securely, indicating a safe and controlled method for handling hot objects."}]}





# Page 152

| element | Appearance before heating | reaction |
| :-- | :-- | :-- |
| magnesium | Shiny silver solid | Burns with a bright flame and <br> leave a white residue. |

# Conclusion 

Magnesium produces a bright flame, when hot is yellow and leave white residue.
Word equation is: Magnesium + Oxygen $\rightarrow$ magnesium oxide.

## Summary

- Potassium tarnishes in the presence of oxygen
- Sodium burns with a yellow flame
- Copper powder burns with dull red glow
- Iron powder burns with bright yellow flame
- Magnesium burns with a bright white flame to produce white solid

$$
\begin{array}{ll}
4 \mathrm{~K}(\mathrm{~s})+ & \mathrm{O}_{2}(\mathrm{~g}) \longrightarrow 2 \mathrm{~K}_{2} \mathrm{O}(\mathrm{~s}) \\
4 \mathrm{Na}(\mathrm{~s})+ & \mathrm{O}_{2}(\mathrm{~g}) \longrightarrow 2 \mathrm{Na}_{2} \mathrm{O}(\mathrm{~s}) \\
2 \mathrm{Cu}(\mathrm{~s})+ & \mathrm{O}_{2}(\mathrm{~g}) \longrightarrow 2 \mathrm{CuO}(\mathrm{~s}) \\
3 \mathrm{Fe}(\mathrm{~s})+ & 2 \mathrm{O}_{2}(\mathrm{~g}) \longrightarrow \mathrm{Fe}_{3} \mathrm{O}_{4}(\mathrm{~s}) \\
2 \mathrm{Mg}(\mathrm{~s})+ & \mathrm{O}_{2}(\mathrm{~g}) \longrightarrow 2 \mathrm{MgO}(\mathrm{~s})
\end{array}
$$

Reactions of Metals with Water
Experiment 2
Method: see Science Today Bk 3 pg93
![img-130.jpeg](img-130.jpeg)

## OlmOCR Image Descriptions

### Image: img-130.jpeg

![img-130.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-130.jpeg.png)


s": [{"description": "The diagram illustrates a setup for collecting gas. It shows a beaker filled with water and a test tube placed inside it. A funnel is used to introduce magnesium into the beaker. The gas produced by the reaction of magnesium with water collects in the test tube."}]}





# Page 153

-One of the products of the reaction with water is hydrogen gas
-hydrogen produces a pop sound with a lighted glowing splint.
-magnesium is less reactive than calcium.
Word equation: metal + water $\rightarrow$ metal oxide + hydrogen i.e. magnesium + water $\rightarrow$ magnesium oxide + hydrogen.

# Summary 

- Potassium, Sodium and Calcium reacts vigorously with cold water

$$
\begin{aligned}
& 2 \mathrm{~K}(\mathrm{~s})+2 \mathrm{H}_{2} \mathrm{O}(\mathrm{l}) \longrightarrow 2 \mathrm{KOH}(\mathrm{aq})+\mathrm{H}_{2} \mathrm{~g}) \\
& 2 \mathrm{Na}(\mathrm{~s})+2 \mathrm{H}_{2} \mathrm{O}(\mathrm{l}) \longrightarrow 2 \mathrm{NaOH}(\mathrm{aq})+\mathrm{H}_{2}(\mathrm{~g}) \\
& 2 \mathrm{Ca}(\mathrm{~s})+2 \mathrm{H}_{2} \mathrm{O}(\mathrm{l}) \longrightarrow 2 \mathrm{CaOH}(\mathrm{aq})+\mathrm{H}_{2}(\mathrm{~g})
\end{aligned}
$$

- Magnesium reacts very slowly with cold water but vigorously with steam
- Zinc do not react with cold water but reacts slowly with steam
- Iron reacts with steam but does not react with cold water. Rusting occurs very slowly in the presence of oxygen.

$$
\begin{aligned}
& \mathrm{Mg}(\mathrm{~s})+\mathrm{H}_{2} \mathrm{O}(\mathrm{~g}) \longrightarrow \mathrm{MgO}(\mathrm{~s})+\mathrm{H}_{2}(\mathrm{~g}) \\
& \mathrm{Zn}(\mathrm{~s})+4 \mathrm{H}_{2} \mathrm{O}(\mathrm{~g}) \longrightarrow \mathrm{ZnO}(\mathrm{~s})+\mathrm{H}_{2}(\mathrm{~g}) \\
& 3 \mathrm{Fe}(\mathrm{~s})+4 \mathrm{H}_{2} \mathrm{O}(\mathrm{~g}) \longrightarrow \mathrm{Fe}_{3} \mathrm{O}_{4}(\mathrm{~s})+\mathrm{H}_{2}(\mathrm{~g})
\end{aligned}
$$

- Copper have no reaction with water and steam


## Reactivity Series

- Metals can be arranged in order of their reactivity.
- The reactivity series is based on the reaction of metals with water or dilute hydrochloric acid.
- When metal reacts, the atom loses electrons to become an ion. The more readily a metal gives up electrons to form ions, the more reactive it is.

Potassium
Sodium
Calcium
Magnesium
Aluminium
Zinc
most reactive
$\downarrow$
decreasing reactivity



# Page 154

# Lead 

## Copper

least reactive
For the reactivity series, use the word MAZILC by noting the underlined letters of each element.

## Metals Reacting With Acids

When metals react with a dilute acid, hydrogen is released. The metal dissolves and disappears and a salt is also formed .e.g. metal+ acid $\rightarrow$ salt + hydrogen.

$$
\begin{aligned}
& \text { Hydrochloric acid } \rightarrow \text { chlorides. } \\
& \text { Sulphuric acid } \rightarrow \text { sulphates. }
\end{aligned}
$$

## Examples

Magnesium + hydrochloric acid $\rightarrow$ magnesium chloride + hydrogen gas.
Zinc + hydrochloric acid $\rightarrow$ zinc chloride + hydrogen gas.
*Use other metals to come up with the above equation. (8)

- Potassium and Sodium reacts explosively to with acids.
- Calcium reacts vigorously with dilute acids.
- Magnesium reacts very fast with dilute acids.
- Zinc reacts moderately with dilute acids
- Iron reacts slowly with dilute acids

| $2 \mathrm{~K}(\mathrm{~s})$ | + | $2 \mathrm{HCl}(\mathrm{aq})$ | $2 \mathrm{KCl}(\mathrm{aq})$ | + | $\mathrm{H}_{2}(\mathrm{~g})$ |
| :--: | :--: | :--: | :--: | :--: | :--: |
| $2 \mathrm{Na}(\mathrm{s})$ | + | $2 \mathrm{HCl}(\mathrm{aq})$ | $2 \mathrm{NaCl}(\mathrm{aq})$ | + | $\mathrm{H}_{2}(\mathrm{~g})$ |
| $\mathrm{Ca}(\mathrm{s})$ | + | $2 \mathrm{HCl}(\mathrm{aq})$ | $\mathrm{CaCl}_{2}$ (aq) | + | $\mathrm{H}_{2}(\mathrm{~g})$ |
| $\mathrm{Mg}(\mathrm{s})$ | + | $2 \mathrm{HCl}(\mathrm{aq})$ | $\mathrm{MgCl}_{2}$ (aq) | + | $\mathrm{H}_{2}(\mathrm{~g})$ |
| $\mathrm{Zn}(\mathrm{s})$ | + | $2 \mathrm{HCl}(\mathrm{aq})$ | $\mathrm{ZnCl}_{2}$ (aq) | + | $\mathrm{H}_{2}(\mathrm{~g})$ |
| $\mathrm{Fe}(\mathrm{s})$ | + | $2 \mathrm{HCl}(\mathrm{aq})$ | $\mathrm{FeCl}_{2}$ (aq) | + | $\mathrm{H}_{2}(\mathrm{~g})$ |

- Lead reacts with warm hydrochloric acid slowly
- Copper has no reaction with dilute hydrochloric acid


## Oxidation and Reduction

Oxidation is the addition of oxygen and removal of hydrogen. Oxygen is an oxidising agent when added to an element during combustion or burning. E.g. Carbon + oxygen $\rightarrow$ carbon- dioxide; Sulphur +oxygen $\rightarrow$ sulphur dioxide.



# Page 155

# Experiment 3 

## Reaction of Magnesium with Steam

The metal reacts to form an oxide. The oxidising agent supplies oxygen.
Materials: magnesium ribbon, hard glass, test tube, water, sand, 2 burners, cork, clamp stand, splint, glass tube.

Method
![img-131.jpeg](img-131.jpeg)

4 Set up apparatus as shown.
4 Heat damp sand and magnesium ribbon.
4 As soon as the ribbon starts to glow, place a lighted splint close to the open end of the glass tube.
4 Continue heating until reaction is complete.
Observations and results
Magnesium reacts with water (steam) releasing hydrogen.
When magnesium is heated strongly and hot steam is passed over it catches fire and burns brightly releasing heat and hot hydrogen which burns when it meets the air.

The residue is magnesium oxide (white powder in appearance)

## Equation

Magnesium +water vapour (steam) $\rightarrow$ magnesium oxide + hydrogen.
The test tube may swell and break due to high heat involved.
Conclusion
Magnesium reacts with steam to form magnesium oxide and hydrogen.

## ACIDS, SALTS AND BASES

## TITRATION

## OlmOCR Image Descriptions

### Image: img-131.jpeg

![img-131.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-131.jpeg.png)


s": [{"description": "The diagram illustrates a setup for heating a magnesium coil. The setup includes damp sand at the base to provide heat. A glass tube is connected to the coil, and there is an indication of burning gas at one end. Arrows pointing upwards suggest the flow of heat."}]}





# Page 156

- Technique used to find the concentration of acids and to make soluble salts from an acid and an alkaline e.g. finding the concentration of ethanoic acid in a sample of vinegar.


# Identify apparatus used in a titration 

- A pipette
- Phenolphthalein.
- A burette


## Describe an acid-base titration procedure

![img-132.jpeg](img-132.jpeg)

- Using a pipette, $25 \mathrm{~cm}^{3}$ of Hydrochloric acid is placed in a conical flask. A few drops of indicator e.g. Phenolphthalein are added.
- Dilute Hydrochloric acid is placed in a burette and then released into conical flask until the indicator changes colour which means all the acid has just reacted. The volume of alkali added from the burette to acid is measured.
- The experiment is now repeated. $25.0 \mathrm{~cm}^{3}$ of Hydrochloric acid is placed in a titration flask as before, but no indicator is added.
- The NaOH is placed in a burette and the same volume of this alkali is added to the flask as before.
- The flask then contains a solution of sodium chloride without excess acid or alkali.
- The sodium chloride is obtained by evaporating most of the water and crystallizing the salt.

## OlmOCR Image Descriptions

### Image: img-132.jpeg

![img-132.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-132.jpeg.png)


s": [{"description": "The diagram illustrates a chemical reaction involving the titration of sulfuric acid with sodium hydroxide solution. The process begins with a pipette containing sulfuric acid and a phenolphthalein indicator. A dropper is used to add the indicator to the sulfuric acid, which changes color due to the presence of the indicator. The next step involves using a burette filled with sodium hydroxide solution to titrate the sulfuric acid. As the sodium hydroxide is added, the pH of the solution increases, causing the phenolphthalein indicator to change color again. This process continues until the equivalence point is reached, where the amount of sodium hydroxide exactly neutralizes the sulfuric acid. The final step shows a flask containing a solution of sodium sulfate, indicating the completion of the titration reaction."}]}





# Page 157

# INDUSTRIAL PROCESSES 

Ammonia (NH3)

- It a poisonous, colourless gas that has a pungent smell.
- It burns in oxygen to produce nitrogen dioxide and water.

Manufacture of Ammonia- Haber Process
![img-133.jpeg](img-133.jpeg)

Step 1

- Nitrogen and hydrogen are scrubbed to remove impurities like carbon dioxide.
- This means washina stream of gas with an alkali to dissolve all carbon dioxide in the alkali.

Step 2

- The gas misture of 1:3 is compressed under a pressure of around 200 atmospheres.

Step 3

- The compressed gas is pumped into a converter chamber where the reaction occurs.
- The gas flows over beds of fine iron which acts as catalyst.
- Temperature of 450-500 degrees Celsius hepls the reaction on.
- The reaction is reversible. Nitrogen + hydrogen $\leftrightarrow$ ammonia. Deduce the chemical equation. (2)

Sstep 4

- Not all the mixture reacts, but only $15 \%$ is converted to ammonia.
- Ammonia is cooled so it is collected.
- Unreacted nitrogen and hydrogen are simply recycled through the converter chamber.

Step 5

- The liquid ammonia is allowed to flow into tanks and stored under pressure until use.

NB: It is not wise to increase temperature beyond 500 degrees Celsius because ammonia can decompose back to nitrogen and hydrogen.

Uses of Ammonia
\& Manufacture of fertilizers.
Nitric acid production.

## OlmOCR Image Descriptions

### Image: img-133.jpeg

![img-133.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-133.jpeg.png)


s": [{"description": "The diagram illustrates the process of synthesizing liquid ammonia. It begins with hydrogen and nitrogen gases being mixed together. The unreacted hydrogen and nitrogen are then separated from the reaction chamber. The reaction takes place in a chamber at 500°C and 200 atm, using iron filings as a catalyst."}]}





# Page 158

4 Used as refrigerant.
4 Making of dyes, drugs, explosives and fibres.
4. Water purification and drugs.

Sulphuric Acid production
The extraction of sulphur

- The frasch process is used.
- The process uses superheated water in the extraction. Superheated water is water that has been heated beyond its boiling point, but kept in the liquid phase by allowing a great pressure to it.
- The superheated water is pumped underground where it melts the sulfur but not the surrounding rocks.
- The liquid sulfur is then pumped to the ground level where it cools and sets.
![img-134.jpeg](img-134.jpeg)

Contact Process

## OlmOCR Image Descriptions

### Image: img-134.jpeg

![img-134.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-134.jpeg.png)


s": [{"description": "The diagram illustrates a process involving the extraction of sulfur from underground deposits. A mixture of water and molten sulfur is pumped into the ground through an outer pipe. The superheated water then flows down to the innermost pipe, where it reacts with the sulfur deposits. The resulting molten sulfur is collected at the bottom, while hot compressed air is used to facilitate the process."}]}





# Page 159

![img-135.jpeg](img-135.jpeg)

Stage 1
Production of sulphur-dioxide

- Sulphur is further oxidised to yield sulphur-dioxide or strongly heating sulfide ores in air.
- $\mathrm{S}+O_{2} \rightarrow \mathrm{SO}_{3}$

Stage 2
Production of sulphur-trioxide

- Sulphur-dioxide is further oxidized to produce sulphur-trioxide.
- Catalyst- vanadium (v)oxide $\left(V_{2} O_{5}\right)$ It speeds up the reaction.
- $2 \mathrm{SO}_{2}+\mathrm{O}_{2} \leftrightarrow 2 \mathrm{SO}_{3}$
- To ensure production, a temperature of 450-500 degrees Celsius, pressure of 1 atmosphere and catalyst are needed.

Question 1
Write down the word equation for production of sulphur-trioxide.(2)
Stage 3
To make oleum (Absorption)

- Sulphur-trioxide is absorbed in concentrated sulphuric acid to obtain oleum.
- Sulphur trioxide + sulphuric acid $\rightarrow$ oleum.
- $\mathrm{SO}_{3}+H_{2} \mathrm{SO}_{4} \rightarrow H_{2} S_{2} \mathrm{O}_{7}$

Stage 4
To make sulphuri acid (Dilution)

## OlmOCR Image Descriptions

### Image: img-135.jpeg

![img-135.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-135.jpeg.png)


s": [{"description": "The diagram illustrates the manufacture of sulfuric acid in industry. It is divided into three main sections labeled I, II, and III.\n\nSection I: The process begins with the reaction of sulfur (S) with dry air to produce SO₂. This mixture then enters a furnace where it undergoes further reactions.\n\nSection II: The output from the furnace contains SO₂ and O₂, which are mixed in a catalytic converter containing V₂O₅ catalyst at 450°C - 550°C. This results in the production of SO₃.\n\nSection III: The SO₃ is then dissolved in water to form concentrated sulfuric acid (H₂SO₄). The process also involves the use of H₂S₂O₇ (Oleum) and a waste gas stream."}]}





# Page 160

- Oleum is converted into twice as much concentrated sulphuric acid by adding water carefully.
- $98 \%$ concentrated sulphuric acid is obtained.
- $\mathrm{H}_{2} \mathrm{~S}_{2} \mathrm{O}_{7}+\mathrm{H}_{2} \mathrm{O} \rightarrow 2 \mathrm{H}_{2} \mathrm{~S}_{2} \mathrm{O}_{7}$
- NB: Not all sulphur dioxide is converted to sulphur trioxide in stage 2 . This unreacted gas can pollute the environment if not disposed off properly by reacting with water to form acid rain.

Question 2
State the uses of sulphuric acid. (10)

1) The acid in a car battery.
2) Making detergents.
3) Metal treatment and anodising.
4) A catalyst
5) A dehydrating agent.
6) Making fertiliser.
7) Paints and dyes.
8) Mineral processing
9) Oil refining
10) Wastewater processing
11) Paper making
12) Manufacture of plastics.
Manufacture of Nitric Acid
![img-136.jpeg](img-136.jpeg)

This is catalytic oxidation of ammonia.
Stage 1

- Ammonia reacts with oxygen to obtain nitrogen dioxide and water, platinum rhodium catalyst, temp of abt 900 degrees Celsius and pressure of 10-15 atmospheres.
- $4 \mathrm{NH}_{3}+5 \mathrm{O}_{2} \rightarrow 6 \mathrm{H}_{3}$

Stage 2

- On cooling, nitrogen monoxide is further oxidised to nitrogen dioxide.
- $2 \mathrm{NO}+\mathrm{O}_{2} \rightarrow 2 \mathrm{NO}_{2}$

Stage3

## OlmOCR Image Descriptions

### Image: img-136.jpeg

![img-136.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-136.jpeg.png)


s": [{"description": "The diagram illustrates the process of mixing gases to produce nitrogen dioxide. Ammonia and oxygen are mixed in a reaction chamber at 900°C with a platinum/rhodium catalyst. Oxygen is also involved in this process. The resulting nitrogen dioxide is then absorbed in an absorption tower using 10% nitric acid."}]}





# Page 161

- Nitrogen dioxide absorbed in water in the presence of oxygen to give nitric acid.
- Nitrogen dioxide + oxygen + water $\rightarrow$ nitric acid (dilute).
- $2 \mathrm{H}_{2} \mathrm{O}+\mathrm{HNO}_{3} \rightarrow \mathrm{NH}_{4} \mathrm{NO}_{3}$

Uses of Nitric Acid
\& Manufacture of fertilizers.
\& Manufacture of explosives.
\& Making dyes, drugs, nylon and plastics.
Manufacture of Ammonium Nitrate Fertilizer

- Nitric acid + ammonia $\rightarrow$ ammonium nitrate
- (Acid) (Base) (Salt)
- $\mathrm{NH}_{3}+\mathrm{HNO}_{3} \quad \rightarrow \mathrm{NH}_{4} \mathrm{NO}_{3}$
- The two substances combine chemically in a process called neutralisation.

Industrial Gases and Their Uses

| Gas | Source | Uses | Test |
| :-- | :-- | :-- | :-- |
| hydrogen | Electrolysis of water | Making ammonia, <br> margarine and is a fuel | Produces a pop sound |
| oxygen | Fractional distillation of <br> liquid air, electrolysis of <br> water | Sulphuric and nitric <br> acid manufacturing, <br> medical use, welding <br> and oxygen lance <br> process | Relights a glowing <br> splint |
| nitrogen | Fractional distillation of <br> air | Manufacture of <br> ammonia |  |
| ammonia | Haber process | manufacture of nitric <br> acid, fertilizers, in <br> refrigerant | Turns damp red <br> litmus paper blue |
| Carbon <br> dioxide | Fermentation of glucose, <br> fractional distillation of <br> air | Fire extinguishers, fizzy <br> drinks, refrigerants | Turns lime water <br> milky |

# OXIDATION AND REDUCTION 

Alloy is a mixture of one metal with one or more other metals and or carbon.
Alloys of iron are pig iron (cast iron), mild steel and stainless steel.
Question 1



# Page 162

State 2 properties and 2 uses of each of the above alloys of iron. (12)
Alloys of iron

# Steel 

Iron made from blast furnace is not good as:

- It contains impurities which makes it brittle (can break easily).
- It cannot be bent or stretched.
- Most iron is converted into steel which is an alloy of iron and carbon with small amounts of other elements.

Advantages of steel

- it is strong and tough.
- it can be bent and stretched without shattering


## Making Steel

- Impurities of iron is removed by blowing oxygen into molten iron to change the impurities into oxides. They are then combined with CaO and removed as slag.
- Carbon and other metals are added in certain amount to make steel.

Different Types of Steel:
Mild steel - is a low carbon steel with $0.25 \%$ carbon.

- It is strong and quite malleable. It is used for car bodies, ships, railway lines and steel rods to reinforce concrete.
Hard steel - is a high-carbon steel with about $1 \%$ carbon.
- It is harder than mild steel and less malleable. It is used to make tools

Stainless steel - is iron with large amounts of chromium and nickel.

- It is hard, shiny and doesn't rust. It is used to make cutleries, medical instrument and pipes in chemical industries.



# Page 163

# ORGANIC CHEMSTRY 

## Alcohols

- The alcohols are the family of organic compounds that contain the $\mathbf{O H}$ group.
- Are homologous series with general formula $\mathrm{CnH} 2 \mathrm{n}+1 \mathrm{OH}$
- They have -OH functional group (hydroxyl group) meaning they will all react in a similar way.
- All alcohols end with suffix -ol
- This tells you that the OH group is attached to a carbon atom at one end of the chain.
- For alcohol, the -OH is not of hydroxide ion, OH -, but is covalent bond between oxygen and hydrogen, $\mathrm{O}-\mathrm{H}$

First three members of the series

- Methanol, $\mathrm{CH}_{3} \mathrm{OH}$
- Ethanol, $\mathrm{C}_{2} \mathrm{H}_{5} \mathrm{OH}$ or $\mathrm{CH}_{3} \mathrm{CH}_{2} \mathrm{OH}$
- Propanol, $\mathrm{C}_{3} \mathrm{H}_{7} \mathrm{OH}$ or $\mathrm{CH}_{3} \mathrm{CH}_{2} \mathrm{OH}$

Ethanol, an important alcohol

- Ethanol is the alcohol in alcoholic drinks.
- It is a good solvent. It dissolves many substances that do not dissolve in water.
- It evaporates easily - it is volatile. That makes it a suitable solvent to use in glues, printing inks, perfumes, and aftershave

Making Ethanol

- Fermentation of sugars with yeast
- Reacting ethene with steam


## Fermenting glucose

- Fermentation is breakdown of sugars into smaller molecules by microorganisms.
- $\quad C_{6} H_{12} O_{6}+C 6 H_{12} O_{6}(\mathrm{aq}) \rightarrow 2 C_{2} H_{5} O H(\mathrm{aq})+2 \mathrm{CO}_{2}(\mathrm{~g})$
- Temperature is kept constant at 37 oC to prevent destruction of yeast at higher temperatures.
- Oxygen is removed by limewater and carbon dioxide is produced during fermentation.
- Alcohol is separated from solution by fractional distillation.


## Reacting Ethene with Steam

- Ethene and steam are passed over phosphoric acid $\mathrm{H}_{3} \mathrm{PO}_{4}$ (as a catalyst) under high temperature of $300^{\circ} \mathrm{C}$ and pressure of 65 atm .
- $\quad C_{2} H_{4}(\mathrm{~g})+H_{2} O(\mathrm{~g}) \rightleftharpoons C_{2} H_{5} O H(\mathrm{aq})$
- Since this is reversible reaction, both ethene and water are produced aside from ethanol. The ethanol is separated by fractional distillation.


## Uses of Alcohol

As organic solvent; alcoholic drink; preservatives; vehicle fuel
Experiment 1



# Page 164

Investigating fermentation
Apparatus: 2 test tubes, bicarbonate indicator solution, litmus paper, yeast and starch solution.
Method
$\stackrel{\text { f }}{\text { Arrange apparatus }}$ as shown below.
Note colour changes after 30 minutes.
Dip red litmus paper into the solution A, observe what happens.
Observations and Results
Brick - red bicarbonate indicator turns yellow to show presence of carbon dioxide. Thus, the gas produced during fermentation is carbon dioxide.

Red litmus paper turns to blue to show the presence of alcohol, an alkaline substance.
\# If one uses lime water, it turns to milky from clear indicating the presence of carbon dioxide.
Uses of ethanol
a. It is used as a fuel.
b. It is a solvent for organic compounds.
c. It is used in alcoholic drinks.
d. It is mixed with methanol to get methylated spirits used in laboratory.
e. It is used to produce drugs, cosmetics, detergents, plastics and lubricants.

# Global warming 

Greenhouse effect is the trapping of heat from sun by greenhouse gases to regulate Earth temperature so that not all heat is reradiated back to space.
However, increased industrialization releases more greenhouse gases to atmosphere, contributing to Global Warming (increase in temperature of Earth's atmosphere due to trapping of heat by greenhouse gases).

Examples of Greenhouse Gases are:

1. Carbon dioxide which is naturally occuring or by combustion of hydrocarbons.
2. Methane which occur naturally or emitted during production of fuels or from decaying vegetable matter.
3. Nitrous Oxide is produced by industrial and agricultural activities, and by incomplete combustion of hydrocarbons.
4. Water vapour
5. Ozone

Causes of Global Warming
State any four causes of global warming. [4 ]
Effects of Global Warming

- Loss of biodiversity.
- Desertification.
- Rising sea Levels.
- Increased tropical storms.



# Page 165

- Heat waves and forest fires
- Droughts and famines (crop failure).
- Skin cancer (diseases).
- It melts polar icebergs.
- Floods low lying areas and coastal regions,
- Alter the climatic conditions of certain places.

Tackling Global Warming

- Reduce the use of fossil fuels.
- Use alternative forms of energy such as wind, tidal and hydroelectric power.
- Use more electric vehicles.
- Reduce number of cars on road.
- Create efficient engines in cars to ensure complete hydrocarbon combustion.
- Reduce, Reuse, Recycle.
- Afforestation and Reforestation.


# PHYSICS 

## DATA PRESENTATION

Pie Charts - display proportions of multiple data.
Advantages

- Simpler to understand and interpret.
- Summarise large amount of data in visual form.

Disadvantages

- Do not show exact values of quantities.
- They do not show changes of quantities over time.
- They can not show relationships between variables.


## MEASUREMENTS

## S. I Unit for base quantities

| Quantity measured | S.I Unit | Symbol |
| :-- | :-- | :-- |
| Length | Metre | m |
| Mass | Kilogram | kg |
| Time | Second | s |
| Temperature | Kelvin | k |
| force | Newton | N |
| power | watt | w |
| Current | Ampere | a |
| Multiples of the <br> quantity | Number of moles | N |



# Page 166

Derived SI units

| Quantity measured | Formula | Symbol |
| :-- | :-- | :-- |
| Density | Mass / Volume | $\mathrm{kg} / \mathrm{m}^{3}$ |
| Area | LXW | $\mathrm{m}^{2}$ |
| Velocity | Length / time | $\mathrm{m} / \mathrm{s}$ |
| Acceleration | Velocity / time | $\mathrm{m} / \mathrm{s}^{2}$ |
| Work | Force x distance | J |
| Potential difference | Work / charge | V |

- A constant 20 N force pulls a cart over a distance of 6 m . Calculate the work done.
- Work done $=$ Force X displacement
$=20 \mathrm{~N} \times 6 \mathrm{~m}$
$=120 \mathrm{Nm}$ or 120 Joules.


# FORCE 

## Pressure in fluids

Pressure is force acting over an area.
It is the ratio of weight/force to the area supporting it.
The bigger the surface area, the smaller the forces or weight each unit area supports.
Pressure $\quad=\quad$ force $(\mathrm{N}) \quad=\mathrm{N} / \mathrm{m}^{2}=\left(\mathrm{Nm}^{2}\right)$
area $\left(\mathrm{m}^{2}\right)$

## Pressure in fluids

$>$ A fluid/liquid cannot be compressed.
$>$ Gravity pulls a liquid into a container and the liquid exerts a pressure on the other container.
Principles in pressure in fluids

- Pressure in a liquid at a certain depth acts equally in all directions.
- Pressure increases with depth because of the weight above. In the above diagram pressure at A is smaller than at B and C .



# Page 167

![img-137.jpeg](img-137.jpeg)

- Pressure increases with density. A heavier (denser) liquid e.g. mercury exerts more pressure than water of the same volume.
- Similarly if a tin with three holes is filled with water comes out with greatest force from the hole at the bottom (C).
- Dam walls are thicker at the bottom to withstand great pressure of water at the bottom.

Pressure of Liquid
![img-138.jpeg](img-138.jpeg)

Mass of liquid $=$ mass X density
$=\mathrm{A} \times \mathrm{h} \times \mathrm{p}$
Weight of liquid $=\mathrm{A} \times \mathrm{h} \mathrm{p} \times \mathrm{g}$
Pressure of liquid $=\frac{\mathrm{A} \times \mathrm{h} \times \mathrm{p} \times \mathrm{g}}{\mathrm{A}}$
$\mathbf{P}=\mathbf{h p g}$ where;
$\mathbf{h}=$ height of the liquid
$\mathbf{g}=$ force of gravity
$\mathbf{p}=$ density of liquid.
-We use a manometer to measure pressure.
-It is a U-tube filled with liquid e.g. water or mercury.
-When both arms are open to atmosphere pressure, the levels of the liquid is the same.

# A manometer 

![img-139.jpeg](img-139.jpeg)

Combined Science Notes 2018
$167 \mid$ Page

## OlmOCR Image Descriptions

### Image: img-137.jpeg

![img-137.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-137.jpeg.png)


s": [{"description": "The diagram illustrates a container filled with blue liquid. Three pipes labeled A, B, and C are connected to the container. Pipe A is directed towards the top right corner of the container, while Pipe B is angled slightly downward towards the bottom right corner. Pipe C is curved and directed towards the bottom left corner of the container."}]}


### Image: img-138.jpeg

![img-138.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-138.jpeg.png)


s": [{"description": "The diagram illustrates a cylinder with its base area labeled as A. The height of the cylinder is denoted by h. The shaded region represents the lateral surface area of the cylinder."}]}


### Image: img-139.jpeg

![img-139.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-139.jpeg.png)


s": [{"description": "The diagram illustrates the concept of pressure using a U-shaped manometer. The leftmost section shows a vacuum with atmospheric pressure on both sides, causing no liquid displacement. The middle section depicts atmospheric pressure on both sides as well, but there is no gas exerting any additional pressure, so the liquid remains at rest. The rightmost section illustrates a gas exerting a pressure greater than atmospheric pressure, causing the liquid to rise in the open arm of the manometer."}]}





# Page 168

$>$ Gas/liquid pressure can be measured using a manometer.
$>$ It is a U-tube partly filled with a liquid such as mercury or water.
$>$ When both arms are open to atmospheric pressure the levels of the liquid are the same in both arms.
$>$ However, if one arm is connected to a gas supply the levels change.
$>$ The liquid in the left arm is forced downwards by the gas pressure.
$>$ The pressure of the gas is then balanced by atmospheric pressure plus the column of liquid with height h .
$>$ The pressure of the gas is equal to the atmospheric pressure at the time of measurement plus the pressure of the water in column $h$.

# Summary 

Pressure of gas $=$ atmosphere $+(\mathrm{h})$
$\begin{array}{ll}\text { Where } & \mathrm{p}=\text { pressure } \\ & \mathrm{P}=\text { atmospheric pressure } \\ \text { Pressure }=\mathrm{P}+\mathrm{pgh} & \mathrm{P}(\text { rho })=\text { density } \\ & \mathrm{g}=\text { gravity } \\ & \mathrm{h}=\text { height difference in pressure }\end{array}$
level .

## Pumps

-Pumps are used to lift liquids and gases using atmospheric pressure.
Types of pumps
Lift pump
![img-140.jpeg](img-140.jpeg)

## OlmOCR Image Descriptions

### Image: img-140.jpeg

![img-140.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-140.jpeg.png)


s": [{"description": "The diagram illustrates the operation of a common pump. It consists of two main parts: (a) Downstroke and (b) Upstroke.\n\nIn part (a), labeled 'Downstroke', the piston moves downward, creating a vacuum inside the cylinder. This vacuum draws water from the reservoir through the intake valve at point A. The atmospheric pressure pushes the water into the cylinder, filling it with water.\n\nIn part (b), labeled 'Upstroke', the piston moves upward, forcing the water out of the cylinder through the outlet valve at point B. The water is then expelled into the system or reservoir above the water level."}]}





# Page 169

- Has two valves. One valve is the position, the other near the base of the cylinder. When one valve is open, the other is closed. The pump is primed (filled with water) first before it can be used so as to prevent air leaking past it.
Upstroke
-Is when piston moves upwards valve A (in the piston) is closed and pressure in the cylinder fall.
-Atmospheric pressure then pushes water up the pipe through valve which is at the bottom which would have open. Water above the piston is forced out of the water spout.
Down stroke
-Piston moves downwards. Valve B closed due to pressure of water on it and valve A open allowing water to pas upwards into the cylinder above the piston.

Disadvantages of a lift pump.
-Needs priming before use (laborious)
-It only delivers water on the upstroke also making it laborious.
-Only raise water through height of 9 meters.

# 2. Force pump 

-They force water to more than 10 metres
-They do not need priming before use.
Upstroke
-Piston moves up, the outlet valve closes.
-Pressure in the barrel decreases
-Inlet valve opens and water enters the barrel
![img-141.jpeg](img-141.jpeg)

Down stroke
$>$ Piston moves down and inlet valve closes.
$>$ Outlet valve opens forcing water into the reservoir and out at the spout.
$>$ Water flows continuously from the spout because of the pressure of air in the reservoir.

## OlmOCR Image Descriptions

### Image: img-141.jpeg

![img-141.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-141.jpeg.png)


s": [{"description": "Fig. 11.3. The Force pump\n\n(a) Upstroke: During the upstroke, atmospheric pressure is applied to the water in the cylinder (A). This causes the piston (B) to move upwards, forcing water out of the outlet pipe (C).\n\n(b) Downstroke: During the downstroke, compressed air is introduced into the cylinder (A), pushing the piston (B) downwards. This action draws water from the lower reservoir through the inlet pipe (P). The water level in the lower reservoir is indicated by arrows pointing downwards."}]}





# Page 170

3. Blair pump
-It is a combination of a force and a lift pump.
-It is used in a covered well.
-It lifts water to a height of about of 10 meters.
-It gives a steady supply of water for small communities.

- It has got a handle connected to a piston which moves in a cylinder that is fixed below the water level in a well.
-It has two valves which both open only upwards.
Up stroke
Piston moves up; atmospheric pressure of water in the well pushes water against valve 1 (foot valve), which opens and water enters the cylinder. Piston valve will be closed.

Down stroke
Piston moves down, valve 1 (foot valve) closes pressure of water in cylinder forces valve 2(piston valve) to open and water enters the handle and flows out of the spout.
![img-142.jpeg](img-142.jpeg)

Advantages

- The Blair pump is made of plastic making it light, cheap and easy to assemble, operate and repair.
- No lubricating oil or grease is used (water is colourless and odourless).

Bicycle pump
-Air is compressed in the cylinder by the piston which is fitted with leather or rubber washer to give an air tight fit. When piston is pushed inwards, the air in the cylinder is forced through the rubber valve in the rubber tube. This prevents air from escaping.

## OlmOCR Image Descriptions

### Image: img-142.jpeg

![img-142.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-142.jpeg.png)


s":"The diagram illustrates the operation of a hand pump. On the left side, labeled 'Upstroke', the handle is shown in an upward position. The piston valve is closed, and water enters the footvalve. The footvalve remains open during this stroke.\n\nOn the right side, labeled 'Downstroke', the handle is shown in a downward position. Water is delivered from the spout as the piston valve opens. The footvalve closes during this stroke."}





# Page 171

![img-143.jpeg](img-143.jpeg)

# Withdrew piston 

-Rubber washer move away from the barrel
-Air pressure at front of barrel reduces and air moves from the back barrel.

## Pushing piston

-Washer moves back to the walk of the barrel. Air in front is compressed and tyre is forced to open. Air enters the tyre.
Fluid systems
Works on the principle that;
4 Liquids transmit equally in all directions.
4 Liquids cannot be exposed or compressed.
Examples of fluid systems includes:
The siphon

- is a tube used to empty liquid from a tank that is not fitted with an outlet.
-When outlet Q is open, pressure inside the tube will be greater than outside.
-Liquid in the tube will flow out. This reduces the pressure in the tube to air pressure on the surface at P which pushes more liquid.
-The tube must be full of water and one end of the tube must be below level of liquid in the tank.
-The liquid to be siphoned should be at a higher level than where it is being taken.
![img-144.jpeg](img-144.jpeg)
-A fountain of water is produced because pressure of water at P is higher than at Q .
-The higher pressure causes water to come at the mouth of the tube.

## OlmOCR Image Descriptions

### Image: img-143.jpeg

![img-143.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-143.jpeg.png)


s": [{"description": "The diagram illustrates a bicycle tire inflation system. It shows the barrel of the pump connected to the plastic cup-shaped washer, which is secured by a piston. The pump is attached to the tire valve via a hose."}]}


### Image: img-144.jpeg

![img-144.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-144.jpeg.png)


s": [{"description": "The diagram illustrates the components of a siphon. The source container is labeled as End P and is connected to the receptacle container through a tube. The outlet end (Q) of the tube must fill up first for the siphon to function properly. The diagram also includes labels such as L, M, and h to indicate different parts of the siphon."}]}





# Page 172

# Hydraulic breaks 

Car breaking system
![img-145.jpeg](img-145.jpeg)
-Pressure of foot on the brake pedal causes the piston in master cylinder to exert pressure on the brake fluid.
-The pressure is passed on equally to the piston in the wheel cylinders
-This pressure forces the brake pads against the brake drums.
NB: Air bubbles must not be found in the brake fluid as air is compressible and thus reducing the effort of the braking system. The principles used in hydraulic systems are that liquids cannot be compressed and an applied pressure is transmitted.

Hydraulic jack
These are used to lift cars.
![img-146.jpeg](img-146.jpeg)

To work the hydraulic jack :-
These use the facts that-;

- Liquids cannot be squeezed.
- Liquids pass on pressure applied to them.
- Effort is exerted to push down the small piston.
- Pressure is transmitted through the liquid and acts on the large piston
- The large piston is lifted up a small amount, compared with how far the small piston has been moved down. Force is applied at Area 2 to lift a load at 1 . The pressure exerted at piston 2 is

## OlmOCR Image Descriptions

### Image: img-145.jpeg

![img-145.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-145.jpeg.png)


s": [{"description": "The diagram illustrates a cross-sectional view of a braking system. It shows the relationship between various components such as the brake pedal, master cylinder, pistons, brake fluid, and brake drum. The brake pedal is connected to the master cylinder by a hydraulic line, which transmits pressure to the pistons inside the brake caliper. The pistons then apply force to the brake pads, which press against the brake drum to slow or stop the vehicle."}]}


### Image: img-146.jpeg

![img-146.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-146.jpeg.png)


s": [{"description": "The diagram represents a hydraulic system. It consists of two main components: the load and the oil reservoir. The load is connected to the oil reservoir through a piston mechanism. The effort is applied on one side of the piston, while the other side is exposed to the pressure from the oil. The piston moves up or down depending on the force applied. The diagram includes labels such as 'load', 'oil', and 'effort' to indicate the different parts of the system."}]}





# Page 173

transmitted equally to the larger piston 1 which is carrying the load. Piston 1 moves up raising the load.

Formular: Force $=$ Force
Area Area
For example;
If a downward force of 20 N act on small piston (piston 2 ) of area 10 cm 2 . The pressure applied to liquid would be -
Pressure $=$ Force $=\frac{20 \mathrm{~N}}{\text { Area }} \quad 10 \mathrm{~cm} 2=2 \mathrm{~N} / \mathrm{cm} 2$
The pressure is passed through the liquid and acts on the large piston (piston 1) of Area 100cm2.
Upward force on piston 1 would be -:

$$
\text { Pressure } \underset{\text { Area }}{=} \underset{\text { Area }}{=} 2 \mathrm{pa} \times 100 \mathrm{~cm} 2=200 \mathrm{~N}
$$

NB: Thus a load of 200 N can be raised by an effort of 20 N .
NB: In machines such as hydraulic brakes and hydraulic jacks, work input equals work output, ignoring energy losses.

1. M.A $=\frac{\text { Load }}{\text { Effort }}$
2. V.R = Ratios of Areas i.e $\underline{100 \mathrm{~cm} 2}$ (load area) $10 \mathrm{~cm} 2$ (effort area)
3. EFFICIENCY $=\frac{\text { M.A }}{\text { V.R }} \quad \mathrm{X} \quad 100 \%$



# Page 174

# ENERGY 

## Solar Cooker

The surface of the solar cooker is shiny so as to reflect heat as possible. The sun`s rays are reflected by the curved surface and come to a focus at the pressure cooker. The solar cooker uses a renewable source of energy. It is fast to cook food with a pressure cooker. The method is environmental friendly and is easy to use once installation done.
![img-147.jpeg](img-147.jpeg)

The Solar Water Heater
![img-148.jpeg](img-148.jpeg)
$\checkmark$ Solar water heating system is mounted on roof of building so as to energy from the sun to be used to produce warm water.
$\checkmark$ The solar panel is painted black to absorb radiant heat.
$\checkmark$ Cold water is pumped into a tank or from a tap system.
$\checkmark$ The water is taken from a tank through copper tubes.
$\checkmark$ These thin copper tubes pass through the solar panel and the heat absorbed by the solar panel is quickly absorbed by the passing water at B where there is Copper Plate.
$\checkmark$ The heated water moves to a storage tank through the copper tubes.
A vacuum or Thermos flask
$\checkmark$ Keeps hot liquids hot or cold liquids cold.
$\checkmark$ It is very difficult for heat to travel into or out of the flask.
$\checkmark$ Transfer by conduction and convection is minimised by making the flask a double-walled glass vessel with a vacuum between the walls (Figure 24.4).
$\checkmark$ Radiation is reduced by silvering both walls on the vacuum side.
$\checkmark$ Then if, for example, a hot liquid is stored, the small amount of radiation from the hot inside wall is reflected back across the vacuum by the silvering on the outer wall.
$\checkmark$ The slight heat loss that does occur is by conduction up the thin glass walls and through the stopper.

## OlmOCR Image Descriptions

### Image: img-147.jpeg

![img-147.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-147.jpeg.png)


s": [{"description": "The diagram illustrates a solar still apparatus. It consists of a curved reflecting surface that is supported by a stand. At the center of the reflecting surface, there is a black pot. The black pot is designed to absorb heat efficiently from the sun, allowing water to be boiled and condensed into fresh water."}]}


### Image: img-148.jpeg

![img-148.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-148.jpeg.png)


s":"The diagram illustrates a solar water heating system. It consists of several components:\n\n- A blackened copper plate (B) which is likely the solar collector.\n- A storage tank (C), which is insulated to maintain water temperature.\n- A float in the storage tank (A) that controls the flow of water.\n- Thin copper tubings connecting the components, indicating the path of water flow.\n- A pump at the top right, suggesting it's used to circulate water through the system.\n\nThe diagram shows a simple flow process where solar energy heats the water in the collector, which then flows into the storage tank. The float mechanism ensures that the water level is maintained."}





# Page 175

![img-149.jpeg](img-149.jpeg)

Figure 24.4 A vacuum flask

## OlmOCR Image Descriptions

### Image: img-149.jpeg

![img-149.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-149.jpeg.png)


s": [{"description": "Figure 24.4 A vacuum flask\n\nThe diagram illustrates a vacuum flask, which consists of several key components:\n\n- **Stopper**: Located at the top of the flask, it seals the opening to prevent heat loss.\n- **Double-walled glass vessel**: The main body of the flask is made of two glass walls separated by a vacuum space. This design helps in maintaining the temperature of the contents for an extended period.\n- **Silvered surfaces**: The inner and outer surfaces of the double-walled vessel are silvered to reflect heat, further enhancing its insulation properties.\n- **Case**: Surrounding the double-walled vessel is a protective case that provides additional insulation and protection.\n- **Vacuum felt pad**: At the base of the flask, a vacuum felt pad helps in maintaining the vacuum between the walls, ensuring efficient thermal insulation."}]}





# Page 176

# TELECOMMUNICATION 

Define the term (2).

## Sound transmission

- Sound waves are longitudinal waveswhich are transmitted when particles of a medium vibrate back and forth in the same direction as the direction of movement of wave.
- For example, when a loud speaker vibrates outwards, it brings air particles closer to each other forming a compression.
- When it vibrates inwards, it pulls air particles apart to form a rarefaction.
- A series of compression and rarefactions move sound forwards but particles of the medium only moves forward and backwards and thus why sound needs a medium to be propagated.
![img-150.jpeg](img-150.jpeg)

Characteristics of sound

1. The wave length (L) - is the distance from the start of one compression to the start of the next compression. It can be measured from the centre of one rarefaction to the centre of the next rarefaction.
2. Frequency (f) - is the rate at which complete wave lengths pass a given point in one second and is measured hertz $(\mathrm{Hz})$. Humans can only hear sounds of frequencies between 20 Hz and 20 kHz . Thus the audible range of frequency.
3. Amplitudes of a sound wave (a) - the maximum distance that particles move from their rest posisions. As amplitude increases, particles move further from their posisions hence sound increases loudness as more sound energy is produced.
4. The velocity (v) - the distance per unit time that a wave-front travels in one second. Sound travels faster in solids that liquids. and slowest in gases.
5. The pitch of a sound - is a measure of how high or low a note is. A sound of high pitch has high frequency and vice versa.

## How a telephone works

Three important steps are:
$>$ When you speak into the mouthpiece, your voice makes a diaphragm in the microphone inside vibrate. Sound energy is converted to electrical energy.
$>$ The electrical energy travels from the phone, through exchanges, to another phone. These exchanges are computer terminals that make electrical connections between the transmitting and receiving phone.

## OlmOCR Image Descriptions

### Image: img-150.jpeg

![img-150.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-150.jpeg.png)


s": [{"description": "The diagram illustrates the movement of molecules in relation to rarefactions and compressions. On the left side, a tuning fork is shown with arrows indicating the direction of molecule movement. Above this, there are two sets of vertical lines representing rarefactions and compressions. The rarefaction line shows a decrease in density, while the compression line shows an increase in density. To the right, another set of lines indicates the direction of propagation of the wave."}]}





# Page 177

> A diaphragm in the loudspeaker inside the earpiece of a receiving phone converts incoming electrical energy back into sound energy.
Thus, making a telephone call, is all about converting sound to electrical energy, the electrical energy is carried down a very long wire and finally electrical energy is turned back in sound.

# The cellphone 

$>$ A microchip inside a cellphone takes vibrations of your voice into a tiny microphone and turns it to springs of numbers that are transmitted as radio waves by means of the phone`s antenna of the phone to the nearest mast.
$>$ The mast works as the antenna in the phone, transmitting the radio waves across the next phone mast and the next, until it reaches the one closest to the person you are calling.
$>$ From that mast it is transmitted to the person`s phone wher the encoded digital message is decoded back into electrical pulses that get the speaker of the receiver vibrating to produce sound waves.

## Email

> The internet converts information into a string of numbers and transmitting these through a combination of radio waves through antennas, electrical pulse through phone lines and pulses of lights thriough fibre optics.
$>$ The computer chips in the computer breaks up information into smaller, addressed pieces called "packets".

## Telecommunication Signals

$>$ Two types are analogue and digital.
Analogue

- Is made up of continuous wave that varies over time.
- The signal varies in amplitude and frequency and takes many values.
- The wave contains the message that is being transmitted.

Digital

- Is an electrical signal that has been chopped into bits. They look like square waves of different sizes.
- The bits are in the form of pulses that can take two values, either a 1 or 0 . Therefore, a digital signal is made up of a series of ones and zeros, either "on" (1) or " off" (0).



# Page 178

![img-151.jpeg](img-151.jpeg)

# Media for signal transmission 

- Modern communication includes radio, television, fixed line phones, cell phones and other hybrid forms. There is need to transmit signals in all these systems.
- Signals carry messages and are transmitted through guided and wireless media.


## Guided media

- In guided media, transmission is restricted within boundries of a cable. 1. Twisted cables, sheathed pair cables, 2. coaxial and 3. optical fibre.
Signal transmission in cables
- The twisted, braided and coaxial cables have copper wire through which electrical signal travels.
- The optic fibre has a thin glass threads through which light travels carrying signals with out leaving the glass cable until it reaches its destination.

Twisted Pair Cable

- Most common form of wiring in data communication.
- It consists of two identical wires wrapped together in a double helix.
- A special type of twisted pair cable known as CAT5 or CAT6 is mostly used in a specific type of LAN namely Ethernet, hence it is also known as Ethernet cable.

## OlmOCR Image Descriptions

### Image: img-151.jpeg

![img-151.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-151.jpeg.png)


s": [{"description": "The diagram illustrates the difference between an analogue signal and a digital signal. The upper part of the diagram shows an analogue signal with a continuous wave pattern that varies smoothly over time. This type of signal is characterized by its ability to represent any value within a given range continuously.\n\nIn contrast, the lower part of the diagram depicts a digital signal, which consists of discrete steps or levels. Digital signals are represented by a series of pulses, each indicating a specific state (e.g., high or low). This type of signal is used in digital electronics and computing because it can be easily processed by electronic devices."}]}





# Page 179

![img-152.jpeg](img-152.jpeg)

# Why the wires are twisted in TWISTED PAIR CABLE? 

- The twisting of wires reduces Crosstalk. The bleeding of a signal from one wire to another and which can corrupt signal and cause network errors. This form of signal interference is called Crosstalk.

Advantages

1. It has low weight.
2. It is very inexpensive.
3. It is easy to install and maintain.

## Disadvantages

1. Because of high attenuation (weakening of signal), it is incapable carrying a signal over long distances without the use of repeaters.
2. It has low bandwidth (data carrying capacity) capabilities

## Coaxial cable

- This type of cable consists of a solid wire core surrounded by one or more wire shields, each separated by some kind of plastic insulator. The inner core carries of the cable carries the signal.
- This cable has high electrical properties and is suitable for high speed communication. It is widely used for television signals.
![img-153.jpeg](img-153.jpeg)

Advantages

1. It provides higher bandwidths as compared to twisted pair cable.
2. The data transmission characteristics of coaxial cables are considerably better than those of twisted pair cables.
3. The coaxial cables can be used for broadband transmission.

## Disadvantages

1. Expensive compared to twister pair cables.
2. The coaxial cables are not compatible with twisted pair cables.

## OlmOCR Image Descriptions

### Image: img-152.jpeg

![img-152.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-152.jpeg.png)


s": [{"description": "The image on the left shows a close-up of a multi-colored cable. The cable is sheathed in gray PVC and consists of several individual wires twisted together. The colors visible are green, orange, blue, and brown.\n\nOn the right side of the image, there is a diagram illustrating the internal structure of the cable. The diagram labels three main components: PVC Jacket, Foil, and Copper Wire. The PVC Jacket encases the entire cable, providing protection. Inside, there is a layer of foil that likely serves as an electrical shield or conductor. The Copper Wire is shown running through the center, indicating its role in transmitting electrical signals."}]}


### Image: img-153.jpeg

![img-153.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-153.jpeg.png)


s": [{"description": "The diagram illustrates a cross-sectional view of an electrical cable. The copper wire is the innermost layer, surrounded by insulation material. Over the insulation, there is a copper mesh for added protection and conductivity. The outermost layer is labeled as outside insulation."}]}





# Page 180

Optical fibers

- It consist of thin strands of glass which are used to carry light from a source at one end of the fiber to a detector at the other end. The bandwidth of this medium is very high.
![img-154.jpeg](img-154.jpeg)

The fiber cable consists of three pieces:

1. Core : the glass strand through which the light travels.
2. Cladding : which is a covering of the core that reflects light back to the core.
3. Protective coating : which protects the fiber cable from hostile environment.
![img-155.jpeg](img-155.jpeg)

Advantages

1. It is immune to electrical and magnetic interference i.e., noise in any form because the information is travelling on a modulated light beam.
2. It guarantees secure transmission and has a very high transmission capacity.
3. It is highly suitable for harsh industrial environments.

Disadvantages

1. Optical fibers are quite fragile and may need special care in installation.
2. Because of noise immunity, optical fibers are virtually impossible to tap.
3. They are the most expensive of all the cables.

# Unguided media / Wireless media 

1. Microwave 2. Radio wave 3. Satellite 4. Infrared 5. Laser 6. Bluetooth

## OlmOCR Image Descriptions

### Image: img-154.jpeg

![img-154.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-154.jpeg.png)


s": ["The image depicts a cross-sectional view of an optical fiber cable. The outer layer is metallic and appears to be sheathed in a protective material. Inside the cable, there are multiple colored fibers, each surrounded by its own protective coating. Blue light rays are emanating from these fibers, indicating the transmission of data through the fiber optic technology. This diagram illustrates the internal structure of an optical fiber cable, highlighting the importance of such cables in high-speed internet and communication systems."}]


### Image: img-155.jpeg

![img-155.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-155.jpeg.png)


s": ["The diagram illustrates an optical fiber, which is a component used in telecommunications to transmit data over long distances. The core of the fiber is depicted as a yellow section surrounded by the cladding, which is shown in orange. The plastic coating, represented in blue, encases the cladding and protects the fiber from physical damage. A light ray enters the core at one end and travels through it due to total internal reflection, allowing for efficient data transmission."]}





# Page 181

# Microwave 

- Microwave signals are wireless transmission media and are used for long distance transmission. The microwave transmission consists of a transmitter, receiver and the atmosphere.
- In microwave communication, parabolic antennas are mounted on towers to send a beam to other antennas tens of kilometers away. The higher the tower, the greater the range. With a 100-meter high tower, distances of 100 km between towers are feasible.
- The microwave transmission is line of sight transmission.
![img-156.jpeg](img-156.jpeg)


## Advantages

1. This transmission media proves cheaper than digging trenches for laying cables.
2. It offers ease of communication over difficult terrain.

## Disadvantges

1. Microwave communication is an insecure communication.
2. Microwave signals is susceptible to weather effects like rains, thunderstorms etc.

Radio wave

- This transmission media make use of radio frequencies. In this transmission continuous sine waves are used to transmit information.
- Transmission through radio wave consist two parts : (i) transmitter (ii) receiver.
- The transmitter takes some sort of message (it could be the sound of someone's voice, pictures for a TV set etc.), encodes/change it onto a sine wave and transmits it with radio waves. The receiver receives the radio waves and decodes the message from the sine wave it receives. Both the transmitter and receiver use antennas to radiate and capture the radio signal.
![img-157.jpeg](img-157.jpeg)

## OlmOCR Image Descriptions

### Image: img-156.jpeg

![img-156.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-156.jpeg.png)


s": [{"description": "The diagram illustrates a line-of-sight communication system between two stations. The transmitting station is located on the left side of the image and the receiving station is on the right. A transmitting antenna is shown at the top of the transmitting station, while a receiving antenna is depicted at the top of the receiving station. The line-of-sight path connects these antennas directly, indicating that the signal transmission occurs in a straight line without any obstructions."}]}


### Image: img-157.jpeg

![img-157.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-157.jpeg.png)


s": [{"description": "The diagram illustrates the process of radio communication. It shows a transmitter and a receiver connected by a radio wave. The transmitter is on the left side with an antenna labeled 'Transmitter' and the receiver is on the right side with an antenna labeled 'Receiver'. A wavy line represents the radio wave that travels from the transmitter to the receiver. Below the wave, there is a label 'Tuning frequency' indicating the frequency at which the radio wave is tuned."}]}





# Page 182

Advantages

1. This transmission media proves cheaper than digging trenches for laying cables.
2. It offers ease of communication over difficult terrain.

## Disadvantages

1. Radio wave communication is an insecure communication.
2. Radio wave signals is susceptible to weather effects like rains, thunderstorms etc.

# Satellite 

- Satellite communication is special case of microwave relay system. It satellite communication the earth station consists of a satellite dish that functions as an antenna and communication equipment to transmit and receive data from satellites passing overhead.
- The satellites accept data/signals transmitted from an earth station, amplify them, and retransmit them to another earth station.
![img-158.jpeg](img-158.jpeg)


## Infrared

- This type of transmission uses infrared light to send data. TV remotes, automatic garage doors, wireless speakers etc., all make use of infrared as transmission media.
- The infrared light transmits data through the air and can propagate throughout a room, but will not penetrate walls.


## Advantages

1. The area coverage through satellite transmission is quite large.
2. The laying and maintenance of intercontinental cable is difficult and expensive and this is where the
satellite proves to be the best alternative.
Disadvantages
3. The costs associated with satellites are significantly high.
![img-159.jpeg](img-159.jpeg)

Laser

- The laser transmission requires direct line of sight. It is unidirectional like microwave, but has much higher speed than microwaves.

## OlmOCR Image Descriptions

### Image: img-158.jpeg

![img-158.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-158.jpeg.png)


s": [{"description": "The diagram illustrates a communication system involving a satellite and an Atlantic cable. The satellite is in a geostationary orbit above the Earth's surface. Two ground stations are depicted: one in the USA and another in Europe. Arrows indicate the direction of data transmission between these stations and the satellite. The uplink arrow points from the USA ground station to the satellite, while the downlink arrow points from the satellite to the European ground station. The Atlantic cable connects the two ground stations, facilitating communication."}]}


### Image: img-159.jpeg

![img-159.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-159.jpeg.png)


s": ["The diagram illustrates the interaction between a remote control and a television. The remote control is shown emitting infrared light towards the TV. The TV screen displays an image, indicating that it is receiving the signal from the remote control. The diagram includes labels such as \"Infrared Link\" and \"remote control,\" highlighting the key components involved in this process."}]





# Page 183

# Bluetooth 

- Bluetooth is a telecommunication industry specification that describes how mobile phones and computers can be easily interconnected using a short range wireless connection.
- The maximum range of connection is 10 meters. Data can be exchanged at a rate of 1 megabit per second.
![img-160.jpeg](img-160.jpeg)

Communicating by cell phone

- When communicating by cell phone, signal is travelling through unguided media.
- At first, its analogue, the cell phone digitalises it before sending it off to mast.
- The signal is converted back to analogue by another cell phone and into sound waves for the other person to hear.
- Signals arrive within a fraction of a second despite the large distance between the two.
![img-161.jpeg](img-161.jpeg)

## OlmOCR Image Descriptions

### Image: img-160.jpeg

![img-160.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-160.jpeg.png)


s": ["The diagram illustrates the concept of Bluetooth technology. It features a mobile phone on the left side connected to a laptop on the right side by an orange arrow, symbolizing data transfer or connectivity via Bluetooth. The central element is the blue and white Bluetooth logo, emphasizing the theme of wireless communication between devices."]}


### Image: img-161.jpeg

![img-161.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-161.jpeg.png)


s": [{"description": "The diagram illustrates the process of communication through various technologies. At the top, a person is shown talking, indicating an analogue signal. Below, there is a cellphone labeled 'digital,' suggesting digital transmission. Further down, a satellite is depicted with the label 'digital,' indicating satellite communication. At the bottom, an ear is shown receiving an analogue signal."}]}





# Page 184

Communicating by telephone
![img-162.jpeg](img-162.jpeg)

## Magnetism and electrictiy

## The generation of electricity

- Electricity is also produced in power stations using generators.
- Their names are derived from the source of energy used.
- In power stations, the turbine connected to the generator is driven by the movement of either water or wind, steam etc.
Thermal Power
- Fuel such as coal, oil and natural gas can be used to heat water in huge boilers to produce steam. Chemical energy $\rightarrow$ Heat energy $\rightarrow$ Kinetic $\rightarrow$ Electrical energy.
- The steam at high pressure turns turbines.
- Turbines turn generators to produce electricity.
- E.g. Hwange and Munyati power station. Advantages

1. Energy production using coal can be increased or decreased according to demand
2. The technology to burn coal to generate electricity already exists

- There are wires all the way from the start to the end.
- The signal is analogue from talker to listener.
- Signal travels by electrical pulses through copper wires, or by light through optic cables ( Guided media).
- Signal boosters or amplifiers are needed along the way so that cables do not lose energy.
- Hence signal speed is fast.


## Disadvantages

1. Coal is finite so will eventually run out.
2. Many existing reserves are becoming harder to extract or are in environmentally sensitive areas.
3. Fossils releases large amounts of greenhouses gases when burnt.
4. Mining deep underground fossils is very dangerous.
5. Coal is very bulky and expensive to transport around the world.

## Solar Power

- Photovoltic cells use sunlight to produce electrons between two films of silicon.
- The electron flow can be channelled in order to complete an electrical current.
Advantages

1. It is a clean form of energy.
2. It is an infinite resource.

## OlmOCR Image Descriptions

### Image: img-162.jpeg

![img-162.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-162.jpeg.png)


s": [{"description": "The diagram illustrates the process of voice communication through a copper cable. It begins with a person talking into a phone, which is connected to a copper cable. The signal travels along the cable and reaches another phone, where it is converted back into an analogue electrical signal for hearing."}]}





# Page 185

3. Panels can be used locally e.g. on top of someone`s house.
4. It can be used to heat water and generate electricity.

## Disadvantages

1. It is expensive to make solar panels.
2. The sun does not shine all the time.
3. Not every country gets adequate levels of sun.
4. They can't be used at night.
5. It is hard store surplus energy.
6. Supply does not always equal demand.

## Wind Power

- Using the energy of the wind to drive a turbine to generate electricity.
Advantages

1. It is a clean form of energy.
2. It is an infinite resource.
3. It can be used on a local scale e.g. in your back garden.
4. Technology is proven.
5. They can be placed at sea or on mountains away from settlements

Disadvantages

1. Visual pollution.
2. Noise pollution.
3. Wind is unreliable.
4. They are expensive to install, especially offshore.
5. It is hard to store surplus energy.
6. They have to be turned off in very strong winds.

HEP (Hydroelectric power)

- Using the energy of falling water in rivers to drive generators.
- Potential energy $\rightarrow$ Kinetic energy $\rightarrow$ Electrical energy.
- Kinetic energy is converted into electrical by a.c generator.

Hydro - electric power generation at Kariba

- Water leaves the lake (head of water) at high pressure and goes through the penstocks ( concrete and steel pipes).
- The larger the depth of water, the more the pressure hence high electricity generation.
- High speed water hits cups of turbines.
- Turbines start spinning and rotating.
- They in turn generators to which they are attached with pistons.
- Generators produce electricity.
- The water passes through surge chambers and return back to the river through trailrail pipes.
- Electricity is transmitted to huge transformer which regulates the power .
- Electricity is transmitted through cables to homes for use.



# Page 186

![img-163.jpeg](img-163.jpeg)

Advantages

1. It is a clean form of energy
2. It is finite as long as rivers are managed properly.
3. The built dam can also prevent flooding.
4. The reservoir behind the dam can be a store of water.

Disadvantages

1. Only a limited number of suitable rivers.
2. Can hamper navigation up and down river.
3. Reservoirs may force resettlement.
4. Migration patterns of animals may be disrupted.
5. Dams can flood large areas of land.

# Electricity 

Electricity Transmission

- The system of power stations and transmission lines is called the national electricity grid.
- The alternating current (A.C) produced by huge A.C generators at Hwange and Kariba is stepped up by transformers.
- The electricity is transmitted as alternating current (A.C) of up to 500 KV (500 000 volts).
- Substations then transform (step down), the high voltage to 230 volts for domestic use.
- $15 \%$ ofelectrical energy is lost in the transmission process.


## Electrical Hazards

$>$ Damaged insulation.
$>$ Overheating cables.
$>$ Damp conditions.
Safety components in homes

- Circuit breaker- an electric switch that interrupts current flow.
- Fuse- a component from a metal with a low melting point that melts when strong current flows over. This prevents overheating and damage of wiring and appliances.
- Earth leakages- will break the current if anything connects the current with the earth.
- Switches -are placed on the live wire of a circuit so as to break the circuit when current is not required.

## OlmOCR Image Descriptions

### Image: img-163.jpeg

![img-163.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-163.jpeg.png)


s": [{"description": "The diagram illustrates a hydroelectric power station. It begins with a reservoir that feeds into a dam, which controls the water flow. The water then passes through an intake control gate and enters the penstock turbine. The generated energy is transferred to the powerhouse where it powers the transformer. From there, the electricity is sent through the generator and outflow to the power lines for distribution."}]}





# Page 187

# Safety Precautions 

Damp conditions - ensure that all gadgets are away from water or your hands are not wet before touching electric gadgets or appliances.
$>$ Do not carry out repairs; only hire the electrician with the knowledge and should disconnect main circuit breakers before.
$>$ Avoid overloading circuits.
$>$ Earthing - reduces electric shock and being electrocuted in that appliances are earthed using an earth wire which would carry current when there is leakage of electricity due to a fault.
$>$ Use insulated cables and wear rubber footwear when using appliances.
$>$ Use three pin plugs on all permanent appliances.
The $3-$ pin plug
![img-164.jpeg](img-164.jpeg)
$>$ Live wire - brown, neutral wire - blue and earth wire - green - yellow. The live wire carries electric current and is considered alive. The earth wire carries current only when there is a leakage due to a fault. The live wire is at full potential of 250 volts while the neutral carries current away and has a potential of -250 volts. At the back of the case of the 3 - pin plug, are letters E, N, L indicating Earth, Neutral and Live respectively. The insulator (rubber or plastic) prevents short circuiting and prevent the user from electrocution.

The $2-$ pin plug
$>$ A 2 - pin plug is connected only to the live and neutral wires and has no earth wire. Appliances such as steam irons, radio and TV sets use the 2 - pin plug.

## Experiment 1

Aim: To demonstrate the effect of a short circuit/overloading of a circuit on a fuse.
Materials: 6 or 12 V battery, copper wires, fuse wire/steel wool strand, switch, car headlamp, torch bulb, switch, 2 nails, wooden block

## Method

- Set up with circuit with a torch bulb in the circuit.
- Close the switch and observe the fuse wire.
- Replace the bulb in the circuit with a car hand-lamp which draws more current than the torch bulb.
- Open the switch and replace the fuse wire.
- Take a wire and replace the bulb with it.
- Close the switch and observe the fuse

## OlmOCR Image Descriptions

### Image: img-164.jpeg

![img-164.jpeg](/Users/Apple/Documents/web_app/project/rag_pipeline/full_knowledge_bank/Form 4/Combined Science/images/img-164.jpeg.png)


s":"The diagram illustrates the internal components of an electrical plug. It includes labels for various parts:\n\n- **Earth wire (green-yellow)**\n- **Neutral wire (blue)**\n- **Live wire (brown)**\n- **Fuse**\n- **Cable**\n\nThese wires are connected to corresponding terminals within the plug, ensuring proper electrical flow. The diagram provides a clear visual guide for understanding the internal structure and wiring of an electrical plug."}





# Page 188

Results and Observations

- The fuse wire remains intact when a torch bulb is used.
- The fuse blows when the torch bulb is replaced with a car head lamp
- The fuse also blows when a wire is used to short circuit the circuit.


## Conclusion

- Fuses can protect a circuit from overloading/short circuits by blowing and breaking the circuit.

Uses of electricity in the home
a) Heating.
b) Lighting.
c) Powering electrical devices.

Buying electricity
$>$ Electrical energy from the National Grid used in household is measured on a meter in each house. We buy electricity at a fixed price per unit of energy. In Zimbabwe, it costs $\$ 0.90$ per kW.
$>$ We use the Kilowatt - Hour to measure the amount of electricity used.
$>$ One kilowatt - hour is the energy used in one hour by electrical appliances.
$>$ Number of kWh units $=\frac{\text { watts }}{1000} \times$ hours.
Or $1 \mathrm{kWh}=1000 \mathrm{~J} / \mathrm{s} \times 3600 \mathrm{~s}$
$=3600000 \mathrm{~J}=3.6 \mathrm{MJ}$
$>$ A 3 kW electric fire working for 2 hours uses 6 kWh of electrical energy - usually called 6 'units'. Electricity meters, which are joulemeters, are marked in kWh : the latest have digital readouts.
Example 1: How much electricity is used by 60 w lamp running for 20 hours?
Solution: $=\frac{60}{1000} \times 20$

$$
\begin{aligned}
& =\frac{1200}{1000} \\
& =1.2 \mathrm{~kW}
\end{aligned}
$$

Therefore if 1 kilowatt costs $\$ 0.90$, the cost of 1.2 kW is $\$ 1.08$
Methods of saving electricity
a) Use of energy saving bulbs and low power rated appliances.
b) Finding other alternative sources of energy.
c) Use of solar panels.
d) Switching off gadgets and appliances not in use.



# Page 189

# REFERENCES 

1. Chavhunduka, K. (2017) Step Ahead Combined Science Form 3: Learner`s Book, Pearson, Cape Town.
2. Chavhunduka, K. (2017) Step Ahead Combined Science Form 4: Learner`s Book, Pearson, Cape Town.
3. Darwin, A. and du Toit, L. (2011), Focus on O` Level Integrated Science Book 3, College Press, Harare.
4. Darwin, A. and du Toit, L. (2011), Focus on O` Level Integrated Science Book 4, College Press, Harare.
5. Mapato, A and Jokomo, E. (2010) O`level Integrated Science Today Volume One Book 3, ZPH Publishers, Harare.
6. Step Ahead O` Level Integrated Science

END
NEW CURRICULUM 2017 - 22
DHLIWAYO P 0775777982 / 0716279474



# Page 190

pdhliwayo2016@gmail.com
Combined Science Notes 2018
190 | P a g e


